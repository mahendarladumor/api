<?php

$jsonFileUrl = 'https://2xrewards.com/Api/appsetup.json';
$jsonData = file_get_contents($jsonFileUrl);
$app = json_decode($jsonData, true);

const DB_USER1 = "2xrewards";
const DB_PASSWORD1 = "Lyri7Gaed7RkzajS";
const DB1 = "2xrewards";

const Miv = "jhza5tua567whsad";
const Mkey = "ghsd56sdjh68sdfj";
$Miv = "jhza5tua567whsad";
$Mkey = "ghsd56sdjh68sdfj";



$user_name = "2xrewards";
$db_password = "Lyri7Gaed7RkzajS";
$db_name = "2xrewards";



//type
$adjoe_earning_type  = "24";
$adjump_earning_type = "45";
$appsprize_earning_type = "50";
$everflow_earning_type = "53";
$offertoro_earning_type = "51";
$pubscale_earning_type = "40";
$playtime_sdk_type = "52";

//App 
$appName = $app['App_Name'];

//console,Firbase
$email = $app['email'];
$PackageName = $app['PackageName'];
$Server_key = $app['Server_key'];

//Prefix
$prifix = $app['prifix'];

// short name
//ShareOffer.php
//api.php
