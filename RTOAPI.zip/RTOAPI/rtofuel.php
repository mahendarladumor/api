<?php

date_default_timezone_set('Asia/Kolkata');

$servername = "localhost";
$username = "monkeyreward";
$password = "sZ8xZiRZrhZXTnAN";
$dbname = "monkeyreward";
// Create connection
$mysqli = new mysqli($servername, $username, $password, $dbname);



if (!$mysqli) {

    die("Connection failed: " . mysqli_connect_error());

}



// Assuming $id is defined somewhere before this code

$id = isset($id) && $id > 1 ? $id : 1;



function getUnusedApi($mysqli, $id) {

    $sql = "SELECT * FROM rto_api_list WHERE orderid >= ? AND isUsed = 0 ORDER BY orderid ASC LIMIT 1";

    $stmt = mysqli_prepare($mysqli, $sql);

    mysqli_stmt_bind_param($stmt, "i", $id);

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    return mysqli_fetch_assoc($result);

}



function getApiCallCount($mysqli, $orderid, $date) {

    $sql = "SELECT COUNT(*) as num FROM rto_api_history WHERE orderid = ? AND date = ?";

    $stmt = mysqli_prepare($mysqli, $sql);

    mysqli_stmt_bind_param($stmt, "ss", $orderid, $date);

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    $row = mysqli_fetch_assoc($result);

    return $row['num'];

}



function insertApiHistory($mysqli, $orderid, $date) {

    $score='Rto Fuel';
    $sql = "INSERT INTO `rto_api_history` (`orderid`, `date`, `cronName`) VALUES (?, ?, ?)";

    $stmt = mysqli_prepare($mysqli, $sql);

    mysqli_stmt_bind_param($stmt, "sss", $orderid, $date, $score);

    return mysqli_stmt_execute($stmt);
}



function makeApiCall($key) {

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://indian-fuel.p.rapidapi.com/fuel/data",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "x-rapidapi-host: indian-fuel.p.rapidapi.com",
            "x-rapidapi-key: $key"
        ],
    ]);

    $response = curl_exec($curl);
    $err = curl_error($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);
    return ['response' => $response, 'error' => $err, 'httpCode' => $httpCode];
    
}



function processApiResponse($mysqli, $response) {

     $response;

    $data = json_decode($response, true);


    foreach ($data as $item) {
        $city = $mysqli->real_escape_string($item['city']);
        $diesel = $mysqli->real_escape_string($item['diesel']);
        $petrol = $mysqli->real_escape_string($item['petrol']);
        
        $sql = "INSERT INTO rto_fuel_price (city, diesel, petrol, entry_date) 
                VALUES ('$city', '$diesel', '$petrol', NOW()) 
                ON DUPLICATE KEY UPDATE 
                diesel = '$diesel', 
                petrol = '$petrol', 
                entry_date = NOW()";
        
        if ($mysqli->query($sql) === TRUE) {
            echo "Record for {$city} inserted or updated successfully.<br>";
        } else {
            echo "Error inserting/updating record for {$city}: " . $mysqli->error . "<br>";
        }
    }    

}



$start = date('Y-m-d');



while (true) {

    $res = getUnusedApi($mysqli, $id);

    if (!$res) {

        echo "No unused API keys found.";

        break;

    }



    $orderid = $res['orderid'];

    $count = getApiCallCount($mysqli, $orderid, $start);



    if ($count < 10) {

        $key = $res['key'];

        echo "Using API key: $key\n";



        $result = makeApiCall($key);



        if (!$result['error']) {

            $responseData = json_decode($result['response'], true);

            

            if ($result['httpCode'] == 429 && isset($responseData['message']) && strpos($responseData['message'], "You have exceeded the DAILY quota") !== false) {

                echo "Daily quota exceeded for this key. Trying next key.\n";

                $id = $orderid + 1;

                continue;

            }



            if (insertApiHistory($mysqli, $orderid, $start)) {

                echo "API call recorded successfully.\n";

                processApiResponse($mysqli, $result['response']);

            } else {

                echo "Failed to record API call.\n";

            }

            break;

        } else {

            echo "API call failed. Error: " . $result['error'] . "\n";

            echo "Trying next key.\n";

        }

    }
    function isWithinTimeRange() {
        $currentHour = (int)date('H');
        return ($currentHour >= 7 && $currentHour < 24);
    }
    
    $start = date('Y-m-d');
    
    while (true) {
        // Check if current time is within the specified range
        $res = getUnusedApi($mysqli, $id);
        if (!$res) {
            echo "No unused API keys found.";
            break;
        }
    
        $orderid = $res['orderid'];
        $count = getApiCallCount($mysqli, $orderid, $start);
    
        if ($count < 10) {
            $key = $res['key'];
            echo "Using API key: $key\n";
    
            $result = makeApiCall($key);
    
            if (!$result['error']) {
                $responseData = json_decode($result['response'], true);
                
                if ($result['httpCode'] == 429 && isset($responseData['message']) && strpos($responseData['message'], "You have exceeded the DAILY quota") !== false) {
                    echo "Daily quota exceeded for this key. Trying next key.\n";
                    $id = $orderid + 1;
                    continue;
                }
    
                if (insertApiHistory($mysqli, $orderid, $start)) {
                    echo "API call recorded successfully.\n";
                    processApiResponse($mysqli, $result['response']);
                } else {
                    echo "Failed to record API call.\n";
                }
                break;
            } else {
                echo "API call failed. Error: " . $result['error'] . "\n";
                echo "Trying next key.\n";
            }
        }
    
        $id = $orderid + 1;
    }


    // $id = $orderid + 1;

}



mysqli_close($mysqli);
?>