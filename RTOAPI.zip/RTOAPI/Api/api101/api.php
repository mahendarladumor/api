<?php
// RTO  
include("../../all_comon.php");
require_once("Rest.inc.php");
include("../ip_files/countries.php");
require_once("PaytmChecksum.php");
$serviceAccountJson = file_get_contents('https://2xrewards.com/serverToken.json');
$key = json_decode($serviceAccountJson, true);
header('Content-type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Acess-Control-Allow-Origin: *");
error_reporting(E_ERROR | E_PARSE);
date_default_timezone_set("Asia/Calcutta");

$jsonFileUrl = 'https://2xrewards.com/Api/appsetup.json';

$jsonData = file_get_contents($jsonFileUrl);
$app = json_decode($jsonData, true);
global $encryptionMethod, $iv, $secretHash, $WelcomeBonusPoint, $charges, $minAmontCharger, $Server_key, $email, $Youtube_url, $Telegram_url, $Insta_url, $App_Name, $PackageName, $isShowPubScale, $isShowAdjump, $isShowOfferToro, $isShowFooterTaskIcon, $isScanAndPayShow, $isShowAppPrize, $isShowHomeBottomSheet, $isAppLovinAdShow, $app_logo, $prifix, $adjoeKeyHash, $isShowAdjoeLeaderboardIcon, $isShowHotOffers, $hotOffersScreenNo, $isTaskVisible, $isTaskVisibleScreenNo, $isShowGiveawayCode, $Miv, $Mkey, $bottomname, $bottomscreenno, $isBackAdsInterstitial, $offerToroAppId, $OfferToroSecretKey, $isShowPlaytimeSDK, $appVersion, $ScanAndPayScreenNo ,$serverToken, $projectId,$isFloatFooterScanAndPayShow;

$App_Name = "2x Reward";
$app_logo = "https://2xrewards.com/Api/images/icon/two_x_app_logo11.png";
$Youtube_url = "https://www.youtube.com/@2XReward";
$Telegram_url = "https://t.me/Reward2Xapp";
$Insta_url = "https://www.instagram.com/2xreward/?igsh=MXFjcGw0Z2Nxc3N5MA%3D%3D";
$email = "pallferoz92@gmail.com";
$PackageName = "app.earneasy.topgames.dailyrewards";
$Server_key = "AAAAywK1qAU:APA91bGbRAQZL85gjnw6Ukq3i-0B5CqlywSDTSgoTqtvuzj9JQXnlQ1ngvHyQtOJqw_uodBYTp_eA6sFpw3aBrqfwgGywogfNKJjWG4i1vgBhy8GuFGRgXEjf_52tXsA6fAeKKg3RBUW";

$prifix = "2XR";

$isShowPubScale = "0";
$isShowAdjump = "0";
$isShowOfferToro = "0";
$isShowFooterTaskIcon = "0";
$isScanAndPayShow = "0";
$isShowAppPrize = "0";
$isShowHomeBottomSheet = "0";
$isAppLovinAdShow = "0";
$isFloatFooterScanAndPayShow = "0";
$adjoeKeyHash = "6d7a9a7589e769011ab5ad2709dc32dd";
$isShowAdjoeLeaderboardIcon = "0";
$isShowHotOffers = "0";
$hotOffersScreenNo = "31";
$isTaskVisible = "0";
$isTaskVisibleScreenNo = "11";
$isShowGiveawayCode = "0";
$bottomname = "Offers";
$bottomscreenno = "11";
$isBackAdsInterstitial = "0";
$offerToroAppId = "15599";
$OfferToroSecretKey = "3eaf1d0f9f658278b9b20e48e5306f38";
$isShowPlaytimeSDK = "1";
$appVersion = "1.0.1";
$ScanAndPayScreenNo = "52";

$serverToken = $key['token'];
$projectId = $key['project_id'];


//privacy & Policy
$aboutUsUrl = "https://2xrewards.com/aboutUs.html";
$privacyPolicy = "https://2xrewards.com/PrivacyPolicy.html";
$termsConditionUrl = "https://2xrewards.com/TermsConditions.html";



$encryptionMethod = "rijndael-128";
$secretHash = "ghsd56sdjh68sdfj";
$iv = "jhza5tua567whsad";
$WelcomeBonusPoint = 200;
$minAmontCharger = 10;
$charges = 120;


// not live countRow =1; live countRow =0;
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

class API extends REST
{

	public $data = "";
	const DB_SERVER = "localhost";
	const DB_USER = "monkeyreward";
	const DB_PASSWORD = "sZ8xZiRZrhZXTnAN";
	const DB = "monkeyreward";
	private $db = NULL;

	#const Miv =  'gtagyup2pb2bc2c9'; #Same as in JAVA
	const Miv =  "jhza5tua567whsad"; #Same as in JAVA
	const Mkey = "ghsd56sdjh68sdfj"; #Same as in JAVA
	#const Mkey = 'avbbht00704aabcp'; #Same as in JAVA
	const isCompleteAdjoeGame = '0'; // This will check adjoe first then will check for task completion

	public function __construct()
	{
		parent::__construct();
		$this->dbConnect();
	}

	private function dbConnect()
	{
		$this->db = mysqli_connect(self::DB_SERVER, self::DB_USER, self::DB_PASSWORD, self::DB);
		$this->db->set_charset('utf8mb4');
	}


	public function processApi()
	{
		if (isset($_REQUEST['rquest']) && $_REQUEST['rquest'] != null) {
			$func = strtolower(trim(str_replace("/", "", $_REQUEST['rquest'])));

			if ((int) method_exists($this, $func) > 0)
				$this->$func();
			else
				$result = array(
					'status' => "0",
					'message' => "Something Wrong"
				);
			$this->response($this->json($result), 404);
		} else {
			$result = array(
				'status' => "0",
				'message' => "Something Wrong"
			);
			$this->response($this->json($result), 404);
		}
	}

	// public function processApi()
	// {
	// 	if (isset($_REQUEST['rquest']) && $_REQUEST['rquest'] != null) {

	// 		ob_start();
	// 		var_dump($_SERVER);
	// 		$server = ob_get_clean();

	// 		$pattern = '/\[\"CONTENT_TYPE\"\]=>\s+string\(\d+\) \"(.*?)\"/';
	// 		if (preg_match($pattern, $server, $matches)) {
	// 			$contentType = $matches[1];
	// 		}

	// 		$func = strtolower(trim(str_replace("/", "", $_REQUEST['rquest'])));
	// 		if (strpos($contentType, 'application') !== false ||  $func == strtolower('YBOLPJKMNY') ||  $func == strtolower('DEGNJLJUJK')) {

	// 			if ((int) method_exists($this, $func) > 0)

	// 				$this->$func();
	// 			else
	// 				$result = array(
	// 					'status' => "0",
	// 					'message' => "Something Wrong"
	// 				);
	// 			$this->response($this->json($result), 404);
	// 		} else {
	// 			$result = array(
	// 				'status' => "0",
	// 				'message' => "Something Wrong."
	// 			);
	// 			$this->response($this->json($result), 404);
	// 		}
	// 	} else {
	// 		$result = array(
	// 			'status' => "0",
	// 			'message' => "Something Wronng"
	// 		);
	// 		$this->response($this->json($result), 404);
	// 	}
	// }

	function iptocountry($ip)
	{

		$numbers = preg_split("/\./", $ip);
		include("../ip_files/" . $numbers[0] . ".php");
		$code = ($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
		foreach ($ranges as $key => $value) {
			if ($key <= $code) {
				if ($ranges[$key][0] >= $code) {
					$two_letter_country_code = $ranges[$key][1];
					break;
				}
			}
		}
		if ($two_letter_country_code == "") {
			$two_letter_country_code = "unkown";
		}
		return $two_letter_country_code;
		// return "USA";
	}

	private function DeviceRegistor()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$str = $this->_request['enc'];
		$DeviceId = $Details['device_id'];


		$this->response($this->json($result), 200);
	}


	function exists_url($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		// don't download content
		curl_setopt($ch, CURLOPT_NOBODY, 1);
		curl_setopt($ch, CURLOPT_FAILONERROR, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$result = curl_exec($ch);
		curl_close($ch);
		if ($result !== FALSE) {
			return true;
		} else {
			return false;
		}
	}

	function exists_url1($url)
	{
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_NOBODY, true);
		if ($result = curl_exec($curl)) {
			$statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			if ($statusCode != 404) {
				return true;
			}
		}
		return false;
	}


	private function AdminLogin()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$Details = json_decode($this->_request['details'], true);
		$DeviceId = $Details['id'];
		$mobileNumber = $Details['pass'];
		$result = array();

		$setting = mysqli_query($this->db, "SELECT id,password FROM tbl_admin WHERE  username = '" . $DeviceId . "' ");
		if ($setting->num_rows > 0) {
			$rowewf = $setting->fetch_assoc();
			$password = $rowewf['password'];
			if ($mobileNumber === $password) {
				$result['message'] = "Login Sucessfully.";
				$result['status'] = "1";
			} else {
				$result['message'] = "Invalid Password";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "This Username is not registor with us. ";
			$result['status'] = "0";
		}
		$this->response($this->json($result), 200);
	}



	function gen_uuid()
	{
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			// 32 bits for "time_low"
			mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),

			// 16 bits for "time_mid"
			mt_rand(0, 0xffff),

			// 16 bits for "time_hi_and_version",
			// four most significant bits holds version number 4
			mt_rand(0, 0x0fff) | 0x4000,

			// 16 bits, 8 bits for "clk_seq_hi_res",
			// 8 bits for "clk_seq_low",
			// two most significant bits holds zero and one for variant DCE1.1
			mt_rand(0, 0x3fff) | 0x8000,

			// 48 bits for "node"
			mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0xffff)
		);
	}


	private function SARAS()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();
		$Details = json_decode($this->_request['details'], true);

		
				$resSlider = mysqli_query($this->db, "SELECT city,diesel,petrol FROM `rto_fuel_price` ");
				if (mysqli_num_rows($resSlider) > 0) {
					while ($rlContest = mysqli_fetch_array($resSlider, MYSQLI_ASSOC)) {
						$result['rto_fuel_price'][] = $rlContest;
					}
					$result['message'] = "Data Found Sucessfully";
					$result['status'] = "1";
				}		
		$this->response($this->json($result), 200);
	}


private function checktoken($token)
	{
		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array("title" => "You Login Success.", 'body' => "Please Check your redeem history for redeem coupon code."),
			'android' => array('notification' => array("title" => "You Login Success.", 'body' => "Please Check your redeem history for redeem coupon code.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "You Login Success.",
				"description" => "Please Check your redeem history for redeem coupon code.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "coin",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		curl_exec($curl);
		$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		$json_response = curl_exec($curl);
		curl_close($curl);
		if ($status == 200) {
			return true;
		} else {
			return false;
		}
	}
	




	


	

	

	



	function log($Details, $name, $isencrypted)
	{
		$on = '1';
		if ($on == '1') {

			if ($isencrypted == '1') {
				$decrypted = MCrypt::decrypt($Details);
				$encrypted = json_decode($decrypted, true);
				$var =  json_encode($encrypted, JSON_PRETTY_PRINT);
				$querry2 = mysqli_query($this->db, "INSERT INTO `log_master` ( `apiName`, `details`,`decrypted`, `appName`) VALUES ('" . $name . "', '" . $Details . "','" . $var . "', '2xreard')");
			} else {

				$var =  json_encode($Details, JSON_PRETTY_PRINT);
				$querry2 = mysqli_query($this->db, "INSERT INTO `log_master` ( `apiName`, `decrypted`, `appName`) VALUES ('" . $name . "', '" . $var . "', '2xreard')");
			}
		}
	}








	



	


	



	function checkwatchvideo($videoid, $point)
	{
		switch ($videoid) {
			case "1":
				if ($point >= 5 && $point <= 30) {
					return true;
				} else {
					return false;
				}
				break;


			case "2":
				if ($point >= 2 && $point <= 20) {
					return true;
				} else {
					return false;
				}
				break;

			case "3":
				if ($point >= 10 && $point <= 30) {
					return true;
				} else {
					return false;
				}
				break;

			case "4":
				if ($point >= 2 && $point <= 10) {
					return true;
				} else {
					return false;
				}
				break;
			case "5":
				if ($point >= 9 && $point <= 35) {
					return true;
				} else {
					return false;
				}
				break;
			case "6":
				if ($point >= 2 && $point <= 42) {
					return true;
				} else {
					return false;
				}
				break;
			case "7":
				if ($point >= 10 && $point <= 22) {
					return true;
				} else {
					return false;
				}
				break;
			case "8":
				if ($point >= 10 && $point <= 42) {
					return true;
				} else {
					return false;
				}
				break;
			case "9":
				if ($point >= 14 && $point <= 45) {
					return true;
				} else {
					return false;
				}
				break;
			case "10":
				if ($point >= 4 && $point <= 20) {
					return true;
				} else {
					return false;
				}
				break;

			default:
				return false;
		}
	}








	









	private function getUserAgent()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$agent = $_SERVER['HTTP_USER_AGENT'];
		// echo ;

		$result['message'] = "Data Found Sucessfully.";
		$result['status'] = "1";
		$result['agent'] = $agent;
		$this->response($this->json($result), 200);
	}










	private function FDGDHGJFSDABVBH()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		$Details = json_decode($this->_request['details'], true);
		$result = array();
		$vehicle = $Details['HDYTHDHY'];

		$ipaddress = $this->getIp();
		$date = date('Y-m-d');
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		
		$TodayOnlydate = date('Y-m-d');

		// Get available API key
		$apiKey = $this->getAvailableApiKey();
		if (!$apiKey) {
			$result['message'] = "No available API keys. Please contact support.";
			$result['status'] = "0";
			$this->response($this->json($result), 200);
			return;
		}

		if($vehicle != ""){
			// $retry = true;
    		// while ($retry) {	
			$curl = curl_init();
			
			curl_setopt_array($curl, [
				CURLOPT_URL => "https://rto-vehicle-information-verification-india.p.rapidapi.com/api/v1/rc/vehicleinfo",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS => json_encode([
					'reg_no' => $vehicle,
					'consent' => 'Y',
					'consent_text' => 'I hear by declare my consent agreement for fetching my information via AITAN Labs API'
				]),
				CURLOPT_HTTPHEADER => [
					"Content-Type: application/json",
					"x-rapidapi-host: rto-vehicle-information-verification-india.p.rapidapi.com",
					"x-rapidapi-key: " . $apiKey
				],
			]);

			$response = curl_exec($curl);
			$err = curl_error($curl);
			// $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			
			// curl_close($curl);
			
			if ($err) {
					echo "cURL Error for \n";
					// $retry = false;
					// continue;
			} else {
				$responseData = json_decode($response, true);
				
				// Check if the API request was successful
				if (isset($responseData['status']) && $responseData['status'] === 'success') {
					$result['Data']= $responseData['result'];
					$result['status'] = "1";
					
					// Update API key usage
					$this->updateApiKeyUsage($apiKey);
				} else {
					$result['message'] = "API request failed: " . ($responseData['message'] ?? 'Unknown error');
					$result['status'] = "0";
					// if ($httpCode == 429 && isset($responseData['message']) && strpos($responseData['message'], "You have exceeded the MONTHLY quota") !== false) {
					// 	$result['ApiResponse'] = "Monthly quota exceeded for this key. Moving to next key.\n";
					// 	$this->updateApiKeyUsage($apiKey);
					// } else {
					// 	$retry = false;
					// }
					$this->updateApiKeyUsage($apiKey);

				}
			// }
		}
		} else {
			$result['message'] = "Vehicle number is required.";
			$result['status'] = "0";
			
		}

		$this->response($this->json($result), 200);
	}





	private function getAvailableApiKey() {
		$query = "SELECT `key` FROM rto_tbl_api_list  WHERE isUsed = 0 AND monthly_count < 5 ORDER BY id ASC LIMIT 1";
		$result = $this->db->query($query);
		
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row['key'];
		}
		
		return null;
	}

	private function updateApiKeyUsage($key) {
		$query = "UPDATE rto_tbl_api_list  SET monthly_count = monthly_count + 1 WHERE `key` = '$key'";
		$this->db->query($query);
		
		$query = "UPDATE rto_tbl_api_list  SET isUsed = 1 WHERE `key` = '$key' AND monthly_count >= 5";
		$this->db->query($query);
	}




	private function CheckMobileNo()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		$Details = json_decode($this->_request['details'], true);
		$DeviceId = $Details['device_id'];
		$mobileNumber = $Details['mobileNumber'];
		$result = array();

		$setting = mysqli_query($this->db, "SELECT userId FROM user_master WHERE  mobileNumber = '" . $mobileNumber . "' ");
		if ($setting->num_rows > 0) {
			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";
		} else {
			$result['message'] = "Please Login/Signup With emailId.";
			$result['status'] = "0";
		}
		$this->response($this->json($result), 200);
	}

	private function shorten_URL($longUrl)
	{
		global $App_Name, $app_logo;
		$key = 'AIzaSyD_QK-ka7sWe2cc48Us8aTKXsc44CmHjyE';
		$url = 'https://firebasedynamiclinks.googleapis.com/v1/shortLinks?key=' . $key;
		$data = array(
			"dynamicLinkInfo" => array(
				"dynamicLinkDomain" => "RewardExpres.page.link",
				"link" => $longUrl,
				"androidInfo" =>  array("androidPackageName" => $PackageName),
				"socialMetaTagInfo" => array(
					"socialTitle" => "$App_Name : Your Earning Partner",
					"socialDescription" => "$App_Name is one of the BEST money earning and most trusted App in India.",
					"socialImageLink" => $app_logo
				)
			),
			"suffix" => array(
				"option" => "UNGUESSABLE"
			)
		);

		$headers = array('Content-Type: application/json');

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

		$data = curl_exec($ch);
		curl_close($ch);

		$short_url = json_decode($data);
		if (isset($short_url->error)) {
			return "";
		} else {
			return $short_url->shortLink;
		}
	}


	function dateDiffInDays($date1, $date2)
	{

		$diff = strtotime($date2) - strtotime($date1);
		return abs(round($diff / 86400));
	}


	function getLocationInfoByIp()
	{
		$client  = @$_SERVER['HTTP_CLIENT_IP'];
		$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote  = @$_SERVER['REMOTE_ADDR'];
		$result  = array('country' => '', 'city' => '');
		if (filter_var($client, FILTER_VALIDATE_IP)) {
			$ip = $client;
		} elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
			$ip = $forward;
		} else {
			$ip = $remote;
		}

		$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
		//$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=138.197.222.35"));    
		if ($ip_data && $ip_data->geoplugin_countryName != null) {
			$result['country'] = $ip_data->geoplugin_countryCode;
			$result['city'] = $ip_data->geoplugin_city;
		}

		return $result;
	}



	private function senWithdrawNoChanneSucesslNotiCoupone($token, $point)
	{

		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array("title" => "Your Withdraw Request Sucessfully Credit in your redeem history.", 'body' => "Please Check your redeem history for redeem coupon code."),
			'android' => array('notification' => array("title" => "Your Withdraw Request Sucessfully Credit in your redeem history.", 'body' => "Please Check your redeem history for redeem coupon code.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "Your Withdraw Request Sucessfully Credit in your redeem history.",
				"description" => "Please Check your redeem history for redeem coupon code.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "success",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}



	private function senWithdrawNoChanneSucesslNoti($token, $point)
	{


		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array("title" => "We have transferred money to your UPI wallet successfully.", 'body' => "Please check your UPI wallet. Give 5 Star tatings & review on playstore."),
			'android' => array('notification' => array("title" => "We have transferred money to your UPI wallet successfully.", 'body' => "Please check your UPI wallet. Give 5 Star tatings & review on playstore.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "We have transferred money to your UPI wallet successfully.",
				"description" => "Please check your UPI wallet. Give 5 Star tatings & review on playstore.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "success",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}

	private function senWithdrawNoChanneSucesslNotiUPI($token, $point)
	{

		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array('title' => "We have transferred money to your UPI bank account successfully.", 'body' => "Please check your UPI wallet. Give 5 Star tatings & review on playstore."),
			'android' => array('notification' => array('title' => "We have transferred money to your UPI bank account successfully.", 'body' => "Please check your UPI wallet. Give 5 Star tatings & review on playstore.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "We have transferred money to your UPI bank account successfully.",
				"description" => "Please check your UPI wallet. Give 5 Star tatings & review on playstore.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "success",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}


	private function senWithdrawNoChanneSucesslNotiQR($token, $point)
	{
		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array('title' => "We have transferred money to your merchant bank successfully.", 'body' => ""),
			'android' => array('notification' => array('title' => "We have transferred money to your merchant bank successfully.", 'body' => "")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "We have transferred money to your merchant bank successfully.",
				"description" => "",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "success",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}


	private function refreFrendNoti($token, $point)
	{
		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array('title' => $point . " Free Points received!", 'body' => "Your friend has signed up with your referral code."),
			'android' => array('notification' => array('title' => $point . " Free Points received!", 'body' => "Your friend has signed up with your referral code.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => $point . " Free Points received!",
				"description" => "Your friend has signed up with your referral code.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "coin",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}



	private function sendDailyLoginNoti($token, $point)
	{
		global $Server_key, $serverToken, $projectId;

		$image = "";

		$flip1 = rand(0, 10);

		if ($flip1 == '1') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/259_newvideo.jpg";
		} else if ($flip1 == '2') {
			$image = "https://mycashbazar.com/admin/images/homeslider/85_taskkarorearnkaro.png";
		} else if ($flip1 == '3') {
			$image = "https://mycashbazar.com/admin/images/homeslider/20_smallads.png";
		} else if ($flip1 == '4') {
			$image = "https://mycashbazar.com/admin/images/homeslider/81_2INR.png";
		} else if ($flip1 == '5') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/728_refervideo.png";
		} else if ($flip1 == '6') {
			$image = "https://mycashbazar.com/admin/images/homeslider/81_2INR.png";
		} else if ($flip1 == '7') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/476_Minmimamwithdrawnew.jpg";
		} else if ($flip1 == '8') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/427_sdsdsd.png";
		} else if ($flip1 == '9') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/672_ewwewewe.jpg";
		}


		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array('title' => "Congratulations!", 'body' => $point . " Points has been credited in your wallet."),
			'android' => array('notification' => array('title' => "Congratulations!", 'body' => $point . " Points has been credited in your wallet.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "Congratulations!",
				"description" => $point . " Points has been credited in your wallet.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "coin",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		curl_close($curl);
	}
	private function Hello()
	{
		if ($this->get_request_method() != "GET") {
			$this->response('', 406);
		}
		$result[] = array('Hello' => "Milan Pambhar");
		$this->response($this->json($result), 200);
	}

	private function json($data)
	{
		// $encrypt = MCrypt::encrypt(json_encode($data));
		$mcrypt = new MCrypt();
		$encrypted = $mcrypt->encrypt(json_encode($data));
		// $data= array();
		$data['encrypt'] = $encrypted;
		if (is_array($data)) {
			return json_encode($data);
		}
	}



	function getIp()
	{
		$ip = $_SERVER['REMOTE_ADDR'];
		if ($ip) {
			if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
				$ip = $_SERVER['HTTP_CLIENT_IP'];
			} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
				$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
			}
			return $ip;
		}
		return false;
	}


	function startsWith($haystack, $needle)
	{
		$length = strlen($needle);
		return (substr($haystack, 0, $length) === $needle);
	}
}
$api = new API;
$api->processApi();


class MCrypt
{

	public $iv = "jhza5tua567whsad"; #Same as in JAVA
	public $key = "ghsd56sdjh68sdfj"; #Same as in JAVA
	function __construct()
	{
	}




	function encrypt($str)
	{

		global $encryptionMethod, $secretHash, $iv;

		$td = mcrypt_module_open($encryptionMethod, '', 'cbc', $iv);

		mcrypt_generic_init($td, $secretHash, $iv);
		$encrypted = mcrypt_generic($td, $str);

		mcrypt_generic_deinit($td);
		mcrypt_module_close($td);

		return bin2hex($encrypted);
	}

	static function decrypt($code)
	{
		global $encryptionMethod, $secretHash, $iv;

		$code = hex2bin($code);

		$td = mcrypt_module_open($encryptionMethod, '', 'cbc', $iv);

		mcrypt_generic_init($td, $secretHash, $iv);
		$decrypted = mdecrypt_generic($td, $code);

		mcrypt_generic_deinit($td);
		mcrypt_module_close($td);

		return utf8_encode(trim($decrypted));
	}


	function hex2bin($hexdata)
	{
		$bindata = '';
		for ($i = 0; $i < strlen($hexdata); $i += 2) {
			$bindata .= chr(hexdec(substr($hexdata, $i, 2)));
		}
		return $bindata;
	}
}
