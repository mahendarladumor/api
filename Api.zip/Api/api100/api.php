<?php
// eazyearning_in
include("../../all_comon.php");
require_once("Rest.inc.php");
include("../ip_files/countries.php");
require_once("PaytmChecksum.php");
header('Content-type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Acess-Control-Allow-Origin: *");
error_reporting(E_ERROR | E_PARSE);
date_default_timezone_set("Asia/Calcutta");
define('DB_SERVER', 'localhost');
define('DB_USER', $user_name);
define('DB_PASSWORD', $db_password);
define('DB', $db_name);


$jsonFileUrl = 'https://eazyearning.com/Api/appsetup.json';


$jsonData = file_get_contents($jsonFileUrl);


$app = json_decode($jsonData, true);


// global $App_Name, $app_logo, $Youtube_url, $Telegram_url, $Insta_url, $email, $PackageName, $Server_key, $prifix, $isShowPubScale, $isShowAdjump, $isShowOfferToro, $isShowFooterTaskIcon, $isScanAndPayShow, $isShowAppPrize, $isShowHomeBottomSheet, $isAppLovinAdShow, $isFloatFooterScanAndPayShow;

global $Server_key, $email, $Youtube_url, $Telegram_url, $Insta_url, $App_Name, $PackageName, $isShowPubScale, $isShowAdjump, $isShowOfferToro, $isShowFooterTaskIcon, $isScanAndPayShow, $isShowAppPrize, $isShowHomeBottomSheet, $isAppLovinAdShow, $app_logo, $prifix, $adjoeKeyHash, $isShowAdjoeLeaderboardIcon, $isShowHotOffers, $hotOffersScreenNo, $isTaskVisible, $isTaskVisibleScreenNo, $isShowGiveawayCode;

$App_Name= "Easy Earn";
$app_logo= "https://eazyearning.com/Api/images/logo1.png";
$Youtube_url= "https://www.youtube.com/@EasyEarn-yh7kq";
$Telegram_url= "https://t.me/easyearnrreward";
$Insta_url= "https://www.instagram.com/easyearn_reward/?igsh=MW9vanBxcjFoczB1aA%3D%3D";
$email= "info.easyearn1@gmail.com";
$PackageName= "app.rewards.easyearn";
$Server_key= "AAAAw7mqoNU:APA91bHoYIOCYlKz8YI-VheaD36X8YDTSTWuGsYhZs8uRMKwYnq_uhZBsN_TxoXtPxqXucJapQWiChpZxAfqjYYNagZAIAuhFi6io1TPBBQ7uiMreoXFOXOVM9swzipBfhsCeE2bXSNq";
$prifix= "EE";
$adjoeKeyHash= "6d7a9a7589e769011ab5ad2709dc32dd";
$isShowAdjoeLeaderboardIcon= "0";
$isShowHotOffers= "0";
$hotOffersScreenNo= "31";
$isTaskVisible= "0";
$isTaskVisibleScreenNo= "21";
$isShowGiveawayCode= "0";
$isShowPubScale= "1";
$isShowAdjump= "1";
$isShowOfferToro= "1";
$isShowFooterTaskIcon= "0";
$isScanAndPayShow= "0";
$isShowAppPrize= "0";
$isShowHomeBottomSheet= "0";
$isAppLovinAdShow= "0";
$isFloatFooterScanAndPayShow= "0";

global $encryptionMethod, $iv, $secretHash, $WelcomeBonusPoint, $charges, $minAmontCharger;

$encryptionMethod = "rijndael-128";
$secretHash = "bsrbsr237lf25vsr";
$iv = 'saybsr237lf25387';
$WelcomeBonusPoint = 200;
$charges = 120;
$minAmontCharger = 10;



class API extends REST
{
	public $data = "";
	const DB_SERVER = "localhost";
	const DB_USER = "eazyearning";
	const DB_PASSWORD = "LiakWfyk6Ls62SZX";
	const DB = "eazyearning";
	private $db = NULL;

	const Miv =  'saybsr237lf25387'; #Same as in JAVA
	const Mkey = 'bsrbsr237lf25vsr'; #Same as in JAVA
	const isCompleteAdjoeGame = '0'; // This will check adjoe first then will check for task completion

	public function __construct()
	{
		parent::__construct();
		$this->dbConnect();
	}

	private function dbConnect()
	{
		$this->db = mysqli_connect(self::DB_SERVER, self::DB_USER, self::DB_PASSWORD, self::DB);
		$this->db->set_charset('utf8mb4');
	}

	public function processApi()
	{
		if (isset($_REQUEST['rquest']) && $_REQUEST['rquest'] != null) {
			$func = strtolower(trim(str_replace("/", "", $_REQUEST['rquest'])));

			if ((int) method_exists($this, $func) > 0)
				$this->$func();
			else
				$result = array(
					'status' => "0",
					'message' => "Something Wrong2"
				);
			$this->response($this->json($result), 404);
		} else {
			$result = array(
				'status' => "0",
				'message' => "Something Wrong1"
			);
			$this->response($this->json($result), 404);
		}
	}

	function iptocountry($ip)

	{

		$numbers = preg_split("/\./", $ip);
		include("../ip_files/" . $numbers[0] . ".php");
		$code = ($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
		foreach ($ranges as $key => $value) {
			if ($key <= $code) {
				if ($ranges[$key][0] >= $code) {
					$two_letter_country_code = $ranges[$key][1];
					break;
				}
			}
		}
		if ($two_letter_country_code == "") {
			$two_letter_country_code = "unkown";
		}
		return $two_letter_country_code;
		// return "USA";
	}

	private function DeviceRegistor()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$str = $this->_request['enc'];
		$DeviceId = $Details['device_id'];


		$this->response($this->json($result), 200);
	}


	function exists_url($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		// don't download content
		curl_setopt($ch, CURLOPT_NOBODY, 1);
		curl_setopt($ch, CURLOPT_FAILONERROR, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$result = curl_exec($ch);
		curl_close($ch);
		if ($result !== FALSE) {
			return true;
		} else {
			return false;
		}
	}

	function exists_url1($url)
	{
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_NOBODY, true);
		if ($result = curl_exec($curl)) {
			$statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			if ($statusCode != 404) {
				return true;
			}
		}
		return false;
	}


	private function AdminLogin()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$Details = json_decode($this->_request['details'], true);
		$DeviceId = $Details['id'];
		$mobileNumber = $Details['pass'];
		$result = array();

		$setting = mysqli_query($this->db, "SELECT id,password FROM tbl_admin WHERE  username = '" . $DeviceId . "' ");
		if ($setting->num_rows > 0) {
			$rowewf = $setting->fetch_assoc();
			$password = $rowewf['password'];
			if ($mobileNumber === $password) {
				$result['message'] = "Login Sucessfully.";
				$result['status'] = "1";
			} else {
				$result['message'] = "Invalid Password";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "This Username is not registor with us. ";
			$result['status'] = "0";
		}
		$this->response($this->json($result), 200);
	}



	function gen_uuid()
	{
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			// 32 bits for "time_low"
			mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),

			// 16 bits for "time_mid"
			mt_rand(0, 0xffff),

			// 16 bits for "time_hi_and_version",
			// four most significant bits holds version number 4
			mt_rand(0, 0x0fff) | 0x4000,

			// 16 bits, 8 bits for "clk_seq_hi_res",
			// 8 bits for "clk_seq_low",
			// two most significant bits holds zero and one for variant DCE1.1
			mt_rand(0, 0x3fff) | 0x8000,

			// 48 bits for "node"
			mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0xffff)
		);
	}
	//Login
	private function WINTER()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $email;
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		// $Details = json_decode($this->_request['details'],true);
		$result = array();

		$ipaddress = $this->getIp();
		$appVersion = $Details['N92VJ7'];
		$deviceName = $Details['C3Y7EN'];
		$deviseId = $Details['TQX49F'];
		$adId = $Details['VI6EW9'];
		$todayOpen = $Details['4E68HZ'];
		$totalOpen = $Details['HWLPTH'];
		$deviceVersion = $Details['HABHOQ'];
		$deviceType = $Details['GATMQ9'];
		$deplinkdata = $Details['NNYYR0'];
		$emailId = $Details['CU0OQJ'];
		$firstName = $Details['WT67JQ'];
		$profileImage = $Details['LZMO4U'];
		$countryCode = "91";
		// $countryCode = $Details['countryCode'];
		$lastName = $Details['0D548H'];
		$loginType = "";
		$mobileNumber = "0000000000";
		$referralCode = $Details['VL083K'];
		$deplinkdata = $Details['WWBIJN'];

		$token = $Details['XZVZSY'];

		$referral_user_id = "";
		$referral_user_data = array();
		$cashPoint = '0';
		$agent = $_SERVER['HTTP_USER_AGENT'];

		$refeSecurity = "1";

		if ($refeSecurity == '1') {


			if (strlen($referralCode) > 0) {

				if ($referralCode == "D1SJ99" || $referralCode == "8ZV5OP" || $referralCode == "WL9QW2"  || $referralCode == "XQU0US" || $referralCode == "8TBWY5"  || $referralCode == "NMWVU1" || $referralCode == "NFGM9W"  || $referralCode == "CPLSQ8"  || $referralCode == "09QYKW") {
					$flip1 = rand(0, 10);
					if ($flip1 == '3' || $flip1 == '8' || $flip1 == '5' || $flip1 == '6') {

						$referralCode = "";
						$referral_user_id = "";
						$referral_user_data = array();
					}
				}

				//
				if ($referralCode == "SWSENG" || $referralCode == "MODWW5" || $referralCode == "WL9QW2"  || $referralCode == "XQU0US"  || $referralCode == "8TBWY5" || $referralCode == "NFGM9W"  || $referralCode == "09QYKW"    || $referralCode == "D1SJ99") {
					$flip2 = rand(0, 10);
					if ($flip2 == '3' || $flip2 == '5' || $flip2 == '8' || $flip2 == '9') {
						$referralCode = "";
						$referral_user_id = "";
						$referral_user_data = array();
					}
				}
			}

			if ($referralCode == "09QYKW" || $referralCode == "8TBWY5" || $referralCode == "WL9QW2") {
				$flip2 = rand(0, 10);
				if ($flip2 == '3' || $flip2 == '5' || $flip2 == '9') {
					$referralCode = "";
					$referral_user_id = "";
					$referral_user_data = array();
				}
			}



			if (strlen($referralCode) > 0) {

				$sqlRederID = mysqli_query($this->db, "SELECT * FROM user_master WHERE referralCode = '" . $referralCode . "' ");

				if ($sqlRederID->num_rows > 0) {

					$rowewf = $sqlRederID->fetch_assoc();

					$referral_user_id = $rowewf['userId'];


					$sqlRefrealCount = mysqli_query($this->db, "SELECT COUNT(*) FROM user_master WHERE referralUserId = '" . $referral_user_id . "'  ");
					$row = $sqlRefrealCount->fetch_row();
					if ((int)$row[0] > 200) {

						$flip1 = rand(0, 10);
						if ($flip1 == '3' || $flip1 == '8' || $flip1 == '5' || $flip1 == '4') {
							$referralCode = "";
							$referral_user_id = "";
							$referral_user_data = array();
						} else {
							$referral_user_data = $rowewf;
							$token1 = $rowewf['token'];
							$earningPoint = $rowewf['earningPoint'];
							$referralLink = $rowewf['referralLink'];
						}
					} else {
						$referral_user_data = $rowewf;
						$token1 = $rowewf['token'];
						$earningPoint = $rowewf['earningPoint'];
						$referralLink = $rowewf['referralLink'];
					}

					if ($referralLink == "0") {

						$referral_user_id == "0";

						$referral_user_id = "";

						$referralCode = "";
					}
				}
			}

			if (strlen($emailId) > 0) {

				$sqlEmailId = mysqli_query($this->db, "SELECT * FROM user_master WHERE emailId = '" . $emailId . "' ");
				if ($sqlEmailId->num_rows > 0) {
					$result['userDetails'] = $sqlEmailId->fetch_assoc();
					$result['userDetails']['pointValue'] = "100";

					if ($result['userDetails']['isActive'] == '1') {
						$result['message'] = "Sucessfully Login.";
						$result['status'] = "1";

						$tid = $this->gen_uuid();
						$result['userDetails']['userToken'] = $tid;
						$result['userToken'] = $tid;
						$result['userDetails']['withdrawMobileNo'] = "";
						mysqli_query($this->db, "UPDATE user_master SET token = '" . $token . "' , userToken = '" . $tid . "', adId = '" . $adId . "', deviceName = '" . $deviceName . "', appVersion = '" . $appVersion . "' WHERE userId = '" . $result['userDetails']['userId'] . "' ");
					} elseif ($result['userDetails']['isActive'] == '2') {
						$result['message'] = "Your account is blocked. Please contact us on $email
 email address to get solution.";
						$result['status'] = "0";
					} elseif ($result['userDetails']['isActive'] == '3') {
						$result['message'] = "Your account is deleted. Please contact us on $email
 email address to get solution.";
						$result['status'] = "0";
					} else {
						$result['message'] = "Your account is blocked for some reason. Please contact us on $email
 email address to get solution.";
						$result['status'] = "0";
					}
				} else {
					$sqlEma = mysqli_query($this->db, "SELECT userId,emailId FROM user_master WHERE  profileImage =  '" . $profileImage . "' ");
					if ($sqlEma->num_rows > 0) {
						$roweE = $sqlEma->fetch_assoc();
						$result['status'] = "0";
						$result['message'] = "This device is alredy registered with " . $roweE['emailId'] . " Email Id. Please login with old account.";
					} else {
						if (strlen($referral_user_id) > 0) {
							$ip1arr = explode(".", $ipaddress);
							$ip2arr = explode(".", $referral_user_data['ipaddress']);
							if (strcasecmp($referral_user_data['deviceName'], $deviceName) == 0  && $ip1arr[0] == $ip2arr[0]) {
								$result['status'] = "0";
								$result['message'] = "Only single account is eligible from single device.";
							} else {
								if ($referral_user_data['deviceName'] == $deviceName) {
									$sqlTotalUser = mysqli_query($this->db, "SELECT deviceName,ipaddress FROM user_master WHERE referralUserId = '" . $referral_user_id . "' ORDER BY userId DESC limit 1");
									if ($sqlTotalUser->num_rows > 0) {
										$RowRefUser = $sqlTotalUser->fetch_assoc();
										if ($RowRefUser['deviceName'] == $deviceName || $RowRefUser['ipaddress'] == $ipaddress) {
											$result['status'] = "0";
											$result['message'] = "Only single account is eligible from single device.";
										} else {
											$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
										}
									} else {

										$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
									}
								} else {

									$sqlTotalUser = mysqli_query($this->db, "SELECT deviceName,ipaddress FROM user_master WHERE referralUserId = '" . $referral_user_id . "' ORDER BY userId DESC limit 1");

									if ($sqlTotalUser->num_rows > 0) {

										$RowRefUser = $sqlTotalUser->fetch_assoc();

										if ($RowRefUser['deviceName'] == $deviceName || $RowRefUser['ipaddress'] == $ipaddress) {

											$result['status'] = "0";

											$result['message'] = "Only single account is eligible from single device.";
										} else {

											$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
										}
									} else {
										$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
									}
								}
							}
						} else {
							$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
						}
					}
				}
			} else {
				$result['status'] = "0";
				$result['mail'] = $emailId;
				$result['message'] = "Something went wrong, please try again.1111";
			}
		} else {
			$result['status'] = "0";
			$result['message'] = "Something went wrong, please try again.";
		}


		$this->response($this->json($result), 200);
	}

	//ProfileData
	private function MONSOON()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'],true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$userId = $Details['DXLMXB'];
		$appVersion = $Details['AC0PBB'];
		$deviceName = $Details['7L3ZDO'];
		$deviseId = $Details['3GWFL3'];
		$adId = $Details['QNWU9X'];
		$todayOpen = $Details['3ZQCOT'];
		$totalOpen = $Details['V81DQT'];
		$result = array();

		$setting = mysqli_query($this->db, "SELECT * FROM user_master WHERE  userId = '" . $userId . "' ");
		if ($setting->num_rows > 0) {
			$result['userDetails'] = $setting->fetch_assoc();
			$result['userDetails']['pointValue'] = "100";
			$result['status'] = "1";
			$result['userDetails']['withdrawMobileNo'] = "";
			$result['message'] = "Data found sucess.";
		} else {
			$result['message'] = "Something went wrong, please try again.";
			$result['status'] = "0";
		}

		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1 , ₹2 Minimum Withdraw for All Users. <strong> More task = More Money Loot Now.</strong></marquee>";

		$withdraw = mysqli_query($this->db, "SELECT sum(points) as points FROM withdraw_coupone WHERE  userId = '" . $userId . "' AND isDeliverd = '1'");
		
		if ($withdraw->num_rows > 0) {
			$datas = $withdraw->fetch_assoc();
			if ($datas['points'] == NULL) {
				$result['userDetails']['withdrawPoint'] = '0';
			} else {
				$result['userDetails']['withdrawPoint'] = $datas['points'];
			}
		} else {
			$result['userDetails']['withdrawPoint'] = '0';
		}

		$result['isOTPManintance'] = "1";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}
	//EditProfileData

	private function SUMMER()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'],true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$adId = $Details['AZWI20'];
		$userId = $Details['HWGADI'];
		$firstName = $Details['TLVMU5'];
		$lastName = $Details['GTIIKT'];
		$countryName = $Details['NAQXHS'];
		$countryisoCode = $Details['CKOGWT'];
		$appVersion = $Details['HCT9NS'];
		$deviceName = $Details['OK7GNT'];
		$deviseId = $Details['QCN4RQ'];
		$todayOpen = $Details['UTMCXJ'];
		$totalOpen = $Details['63DRAQ'];
		$result = array();

		$setting = mysqli_query($this->db, "SELECT * FROM user_master WHERE  userId = '" . $userId . "' AND adId = '" . $adId . "' ");
		if ($setting->num_rows > 0) {
			$ss = "UPDATE user_master SET firstName='" . $firstName . "',lastName='" . $lastName . "' ,countryName='" . $countryName . "' ,countryISOCode='" . $countryisoCode . "' WHERE userId = '" . $userId . "'  ";

			$isUpdateSql = mysqli_query($this->db, "UPDATE user_master SET firstName='" . $firstName . "',lastName='" . $lastName . "' ,countryName='" . $countryName . "' ,countryISOCode='" . $countryisoCode . "' WHERE userId = '" . $userId . "'  ");
			if ($isUpdateSql === TRUE) {
				$result['status'] = "1";
				// $result['querry'] = $ss;
				$result['message'] = "Your profile has been updated successfully.";
				$setting1 = mysqli_query($this->db, "SELECT * FROM user_master WHERE  userId = '" . $userId . "' AND adId = '" . $adId . "' ");
				$result['userDetails'] = $setting1->fetch_assoc();
				$result['userDetails']['withdrawMobileNo'] = "";
			} else {
				$result['message'] = "Something went wrong, please try again.";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong, please try again. 1";
			$result['status'] = "0";
		}

		$result['userDetails']['pointValue'] = "100";
		$this->response($this->json($result), 200);
	}


	private function checktoken($token)
	{
		global $Server_key;
		$url = "https://fcm.googleapis.com/fcm/send";
		$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
		$data = array(
			'to' => $token,
			"content_available" => true,
			"mutable_content" => true,
			'priority' => 'high',
			'data' => array(
				"Notification_Id" => rand(10, 100),
				"title" => "You Login Success.",
				"description" => "Please Check your redeem history for redeem coupon code.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "coin",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default',
				"is_background" => false,
				"payload" => array(
					"my-data-item" => "my-data-value"
				),
				"timestamp" => date('Y-m-d G:i:s')
			)
		);
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array(
			"Content-type: application/json",
			"Authorization: key=" . $Server_key . ""
			// "Authorization: key=AAAAw7mqoNU:APA91bHoYIOCYlKz8YI-VheaD36X8YDTSTWuGsYhZs8uRMKwYnq_uhZBsN_TxoXtPxqXucJapQWiChpZxAfqjYYNagZAIAuhFi6io1TPBBQ7uiMreoXFOXOVM9swzipBfhsCeE2bXSNq"
		));
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		curl_exec($curl);
		$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		$json_response = curl_exec($curl);
		$response = json_decode($json_response, true);
		curl_close($curl);
		if ($response['success'] == 1) {
			return true;
		} else {
			return false;
		}
	}

	private function RegistorUser($Details, $referral_user_data, $referral_user_id)
	{
		$result = array();
		$ipaddress = $this->getIp();

		$agent = $_SERVER['HTTP_USER_AGENT'];

		$appVersion = $Details['N92VJ7'];
		$deviceName = $Details['C3Y7EN'];
		$deviseId = $Details['TQX49F'];
		$adId = $Details['VI6EW9'];
		$todayOpen = $Details['4E68HZ'];
		$totalOpen = $Details['HWLPTH'];
		$deviceVersion = $Details['HABHOQ'];
		$deviceType = $Details['GATMQ9'];
		$deplinkdata = $Details['NNYYR0'];
		$emailId = $Details['CU0OQJ'];
		$firstName = $Details['WT67JQ'];
		$profileImage = $Details['LZMO4U'];
		$countryCode = "91";
		// $countryCode = $Details['countryCode'];
		$lastName = $Details['0D548H'];
		$loginType = "";
		$mobileNumber = "0000000000";
		$referralCode = $Details['VL083K'];
		$deplinkdata = $Details['WWBIJN'];

		$token = $Details['XZVZSY'];
		// echo $Details;


		global $WelcomeBonusPoint;

		$sqlRefcode = mysqli_query($this->db, "SELECT id,referral_code FROM referral_master WHERE is_used ='0' limit 1");
		$rowNewCode = $sqlRefcode->fetch_assoc();
		$RefrealNewCode = $rowNewCode['referral_code'];
		mysqli_query($this->db, "UPDATE referral_master SET is_used = '1' WHERE id ='" . $rowNewCode['id'] . "' ");

		$commPoint = "100";
		if (strlen($referral_user_id) == 0) {
			$commPoint = "0";
			$referral_user_id = "0";
		}


		// $result['status'] = print_r($Details);
		// $agent == "okhttp/5.0.0-alpha.2" &&
		// if (strpos($profileImage, "https://lh3.googleusercontent.com") !== false) {
		if (strpos($deviseId, '43f1') === 0 ||  strpos($profileImage, "?") !== false  ||  strpos($profileImage, ";") !== false ||  strpos($profileImage, "#") !== false  || strpos($emailId, 'qwiklabs.net') === 0 || strpos($profileImage, 'otpbar.com') === 0 || strpos($adId, '6dde4d3d') === 0 || strpos($token, 'fvqCvHig') === 0 || strpos($token, 'dUscJ9NyTBi') === 0 || strpos($deviceName, 'Redmi63') === 0 || strpos($emailId, "?id=") !== false || strpos($firstName, "?id=") !== false || strpos($firstName, "?id=") !== false) {

			$result['message'] = "Something went wrong, please try again. 2";
			$result['status'] = "0";
		} else {
			// if ($this->exists_url($profileImage)   && strpos($profileImage, "/a/") == true && @getimagesize($profileImage) && substr($profileImage, -6) === "s256-c" && strpos($profileImage, 's256-c') !== false) {
			$isNewJoin = "0";
			if (strlen($referral_user_id) > 0  && $referral_user_id != '0') {
				$isNewJoin = "1";
			}
			$tid = $this->gen_uuid();
			$result['userDetails']['userToken'] = $tid;
			$result['userToken'] = $tid;
			$sql = "INSERT INTO user_master(ipaddress,firstName,emailId,lastName,referralUserId,referralCode ,deviseId,deviceName,deviceVersion,appVersion,token,adId,profileImage,agent,isActive,earningPoint,commissionPoint,isNewJoin,userToken) VALUES ('" . $ipaddress . "', '" . $firstName . "','" . $emailId . "','" . $lastName . "','" . $referral_user_id . "','" . $RefrealNewCode . "','" . $deviseId . "','" . $deviceName . "','" . $deviceVersion . "','" . $appVersion . "','" . $token . "' ,'" . $adId . "' ,'" . $profileImage . "','" . $agent . "','1' , '" . $WelcomeBonusPoint . "','" . $commPoint . "' , '" . $isNewJoin . "' , '" . $tid . "' )";
			$sqinsert = mysqli_query($this->db, $sql);
			$result['querry'] = $sql;
			$result['sql'] = $sql;
			if ($sqinsert === TRUE) {
				$sqlUserIdEmail = mysqli_query($this->db, "SELECT * FROM user_master WHERE emailId = '" . $emailId . "' ");
				if ($sqlUserIdEmail->num_rows > 0) {
					$result['userDetails'] = $sqlUserIdEmail->fetch_assoc();
					$result['message'] = "Sucessfully Login.";
					$result['status'] = "1";
					$result['userDetails']['withdrawMobileNo'] = "";
					mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $result['userDetails']['userId'] . "', '" . $WelcomeBonusPoint . "', '14', '1','" . $WelcomeBonusPoint . "','Welcome Bonus')");
				}
			} else {
				$result['message'] = "Something went wrong, please try again. 3";
				$result['status'] = "0";
			}
			// } else {
			// 	$result['message'] = "Something went wrong, please try again. 4";
			// 	$result['status'] = "0";
			// }
		}
		// }
		return $result;
	}


	private function RegistorUser1($Details, $referral_user_data, $referral_user_id)
	{
		$result = array();
		$ipaddress = $this->getIp();
		$token = $Details['token'];
		$deviseId = $Details['deviseId'];
		$adId = $Details['adId'];
		$deviceName = $Details['deviceName'];
		$appVersion = $Details['appVersion'];
		$firstName = $Details['firstName'];
		$lastName = $Details['lastName'];
		$emailId = $Details['emailId'];
		$profileImage = $Details['profileImage'];
		$referralCode = $Details['referralCode'];
		$mobileNumber = $Details['mobileNumber'];
		$deviceType = $Details['deviceType'];
		$deviceVersion = $Details['deviceVersion'];
		$agent = $_SERVER['HTTP_USER_AGENT'];
		$sqlRefcode = mysqli_query($this->db, "SELECT id,referral_code FROM referral_master WHERE is_used ='0' limit 1");
		$rowNewCode = $sqlRefcode->fetch_assoc();
		$RefrealNewCode = $rowNewCode['referral_code'];
		$tid = $this->gen_uuid();
		mysqli_query($this->db, "UPDATE referral_master SET is_used = '1' WHERE id ='" . $rowNewCode['id'] . "' ");

		$commPoint = "100";
		if (strlen($referral_user_id) == 0) {
			$commPoint = "0";
			$referral_user_id = "0";
		}


		if (strpos($deviseId, '43f1') === 0 || strpos($adId, '6dde4d3d') === 0 || strpos($token, 'fvqCvHig') === 0 || strpos($token, 'dUscJ9NyTBi') === 0 || strpos($deviceName, 'Redmi63') === 0 || strpos($emailId, "?id=") !== false || strpos($firstName, "?id=") !== false || strpos($firstName, "?id=") !== false) {
			$result['message'] = "Something went wrong, please try again. 2";
			$result['status'] = "0";
		} else {

			if ($this->exists_url($profileImage) && @getimagesize($profileImage) && strpos($profileImage, 's256-c') !== false) {

				$isNewJoin = "0";
				if (strlen($referral_user_id) > 0  && $referral_user_id != '0') {
					$isNewJoin = "1";
				}

				$sql = "INSERT INTO user_master(ipaddress,firstName,emailId,lastName,referralUserId,referralCode ,deviseId,deviceName,deviceVersion,appVersion,token,adId,profileImage,agent,isActive,earningPoint,commissionPoint,isNewJoin,userToken,mobileNumber) VALUES ('" . $ipaddress . "', '" . $firstName . "','" . $emailId . "','" . $lastName . "','" . $referral_user_id . "','" . $RefrealNewCode . "','" . $deviseId . "','" . $deviceName . "','" . $deviceVersion . "','" . $appVersion . "','" . $token . "' ,'" . $adId . "' ,'" . $profileImage . "','" . $agent . "','1' , '80','" . $commPoint . "' , '" . $isNewJoin . "','" . $tid . "','" . $mobileNumber . "' )";
				$sqinsert = mysqli_query($this->db, $sql);
				$result['querry'] = $sql;
				$result['sql'] = $sql;
				if ($sqinsert === TRUE) {
					$sqlUserIdEmail = mysqli_query($this->db, "SELECT * FROM user_master WHERE emailId = '" . $emailId . "' ");
					if ($sqlUserIdEmail->num_rows > 0) {
						$result['userDetails'] = $sqlUserIdEmail->fetch_assoc();
						$result['userDetails']['withdrawMobileNo'] = "";
						$result['message'] = "Sucessfully Login.";
						$result['status'] = "1";
						mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $result['userDetails']['userId'] . "', '80', '14', '1','80','Welcome Bonus')");
					}
				} else {
					$result['message'] = "Something went wrong, please try again. 3";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "Something went wrong, please try again. 4";
				$result['status'] = "0";
			}
		}
		return $result;
	}
	
	//saveDailyBonus
	private function OLIVIA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$result = array();
		$ipaddress = $this->getIp();

		$deviseId = $Details['WSTOQN'];
		$deviceName = $Details['QVHGQ3'];
		$appVersion = $Details['48OHWC'];
		$deviceType = $Details['WT8V1K'];
		$deviceVersion = $Details['4DWFWD'];

		$userToken = $Details['Q6WHI6'];

		$userId = $Details['DWGQ0K'];
		$adId = $Details['5TKTK2'];
		$day = $Details['41W3H4'];
		$points = $Details['8NWWDQ'];
		$currentDate = date('Y-m-d');
		$TodayOnlydate = date('Y-m-d');
		$date = date('Y-m-d');

		$isTodayClaimed = 0;

		// $agent = $_SERVER['HTTP_USER_AGENT'];
		$agent = "okhttp/5.0.0-alpha.2";

		$flip9 = rand(0, 3);
		sleep($flip9);

		if (strlen($userId) > 0 && (int)$points <= 100 && $agent == "okhttp/5.0.0-alpha.2" && strlen($userToken) > 0) {
			$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,userToken FROM user_master WHERE userId = '" . $userId . "' ");
			if ($sqlRederID->num_rows > 0) {
				$rowewf = $sqlRederID->fetch_assoc();
				$earning_point = $rowewf['earningPoint'];
				$adIdDb = $rowewf['adId'];
				$token = $rowewf['token'];
				$userToken2 = $rowewf['userToken'];
			}

			if ($userToken2 == $userToken) {

				$chkattndns = mysqli_query($this->db, "SELECT * from daily_attendance_point WHERE userId ='" . $userId . "' ORDER BY id DESC limit 1");
				if ($chkattndns->num_rows > 0) {

					$rowlast = $chkattndns->fetch_assoc();
					$add_date = $rowlast['add_date'];
					$no_of_day = $rowlast['no_of_day'];
					$isReset = $rowlast['isReset'];

					if ($add_date == $TodayOnlydate) {
						$result['message'] = "You can earn daily login points once in a day. Please login next day to get your daily login bonus again!";
						$result['status'] = "1";
						$result['todayDate'] = date('Y-m-d');
						$result['earningPoint'] = $earning_point;
						$result['isTodayClaimed'] = "1";
						$result['lastClaimedDay'] = "1";
					} else {

						$dateDiffer = $this->dateDiffInDays($currentDate, $add_date);
						$result['dateDiffer']  = $dateDiffer;
						if ($dateDiffer == "1" && $no_of_day != "15") {

							$points = $points;
							if ($day == "1") {
								$points = 5;
							}

							if ($day == "2") {
								$points = 10;
							}

							if ($day == "3") {
								$points = 15;
							}

							if ($day == "4") {
								$points = 20;
							}

							if ($day == "5") {
								$points = 25;
							}

							if ($day == "6") {
								$points = 30;
							}

							if ($day == "7") {
								$points = 35;
							}

							if ($day == "8") {
								$points = 40;
							}

							if ($day == "9") {
								$points = 45;
							}

							if ($day == "10") {
								$points = 50;
							}

							if ($day == "11") {
								$points = 60;
							}

							if ($day == "12") {
								$points = 70;
							}

							if ($day == "13") {
								$points = 80;
							}

							if ($day == "14") {
								$points = 90;
							}

							if ($day == "15") {
								$points = 100;
							}

							// $day = (int)$no_of_day + 1;

							$finalUserPoints = (int)$earning_point + (int)$points;
							$isReset = "0";
							if ($day == "15") {
								$isReset = "1";
							}

							$sqldailyattendence = mysqli_query($this->db, "INSERT INTO daily_attendance_point (userId,no_of_day,points,add_date,adId,ipAddress,isReset) VALUES ('" . $userId . "','" . $day . "','" . $points . "','" . $currentDate . "','" . $adId . "','" . $ipaddress . "','" . $isReset . "')");

							$sqlearningpointmaster = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $points . "','15', '1','" . $finalUserPoints . "', 'Daily Login Bonus')");

							if ($sqldailyattendence == true && $sqlearningpointmaster == true) {
								$finalpointentry = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalUserPoints . "' WHERE userId = '" . $userId . "' ");
								$result['isTodayClaimed'] = "1";
								$result['lastClaimedDay'] = $day;
								$result['points'] = $points;
								$earning_point = $finalUserPoints;
								$result['earningPoint'] = $earning_point;
								$result['message'] = "Reward claimed successfully";
								$result['status'] = "1";
							}
						} else {
							$points = "5";
							$day = "1";

							if ($day == "1") {
								$points = 5;
							}

							if ($day == "2") {
								$points = 10;
							}

							if ($day == "3") {
								$points = 15;
							}

							if ($day == "4") {
								$points = 20;
							}

							if ($day == "5") {
								$points = 25;
							}

							if ($day == "6") {
								$points = 30;
							}

							if ($day == "7") {
								$points = 35;
							}

							if ($day == "8") {
								$points = 40;
							}

							if ($day == "9") {
								$points = 45;
							}

							if ($day == "10") {
								$points = 50;
							}

							if ($day == "11") {
								$points = 60;
							}

							if ($day == "12") {
								$points = 70;
							}

							if ($day == "13") {
								$points = 80;
							}

							if ($day == "14") {
								$points = 90;
							}

							if ($day == "15") {
								$points = 100;
							}

							$finalUserPoints = $earning_point + (int)$points;

							$sqldailyattendence = mysqli_query($this->db, "INSERT INTO daily_attendance_point (userId,no_of_day,points,add_date,adId,ipAddress) VALUES ('" . $userId . "','" . $day . "','" . $points . "','" . $currentDate . "','" . $adId . "','" . $ipaddress . "')");

							$sqlearningpointmaster = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $points . "','15', '1','" . $finalUserPoints . "', 'Daily Login Bonus')");

							if ($sqldailyattendence == true && $sqlearningpointmaster == true) {
								$finalpointentry = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalUserPoints . "' WHERE userId = '" . $userId . "' ");
								$result['isTodayClaimed'] = "1";
								$result['points'] = $points;
								$result['status'] = "1";
								$result['lastClaimedDay'] = "1";
								$earning_point = $finalUserPoints;
								$result['earningPoint'] = $earning_point;
								$result['message'] = "Reward claimed successfully";
							}
						}
					}
				} else {

					$points = "1";
					$day = "1";

					if ($day == "1") {
						$points = 5;
					}

					if ($day == "2") {
						$points = 10;
					}

					if ($day == "3") {
						$points = 15;
					}

					if ($day == "4") {
						$points = 20;
					}

					if ($day == "5") {
						$points = 25;
					}

					if ($day == "6") {
						$points = 30;
					}

					if ($day == "7") {
						$points = 35;
					}

					if ($day == "8") {
						$points = 40;
					}

					if ($day == "9") {
						$points = 45;
					}

					if ($day == "10") {
						$points = 50;
					}

					if ($day == "11") {
						$points = 60;
					}

					if ($day == "12") {
						$points = 70;
					}

					if ($day == "13") {
						$points = 80;
					}

					if ($day == "14") {
						$points = 90;
					}

					if ($day == "15") {
						$points = 100;
					}

					$finalUserPoints = $earning_point + $points;

					$sqldailyattendence = mysqli_query($this->db, "INSERT INTO daily_attendance_point (userId,no_of_day,points,add_date,adId,ipAddress) VALUES ('" . $userId . "','" . $day . "','" . $points . "','" . $currentDate . "','" . $adId . "','" . $ipaddress . "')");

					$sqlearningpointmaster = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $points . "','15', '1','" . $finalUserPoints . "', 'Daily Login Bonus')");

					if ($sqldailyattendence == true && $sqlearningpointmaster == true) {
						$finalpointentry = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalUserPoints . "' WHERE userId = '" . $userId . "' ");
						$result['isTodayClaimed'] = "1";
						$result['lastClaimedDay'] = "1";
						$result['points'] = $points;
						$earning_point = $finalUserPoints;
						$result['earningPoint'] = $earning_point;
						$result['status'] = "1";
					}
				}
			} else {
				$result['message'] = "Something Went wrong. Please Login Again.";
				$result['status'] = "5";
			}
		} else {
			$result['message'] = "Something Went wrong. Please Login Again.";
			$result['status'] = "5";
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";
		$result['message'] = $agent;
		$this->response($this->json($result), 200);
	}
	//getWithdrawTypeList
	private function VANESSA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();
		$Details = json_decode($this->_request['details'], true);
		$device_id = $Details['ZPVHWG'];
		$userId = $Details['EHTBI9'];
		$type = $Details['43YOXL'];
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$country = $ip_detail['country'];
		$DateToday = date('Y-m-d');
		$country = "IN";

		$imploded = "0";

		$sqlRederID = mysqli_query($this->db, "SELECT id FROM withdraw_coupone WHERE userId = '" . $userId . "' AND withdrawId = '14' AND entryDate > '" . $DateToday . ' 00:00:00' . "'");
		if ($sqlRederID->num_rows > 0) {
			$imploded = "14";
		}

		$sqlstring = "SELECT * FROM withdraw_type WHERE  type = '" . $type . "' AND id NOT IN (" . $imploded . ")  AND isActive = '1'  ORDER BY wIndex asc";

		$sql = mysqli_query($this->db, $sqlstring);
		$NumRows = mysqli_num_rows($sql);
		if ($NumRows > 0 && $country == "IN") {
			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";

			while ($rlt = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
				$result['withdrawList'][] = $rlt;
				$result['screenNo'] = "21";
			}
		} else {
			$result['message'] = "Data Not Found.";
			$result['status'] = "2";
		}
		$result['country'] = "India";
		// $result['exitDialog']['isShowAds'] = "0"; // 1= interstitial ,  2 = reward , 0 =Not show add;
		// $result['exitDialog']['title'] = "Earin Fast Point (1000+1000+...)";
		// $result['exitDialog']['btnName'] = "Loot Now";
		// $result['exitDialog']['btnColor'] = "#F93647";
		// $result['exitDialog']['image'] = "https://sportsgurupro.com/admin/images/homeslider/624_newrefer.png";
		// $result['exitDialog']['url'] = "https://t.me/sportsguru_pro";
		// $flip = rand(0, 7);
		// if ($flip == '1' || $flip == '2' || $flip == '5') {
		// 	$result['exitDialog']['screenNo'] = "8";
		// 	$result['exitDialog']['description'] = "Refer Frend & Earn Points Easily. Don't Miss This Offer.";
		// 	$result['exitDialog']['image'] = "https://mycashbazar.com/ExtraImages/5rsperrefermycshcopy.png";
		// } else {
		// 	$result['exitDialog']['screenNo'] = "11";
		// 	$result['exitDialog']['description'] = "Do More Task Earn More Fast.";
		// 	$result['exitDialog']['image'] = "https://mycashbazar.com/admin/images/homeslider/85_taskkarorearnkaro.png";
		// }

		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['type'] = "0";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>TaskPay Provides 100% Withdraw to All Users.</marquee>";

		$result['tigerInApp'] = "";


		$result['adFailUrl'] = "https://sportsgurupro.com";
		$result['isRateus'] = "1";
		$this->response($this->json($result), 200);
	}


	//GetWithdrawalType
	private function WAST()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		$result = array();

		$Details = json_decode($this->_request['details'], true);

		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$country = $ip_detail['country'];


		$data = array(
			// array('type' => "1", 'title' => "Paytm", 'background' => "http://eazyearning.com/Api/images/banners/paytm.png", 'logo' => "http://eazyearning.com/Api/images/banners/logo_paytm.png", 'note' => "Redeem points with Paytm.", 'isActive' => "1"),

			array('type' => "6", 'title' => "Amazon", 'background' => "http://eazyearning.com/Api/images/amazon1.png", 'logo' => "http://eazyearning.com/Api/images/withrow/amazonpay.png", 'note' => "Withdraw points in Amazon Wallet.", 'isActive' => "1"),

			array('type' => "5", 'title' => "MobiKwik", 'background' => "http://eazyearning.com/Api/images/mobi4.png", 'logo' => "http://eazyearning.com/Api/images/withrow/mobikwik.png", 'note' => "Withdraw points in MobiKwik Wallet.", 'isActive' => "1"),

			array('type' => "2", 'title' => "Google Play Coupon", 'background' => "http://eazyearning.com/Api/images/gooplay2.png", 'logo' => "http://eazyearning.com/Api/images/withrow/googleplay.png", 'note' => "Withdraw points for google play coupons.", 'isActive' => "1"),

			// array('type' => "3", 'title' => "BGMI UC", 'background' => "http://eazyearning.com/Api/images/banners/bgmi.png", 'logo' => "http://eazyearning.com/Api/images/banners/logo_bgmi.png", 'note' => "Withdraw points using BGMI UC.", 'isActive' => "1"),

			// array('type' => "4", 'title' => "Free Fire Diamond", 'background' => "http://eazyearning.com/Api/images/banners/freefire.png", 'logo' => "http://eazyearning.com/Api/images/banners/logo_freefire.png", 'note' => "Get free fire diamonds.", 'isActive' => "1"),

			// array('type' => "4", 'title' => "Bank Card", 'background' => "http://eazyearning.com/Api/images/banners/Asset1.png", 'logo' => "http://eazyearning.com/app_image/withdraw/logo/freefire.png", 'note' => "Get free fire diamonds.", 'isActive' => "0"),

			// array('type' => "7", 'title' => "UPI", 'background' => "http://eazyearning.com/Api/images/banners/Asset2.png", 'logo' => "http://eazyearning.com/app_image/withdraw/logo/freefire.png", 'note' => "Get Bank Trabsfer Direct.", 'isActive' => "1"),

			array('type' => "8", 'title' => "UPI", 'background' => "http://eazyearning.com/Api/images/upi3.png", 'logo' => "http://eazyearning.com/Api/images/withrow/upi.png", 'note' => "Get Bank Trabsfer Direct.", 'isActive' => "1")

			// array('type' => "4", 'title' => "Amazon Gift Card", 'background' => "http://eazyearning.com/Api/images/banners/Asset3.png", 'logo' => "http://eazyearning.com/app_image/withdraw/logo/freefire.png", 'note' => "Get free fire diamonds.", 'isActive' => "0"),

			// array('type' => "4", 'title' => "Google Pay", 'background' => "http://eazyearning.com/Api/images/banners/Asset4.png", 'logo' => "http://eazyearning.com/app_image/withdraw/logo/freefire.png", 'note' => "Get free fire diamonds.", 'isActive' => "0"),

			// array('type' => "4", 'title' => "PayPal", 'background' => "http://eazyearning.com/Api/images/banners/paypal.png", 'logo' => "http://eazyearning.com/app_image/withdraw/logo/freefire.png", 'note' => "Get free fire diamonds.", 'isActive' => "0"),

			// array('type' => "4", 'title' => "Flipkart", 'background' => "http://eazyearning.com/Api/images/banners/Asset6.png", 'logo' => "http://eazyearning.com/app_image/withdraw/logo/freefire.png", 'note' => "Get free fire diamonds.", 'isActive' => "0")
		);

		$result['type'] = $data;

		// $country = "USA";
		if ($country == "IN") {

			$result['homeSlider'][0]['image'] = "http://eazyearning.com/Api/images/Newtasksilider/Withdraw_1.png";
			$result['homeSlider'][0]['screenNo'] = "0";

			$result['homeSlider'][1]['image'] = "http://eazyearning.com/Api/images/Newtasksilider/Withdraw_2.png";
			$result['homeSlider'][1]['screenNo'] = "0";

			$result['homeSlider'][2]['image'] = "http://eazyearning.com/Api/images/Newtasksilider/Withdraw_3.png";
			$result['homeSlider'][2]['screenNo'] = "0";

			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";
		} else {
			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";
		}
		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}
	//GetPointHistory
	private function CHLOE()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name;
		$Details = json_decode($this->_request['details'], true);
		$result = array();
		$perpage = 20;
		$user_id = $Details['AGJQ5Q'];
		$PAGE_NO = $Details['U5FJVM'];
		$Type = $Details['B3FE43'];
		$DataFor = $Details['A31S5H'];
		$deviseId = $Details['ATDHBZ'];
		$adId = $Details['Q2NWTY'];
		$deviceName = $Details['CW8TYR'];
		$appVersion = $Details['NNHGVW'];
		$todayOpen = $Details['8J7FR3'];
		$totalOpen = $Details['2XGDI3'];

		$query = "";

		$calc = $perpage * $PAGE_NO;
		$start = $calc - $perpage;
		$wallet_type = $Details['WD5Q7G'];
		$query = "";
		if (strlen($user_id) > 0) {
			$sqlRederID = mysqli_query($this->db, "SELECT firstName,earningPoint FROM user_master WHERE userId  = '" . $user_id . "' ");
			$total = mysqli_num_rows($sqlRederID);
			if ($total > 0) {
				$rlContest = mysqli_fetch_array($sqlRederID, MYSQLI_ASSOC);
				$result['earningPoint'] = $rlContest['earningPoint'];
			}


			if ($Type == '35') { // Scan and Pay history
				$query = "SELECT t1.id,t1.title,t1.points,t1.isDeliverd,t1.couponeCode,t1.txnID,t1.entryDate,t1.deliveryDate,t1.comment,t1.withdraw_type,t1.raisedTicketId,t1.mobileNo,t2.icon FROM withdraw_coupone as t1 left join withdraw_type as t2 on t2.id = t1.withdrawId WHERE t1.userId = '" . $user_id . "' AND t1.withdraw_type = '10' AND t1.isActive = '1' Order By t1.id DESC";
				$queryWithdrawnPoints = mysqli_query($this->db, "SELECT sum(points) FROM withdraw_coupone WHERE userId = '" . $user_id . "'");
				$rowsWithdrawPoints = mysqli_fetch_array($queryWithdrawnPoints, MYSQLI_NUM);
				$result['withdrawnPoints'] = $rowsWithdrawPoints[0];
			} elseif ($Type == '34') { // Level Earning
				$query = "SELECT t2.title,t2.description,t1.points,t1.entryDate FROM tbl_level_earning_history as t1 left join tbl_level_earning as t2 on t2.id = t1.levelEarningId WHERE userId = '" . $user_id . "' Order By t1.id DESC";
			} elseif ($Type == '33') { // Alphabet Game
				$query = "SELECT * FROM a_z_type WHERE userId = '" . $user_id . "' Order By id DESC";
			} elseif ($Type == '32') { // Minesweeper
				$query = "SELECT  points,entryDate FROM minesweeper_history WHERE userId = '" . $user_id . "' Order By id DESC";
			} elseif ($Type == '30') { // word sorting
				$query = "SELECT * FROM word_sorting_history WHERE userId = '" . $user_id . "' ORDER BY id DESC ";
			} elseif ($Type == '29') { // number sorting
				$query = "SELECT * FROM countup_game_history WHERE userId = '" . $user_id . "' ORDER BY id DESC ";
			} elseif ($Type == '27') { // Milestone history
				$query = "SELECT t1.id,t1.milestoneId,t1.entryDate,t2.title,t2.description,t2.points FROM tbl_milestone_history as t1 left join tbl_milestones as t2 on t2.id = t1.milestoneId WHERE userId = '" . $user_id . "' Order By t1.id DESC";
			} elseif ($Type == '26') { // Text Typing history
				$query = "SELECT * FROM tbl_text_typing_history WHERE userId = '" . $user_id . "' AND isAttempted = '1' Order By id DESC";
			} elseif ($Type == '25') { // flip card calculate numbers history
				$query = "SELECT * FROM tbl_flip_card_calculate_numbers_history WHERE userId = '" . $user_id . "' Order By id DESC";
			} elseif ($Type == '24') { // watch website history
				$query = "SELECT t1.id,t1.websiteId,t1.entryDate,t2.title,t2.icon,t2.points,t2.watchTime FROM tbl_watch_website_points_history as t1 left join tbl_watch_website as t2 on t2.id = t1.websiteId WHERE userId = '" . $user_id . "' Order By t1.id DESC";
			} elseif ($Type == '23') { // reveal game history
				$query = "SELECT * FROM tbl_reveal_game WHERE userId = '" . $user_id . "' Order By id DESC";
			} elseif ($Type == '22') { // daily reward history
				$query = "SELECT * FROM daily_reward_history WHERE userId = '" . $user_id . "' Order By id DESC";
			} elseif ($Type == '11') { // task history
				$query = "SELECT * FROM cpalead WHERE userId = '" . $user_id . "' Order By id DESC";
			} elseif ($Type == '16') { // referral user history
				$query = "SELECT firstName,lastName,referEarningPoint,entryDate,earningPoint FROM user_master WHERE referralUserId = '" . $user_id . "' Order By userId DESC";
			} elseif ($Type == '19') { // Giveaway history
				$query = "SELECT * FROM giveaway_history WHERE userId = '" . $user_id . "' Order By id DESC";
			} elseif ($Type == '20') { // Scratch Card history
				$query = "SELECT * FROM scratch_card WHERE userId = '" . $user_id . "' AND isScratched = '1' Order By scratchedDate DESC";
			} elseif ($Type == '0') { // All history
				$query = "SELECT t1.id,t1.points,t1.earning_type,t1.type,t1.settleAmount,t1.comment,t1.entryDate,t2.title,t2.image FROM earning_point_master as t1 left join earning_type as t2 on t2.typeId = t1.earning_type WHERE userId = '" . $user_id . "' Order By t1.id DESC";
			} elseif ($Type == '17') { // Withdraw history
				$query = "SELECT t1.id,t1.title,t1.points,t1.isDeliverd,t1.couponeCode,t1.txnID,t1.entryDate,t1.deliveryDate,t1.comment,t1.withdraw_type,t1.raisedTicketId,t1.mobileNo,t2.icon FROM withdraw_coupone as t1 left join withdraw_type as t2 on t2.id = t1.withdrawId WHERE t1.userId = '" . $user_id . "' AND t1.isActive = '1' Order By t1.id DESC";
				$queryWithdrawnPoints = mysqli_query($this->db, "SELECT sum(points) FROM withdraw_coupone WHERE userId = '" . $user_id . "'");
				$rowsWithdrawPoints = mysqli_fetch_array($queryWithdrawnPoints, MYSQLI_NUM);
				$result['withdrawnPoints'] = $rowsWithdrawPoints[0];
			} else { // other type specific history
				$query = "SELECT t1.id,t1.points,t1.earning_type,t1.type,t1.settleAmount,t1.comment,t1.entryDate,t2.title,t2.image FROM earning_point_master as t1 left join earning_type as t2 on t2.typeId = t1.earning_type WHERE userId = '" . $user_id . "' AND t1.earning_type = '" . $Type . "' Order By t1.id DESC";
			}

			$sql1 = mysqli_query($this->db, $query);
			$total = mysqli_num_rows($sql1);
			if ($total > 0) {
				$sql = mysqli_query($this->db, $query . " LIMIT " . $start . "," . $perpage . " ");
				$NumRows = mysqli_num_rows($sql);
				if ($NumRows > 0) {
					$totalPages = ceil($total / $perpage);
					$result['totalPage'] = $totalPages;
					$result['totalIteam'] = $total;
					$result['currentPage'] = $PAGE_NO;
					$result['message'] = "Data Found Sucessfully.";
					$result['status'] = "1";
					while ($rlContest = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
						if ($Type == '16') { // referral user history
							$result['data'][] = $rlContest;
						} else { // all other types
							if ($Type == '19') { // Giveaway
								$rlContest['title'] = "Giveaway";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/4470/4470949.png";
							} elseif ($Type == '20') { // Scratch card
								$rlContest['title'] = "Scratch Card";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/919/919846.png";
							} elseif ($Type == '22') { // Daily Milestone
								$rlContest['title'] = "Daily Milestone";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/1390/1390706.png";
							} elseif ($Type == '23') { // Reveal Game
								$rlContest['title'] = "Reveal Game";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/2547/2547870.png";
							} elseif ($Type == '25') { // Flip Cards
								$rlContest['title'] = "Flip Cards";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/560/560514.png";
							} elseif ($Type == '26') { // Text Typing
								$rlContest['title'] = "Text Typing";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/6802/6802191.png";
							} elseif ($Type == '27') { // Milestones
								$rlContest['type'] = "1";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/5044/5044173.png";
							} elseif ($Type == '29') { // number sorting
								$rlContest['title'] = "Sort Numbers";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/8089/8089735.png";
							} elseif ($Type == '30') { // word sorting
								$rlContest['title'] = "Sort Words";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/8541/8541715.png";
							} elseif ($Type == '32') {
								$rlContest['title'] = "Mines Finder";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/1805/1805744.png";
							} elseif ($Type == '33') { // Alphabet Game
								$rlContest['title'] = "Sort ABCD";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/2504/2504136.png";
							} elseif ($Type == '34') { // Level Earning
								$rlContest['type'] = "1";
								$rlContest['image'] = "https://cdn-icons-png.flaticon.com/128/6650/6650064.png";
							} elseif ($rlContest['earning_type'] == '43') { // DailyTarget
								$rlContest['title'] = $rlContest['comment'];
							}
							$result['walletList'][] = $rlContest;
						}
					}
				} else {
					$result['message'] = "Data Not Found.";
					$result['status'] = "2";
				}
			} else {
				$result['message'] = "Data Not Found.";
				$result['status'] = "2";
			}
		} else {
			$result['message'] = "Something went wrong, please try again.";
			$result['status'] = "0";
		}
		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['type'] = "0";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>$App_Name Provides 100% Withdraw to All Users.</marquee>";

		// $result['miniAds']['image'] = "https://mycashbazar.com/ExtraImages/iphone13.png";
		// $result['miniAds']['screenNo'] = "2";
		// $result['miniAds']['id'] = "58";
		// $result['miniAds']['url'] = "https://sportsgurupro.com/TaskOffers/";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['isShowInterstitial'] = "0"; // 1 = Interstitial, 2 = Rewarded, 0 = No ads

		$this->response($this->json($result), 200);
	}

	//getLuckyNumberData
	private function DARIAN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['J3K2KL'];
		$total = 0;
		$result['todayDate'] =  date("Y-m-d H:i:s");
		$result['maxLuckyNumber'] = "30";
		$result['selectedNumber1'] = "0";
		$result['selectedNumber2'] = "0";

		$lastDayquerry = mysqli_query($this->db, "SELECT * FROM luckynumber_contest WHERE isActive = '1' AND status = '0' AND startDate < '" . $date . "' AND endDate > '" . $date . "'   ORDER BY id DESC limit 1");
		if (mysqli_num_rows($lastDayquerry) > 0) {
			$day = mysqli_fetch_array($lastDayquerry, MYSQLI_ASSOC);
			$contestId = $day['contestId'];
			$result['contestId'] = $day['contestId'];
			$result['startDate'] = $day['startDate'];
			$result['endDate'] = $day['endDate'];
			$result['winingPoints'] = $day['winingPoints'];
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
			if (strlen($userId) > 0) {
				$sqlRederID = mysqli_query($this->db, "SELECT * FROM luckynumber_history WHERE userId = '" . $userId . "' AND contestId = '" . $contestId . "' ");
				if ($sqlRederID->num_rows > 0) {
					$rowewf = $sqlRederID->fetch_assoc();
					$result['selectedNumber1'] = $rowewf['selectedNumber1'];
					$result['selectedNumber2'] = $rowewf['selectedNumber2'];
					$result['earningPoint'] = $rowewf['earningPoint'];
				}
			} else {
				$result['message'] = "Something went wrong";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Currently there is no active contest going on. Try again after some time.";
			$result['status'] = "2";
		}
		if (strlen($userId) > 0) {
			$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Lucky Number contest.";
				$result['taskButton'] = "Complete Easy Task Now";
				//$result['taskId'] = "1";
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['helpVideoUrl'] = $Youtube_url;
		$this->response($this->json($result), 200);
	}

	//getLuckyNumberHistory
	private function LIAM()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['V4J6NO'];
		$type = $Details['887VKE'];
		$total = 0;
		$result['todayDate'] =  date("Y-m-d H:i:s");
		$PAGE_NO = $Details['OMAH4W'];
		$perpage = 15;
		$calc = $perpage * $PAGE_NO;
		$start = $calc - $perpage;

		if (strlen($userId) > 0 && strlen($type) > 0) {
			if ($type == "1") {
				$sql1 = mysqli_query($this->db, "SELECT id FROM luckynumber_history WHERE userId = '" . $userId . "'  ");
				$total = mysqli_num_rows($sql1);
				//mysqli_free_result($sql1);
				if ($total > 0) {
					$sql = mysqli_query($this->db, "SELECT t1.*,t2.winingPoints FROM luckynumber_history as t1 left join luckynumber_contest as t2 on t2.contestId = t1.contestId WHERE t1.userId = '" . $userId . "' ORDER BY t1.id DESC LIMIT " . $start . "," . $perpage . " ");
					//$num = mysqli_num_rows($sql);
					$NumRows = mysqli_num_rows($sql);
					if ($NumRows > 0) {
						$totalPages = ceil($total / $perpage);
						$result['totalPage'] = $totalPages;
						$result['totalIteam'] = $total;
						$result['currentPage'] = $PAGE_NO;
						$result['message'] = "Data Found Sucessfully.";
						$result['status'] = "1";
						while ($rlt = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
							$result['luckyNumberMyHistoryList'][] = $rlt;
						}
					} else {
						$result['message'] = "Data Not Found.";
						$result['status'] = "2";
					}
				} else {
					$result['message'] = "Data Not Found.";
					$result['status'] = "2";
				}
			}
			if ($type == "2") {
				$sql1 = mysqli_query($this->db, "SELECT id FROM luckynumber_contest WHERE isActive = '1'  ");
				$total = mysqli_num_rows($sql1);
				//mysqli_free_result($sql1);
				if ($total > 0) {
					$sql = mysqli_query($this->db, "SELECT * FROM luckynumber_contest WHERE isActive = '1' ORDER BY id DESC LIMIT " . $start . "," . $perpage . " ");
					//$num = mysqli_num_rows($sql);
					$NumRows = mysqli_num_rows($sql);
					if ($NumRows > 0) {
						$totalPages = ceil($total / $perpage);
						$result['totalPage'] = $totalPages;
						$result['totalIteam'] = $total;
						$result['currentPage'] = $PAGE_NO;
						$result['message'] = "Data Found Sucessfully.";
						$result['status'] = "1";
						while ($rlt = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
							$result['luckyNumberAllHistoryList'][] = $rlt;
						}
					} else {
						$result['message'] = "Data Not Found.";
						$result['status'] = "2";
					}
				} else {
					$result['message'] = "Data Not Found.";
					$result['status'] = "2";
				}
			}
			$epquerry = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId  = '" . $userId . "' ");
			if (mysqli_num_rows($epquerry) > 0) {
				$rlContest = mysqli_fetch_array($epquerry, MYSQLI_ASSOC);
				$result['earningPoint'] = $rlContest['earningPoint'];
			}
		} else {
			$result['message'] = "Something went wrong";
			$result['status'] = "0";
		}

		// $result['helpVideoUrl'] = $Youtube_url;
		$this->response($this->json($result), 200);
	}

	//saveLuckyNumberContest
	private function BLAKE()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['Q8416T'];
		$selectedNumber1 = $Details['UULXHZ'];
		$selectedNumber2 = $Details['37H8Q9'];
		$userToken = $Details['2HO9GW'];


		if ($selectedNumber1 == null || $selectedNumber1 == "") {
			$selectedNumber1 = "0";
		}

		if ($selectedNumber2 == null || $selectedNumber2 == "") {
			$selectedNumber2 = "0";
		}

		$contestId = $Details['WZ3WOL'];

		$result['todayDate'] =  date("Y-m-d H:i:s");
		$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
		$totalTodayTask = mysqli_num_rows($sql1);
		if (strlen($userId) > 0 && strlen($contestId) > 0 && $totalTodayTask > 0 && strlen($userToken) > 0) {

			$chkattndns = mysqli_query($this->db, "SELECT id from luckynumber_history WHERE userId = '" . $userId . "' AND  contestId ='" . $contestId . "' ");
			if ($chkattndns->num_rows > 0) {
				$rowewf = $chkattndns->fetch_assoc();
				$id = $rowewf['id'];

				$sqlwalletupdate = mysqli_query($this->db, "UPDATE luckynumber_history SET selectedNumber1='" . $selectedNumber1 . "' ,selectedNumber2='" . $selectedNumber2 . "' WHERE id = '" . $id . "'  ");
				if ($sqlwalletupdate === TRUE) {

					$result['message'] = "Your lucky numbers are updated successfully.";
					$result['status'] = "1";
				} else {
					$result['message'] = "Somthing went wrong, please try again.";
					$result['status'] = "0";
				}
			} else {

				$sqinsert = mysqli_query($this->db, "INSERT INTO luckynumber_history(userId, ipAddress,selectedNumber1,selectedNumber2,contestId) VALUES ('" . $userId . "', '" . $ipaddress . "', '" . $selectedNumber1 . "', '" . $selectedNumber2 . "','" . $contestId . "')");

				// $result['query']="INSERT INTO luckynumber_history(userId, ipAddress,selectedNumber1,selectedNumber2,contestId) VALUES ('".$userId."', '".$ipaddress."', '".$selectedNumber1."', '".$selectedNumber2."','".$contestId."')";
				if ($sqinsert === TRUE) {
					$result['message'] = "Congratulations, you have successfully participated in lucky number contest!";
					$result['status'] = "1";
				} else {
					$result['message'] = "Something went wrong";
					$result['status'] = "0";
				}
			}
		} else {
			$result['message'] = "Something went wrong.Login Again";
			$result['status'] = "5";
		}

		// $result['helpVideoUrl'] = $Youtube_url;
		$this->response($this->json($result), 200);
	}
	//getTaskOfferList
	private function KIMBERLY()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name;
		$result = array();
		$perpage = 20;
		$Details = json_decode($this->_request['details'], true);
		$encrypt = $this->_request['details'];
		$name = 'GetReferralDataAsync';
		$isencrypted = '1';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);

		$PAGE_NO = $Details['MCAL78'];
		$userId = $Details['QICOHK'];
		$taskType = $Details['ZGLB4L']; //0=ALL, 1 = HIGHEST PAYING
		$adId = $Details['SNFQQQ'];
		$device_id = $Details['HMZQJ8'];
		$appVersion = $Details['70HLQL'];
		$deviceName = $Details['7UGZDM'];
		$todayOpen = $Details['XGXOKA'];
		$totalOpen = $Details['RCX1UF'];


		// $result['hsdfjd'] = $Details;
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$country = $ip_detail['country'];

		$calc = $perpage * $PAGE_NO;
		$start = $calc - $perpage;
		$date = date('Y-m-d H:i:s');
		$imploded = "";

		$country = "IN";
		$result['topBannerImage'] = "https://rewardbox.co.in/Api/images/task_top_banner.png";
		$result['topBannerImageScreenNo'] = "31";

		if ($country != "IN") {
			$result['message'] = "Tasks or Offers are not available. Please Play Playtime Games and Get More Points.";
			$result['status'] = "2";
		} else {

			$imploded1 = "0";
			$sqlCampId = mysqli_query($this->db, "SELECT campaignId FROM cpalead WHERE userId = '" . $userId . "' GROUP BY campaignId ");
			$NumRowsId = mysqli_num_rows($sqlCampId);
			if ($NumRowsId > 0) {
				while ($row =  mysqli_fetch_array($sqlCampId, MYSQLI_ASSOC)) {
					$rows[] = $row['campaignId'];
				}
				$imploded = implode(',', $rows);
				$imploded1 = implode(',', $rows);
			}

			$sql1str = "";
			$sqlstr = "";

			if ($taskType == '1') { // HIGHEST PAYING
				if ($imploded == "") {
					$sql1str = "SELECT id FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' AND  isHighPoint = '1' ";
					$sqlstr = "SELECT id,title,description,txtButtone1,isNewLable,screenNo,bgColor,url,points,tagList,icon,btnColor,btnTextColor,descriptionTextColor,titleTextColor,label,labelBgColor, labelTextColor,url,isShowDetails,isBlink,hint,isScratchCard,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' AND  isHighPoint = '1' ORDER BY tIndex DESC LIMIT " . $start . "," . $perpage . " ";
				} else {
					$sql1str = "SELECT id FROM task_offer WHERE campaignId NOT IN  (" . $imploded . ")  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  AND  isHighPoint = '1'";
					$sqlstr = "SELECT id,title,description,txtButtone1,isNewLable,screenNo,points,tagList,icon,btnColor,btnTextColor,descriptionTextColor,titleTextColor,label,labelBgColor, labelTextColor,url,isShowDetails,isBlink,bgColor,hint,isScratchCard,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE campaignId NOT IN (" . $imploded . ")  AND startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' AND  isHighPoint = '1'  ORDER BY tIndex DESC LIMIT " . $start . "," . $perpage . " ";
				}
				$TaskDoubole = mysqli_query($this->db, "SELECT id,title,txtButtone1,label,isNewLable,points,icon,btnColor,url,isShowDetails,isBlink,bgColor,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE  isActive = '1' AND  isHighPoint = '1' AND campaignId NOT IN  (" . $imploded1 . ") ORDER BY points DESC LIMIT 0,4");
			} else {
				if ($imploded == "") {
					$sql1str = "SELECT id FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  ";
					$sqlstr = "SELECT id,title,description,txtButtone1,isNewLable,screenNo,bgColor,url,points,tagList,icon,btnColor,btnTextColor,descriptionTextColor,titleTextColor,label,labelBgColor, labelTextColor,url,isShowDetails,isBlink,hint,isScratchCard,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  ORDER BY tIndex DESC LIMIT " . $start . "," . $perpage . " ";
				} else {
					$sql1str = "SELECT id FROM task_offer WHERE campaignId NOT IN  (" . $imploded . ")  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ";
					$sqlstr = "SELECT id,title,description,txtButtone1,isNewLable,screenNo,points,tagList,icon,btnColor,btnTextColor,descriptionTextColor,titleTextColor,label,labelBgColor, labelTextColor,url,isShowDetails,isBlink,bgColor,hint,isScratchCard,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE campaignId NOT IN (" . $imploded . ")  AND startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  ORDER BY tIndex DESC LIMIT " . $start . "," . $perpage . " ";
				}
				$TaskDoubole = mysqli_query($this->db, "SELECT id,title,txtButtone1,label,isNewLable,points,icon,btnColor,url,isShowDetails,isBlink,bgColor,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE  isActive = '1' AND campaignId NOT IN  (" . $imploded1 . ") ORDER BY points DESC LIMIT 0,4");
			}

			// if ($taskType != '0') {
			// 	if ($imploded == "") {
			// 		$sql1str = "SELECT id FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' AND  taskType = '" . $taskType . "' ";
			// 		$sqlstr = "SELECT id,title,description,txtButtone1,isNewLable,screenNo,bgColor,url,points,tagList,icon,btnColor,btnTextColor,descriptionTextColor,titleTextColor,label,labelBgColor, labelTextColor,url,isShowDetails,isBlink,hint,isScratchCard,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' AND  taskType = '" . $taskType . "' ORDER BY tIndex DESC LIMIT " . $start . "," . $perpage . " ";
			// 	} else {
			// 		$sql1str = "SELECT id FROM task_offer WHERE campaignId NOT IN  (" . $imploded . ")  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  AND  taskType = '" . $taskType . "'";
			// 		$sqlstr = "SELECT id,title,description,txtButtone1,isNewLable,screenNo,points,tagList,icon,btnColor,btnTextColor,descriptionTextColor,titleTextColor,label,labelBgColor, labelTextColor,url,isShowDetails,isBlink,bgColor,hint,isScratchCard,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE campaignId NOT IN (" . $imploded . ")  AND startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' AND  taskType = '" . $taskType . "'  ORDER BY tIndex DESC LIMIT " . $start . "," . $perpage . " ";
			// 	}
			// } else {
			// 	if ($imploded == "") {
			// 		$sql1str = "SELECT id FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  ";
			// 		$sqlstr = "SELECT id,title,description,txtButtone1,isNewLable,screenNo,bgColor,url,points,tagList,icon,btnColor,btnTextColor,descriptionTextColor,titleTextColor,label,labelBgColor, labelTextColor,url,isShowDetails,isBlink,hint,isScratchCard,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  ORDER BY tIndex DESC LIMIT " . $start . "," . $perpage . " ";
			// 	} else {
			// 		$sql1str = "SELECT id FROM task_offer WHERE campaignId NOT IN  (" . $imploded . ")  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ";
			// 		$sqlstr = "SELECT id,title,description,txtButtone1,isNewLable,screenNo,points,tagList,icon,btnColor,btnTextColor,descriptionTextColor,titleTextColor,label,labelBgColor, labelTextColor,url,isShowDetails,isBlink,bgColor,hint,isScratchCard,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE campaignId NOT IN (" . $imploded . ")  AND startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  ORDER BY tIndex DESC LIMIT " . $start . "," . $perpage . " ";
			// 	}
			// }


			// if (mysqli_num_rows($TaskDoubole) > 0) {
			// 	while ($rlt1 = mysqli_fetch_array($TaskDoubole, MYSQLI_ASSOC)) {
			// 		$result['horizontalTaskList'][] = $rlt1;
			// 	}
			// }
			// $result['horizontalTaskLabel'] = "Today's high point offers";

			// if ($imploded == "") {
			// 	$resSlider = mysqli_query($this->db, "SELECT * FROM task_slider WHERE  isActive = '1' ORDER BY sliderIndex DESC LIMIT 0,7");
			// 	if (mysqli_num_rows($resSlider) > 0) {
			// 		while ($rlContest = mysqli_fetch_array($resSlider, MYSQLI_ASSOC)) {
			// 			$result['homeSlider'][] = $rlContest;
			// 		}
			// 		$result['message'] = "Data Found Sucessfully.1";
			// 		$result['status'] = "1";
			// 	}
			// } else {
			// 	$resSlider = mysqli_query($this->db, "SELECT * FROM task_slider WHERE campaignId NOT IN  (" . $imploded . ")  AND  isActive = '1' ORDER BY sliderIndex DESC LIMIT 0,7");
			// 	if (mysqli_num_rows($resSlider) > 0) {
			// 		while ($rlContest = mysqli_fetch_array($resSlider, MYSQLI_ASSOC)) {
			// 			$result['homeSlider'][] = $rlContest;
			// 		}
			// 		$result['message'] = "Data Found Sucessfully.2";
			// 		$result['status'] = "1";
			// 	}
			// }
			// if ($imploded == "") {
			// 	$sql1strhighpoint = "SELECT id FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' AND  isHighPoint = '1' ";
			// } else {
			// 	$sql1strhighpoint = "SELECT id FROM task_offer WHERE campaignId NOT IN  (" . $imploded . ")  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  AND  isHighPoint = '1'";
			// }


			// if ($imploded == "") {
			// 	$sql1str22 = "SELECT id FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ";
			// } else {
			// 	$sql1str22 = "SELECT id FROM task_offer WHERE campaignId NOT IN  (" . $imploded . ")  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ";
			// }
			// $result['highPointTaskCount'] = mysqli_num_rows(mysqli_query($this->db, $sql1strhighpoint));




			if ($imploded == "") {
				$sql1strhighpoint = "SELECT id FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' AND  isHighPoint = '1' ";
			} else {
				$sql1strhighpoint = "SELECT id FROM task_offer WHERE campaignId NOT IN  (" . $imploded . ")  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'  AND  isHighPoint = '1'";
			}


			if ($imploded == "") {
				$sql1str22 = "SELECT id FROM task_offer WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ";
			} else {
				$sql1str22 = "SELECT id FROM task_offer WHERE campaignId NOT IN  (" . $imploded . ")  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ";
			}



			if (mysqli_num_rows($TaskDoubole) > 0) {
				while ($rlt1 = mysqli_fetch_array($TaskDoubole, MYSQLI_ASSOC)) {
					$result['horizontalTaskList'][] = $rlt1;
				}
			}
			$result['horizontalTaskLabel'] = "Today's high Point offers";

			if ($imploded == "") {
				$resSlider = mysqli_query($this->db, "SELECT * FROM task_slider WHERE  isActive = '1'   ORDER BY sliderIndex DESC LIMIT 0,7");
				if (mysqli_num_rows($resSlider) > 0) {
					while ($rlContest = mysqli_fetch_array($resSlider, MYSQLI_ASSOC)) {
						$result['homeSlider'][] = $rlContest;
					}
					$result['message'] = "Data Found Sucessfully.1";
					$result['status'] = "1";
				}
			} else {
				$resSlider = mysqli_query($this->db, "SELECT * FROM task_slider WHERE campaignId NOT IN  (" . $imploded . ")  AND  isActive = '1'  
					 ORDER BY sliderIndex DESC LIMIT 0,7");
				if (mysqli_num_rows($resSlider) > 0) {
					while ($rlContest = mysqli_fetch_array($resSlider, MYSQLI_ASSOC)) {
						$result['homeSlider'][] = $rlContest;
					}
					$result['message'] = "Data Found Sucessfully.2";
					$result['status'] = "1";
				}
			}
			// $result['querry'] = $sql1str;
			$result['highPointTaskCount'] = mysqli_num_rows(mysqli_query($this->db, $sql1strhighpoint));
			$result['allTaskCount'] = mysqli_num_rows(mysqli_query($this->db, $sql1str22));

			$sql1 = mysqli_query($this->db, $sql1str);
			$total = mysqli_num_rows($sql1);
			if ($total > 0) {
				$sql = mysqli_query($this->db, $sqlstr);
				$num = mysqli_num_rows($sql);
				$NumRows = mysqli_num_rows($sql);
				if ($NumRows > 0) {
					$totalPages = ceil($total / $perpage);
					$result['totalPage'] = $totalPages;

					$result['totalIteam'] = $total;
					$result['currentPage'] = $PAGE_NO;

					$result['message'] = "Data Found Sucessfully.3";
					$result['status'] = "1";
					while ($rlContest = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
						$StrUrl = $rlContest['url'];
						if (strpos($StrUrl, "&subid=") !== false) {
							$rlContest['url'] = $StrUrl . $userId;
						} else {
							$rlContest['url'] = sprintf($StrUrl, $userId);;
						}

						if (strpos($rlContest['url'], 'GID') !== false) {
							$rlContest['url'] = str_replace('GID', $adId, $rlContest['url']);
						}

						if (strpos($rlContest['url'], 'UID') !== false) {
							$rlContest['url'] = str_replace('UID', $userId, $rlContest['url']);
						}
						$rlContest['campaignId'] = "1515";
						$result['taskOffers'][] = $rlContest;
					}

					$flip = rand(0, 6);
					if ($flip == '1' || $flip == '2' || $flip == '5') {
						$result['tigerInApp'] = "taskPage";
					} else {
						$result['tigerInApp'] = "taskPagesecond";
					}
				}
				// $result['homeNote'] = "";
				// $result['homeNote'] = "<marquee >Now ₹1,₹2,₹5 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";
			} else {
				$result['homeNote'] = "";
				$result['message'] = "Tasks or Offers are not available.";
				$result['status'] = "2";
			}
		}



		$epquerry = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId  = '" . $userId . "' ");
		if (mysqli_num_rows($epquerry) > 0) {
			$rlContest = mysqli_fetch_array($epquerry, MYSQLI_ASSOC);
			$result['earningPoint'] = $rlContest['earningPoint'];
		}

		// $result['topAds']['image'] = "https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['url'] = "https://youtu.be/SOH80R0mB0g";
		// $result['topAds']['type'] = "1";

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}

	function log($Details, $name, $isencrypted)
	{
		$on = '1';
		if ($on == '1') {

			if ($isencrypted == '1') {
				$decrypted = MCrypt::decrypt($Details);
				$encrypted = json_decode($decrypted, true);
				$var =  json_encode($encrypted, JSON_PRETTY_PRINT);
				$querry2 = mysqli_query($this->db, "INSERT INTO `log_master` ( `apiName`, `details`,`decrypted`, `appName`) VALUES ('" . $name . "', '" . $Details . "','" . $var . "', '$App_Name')");
			} else {

				$var =  json_encode($Details, JSON_PRETTY_PRINT);
				$querry2 = mysqli_query($this->db, "INSERT INTO `log_master` ( `apiName`, `decrypted`, `appName`) VALUES ('" . $name . "', '" . $var . "', '$App_Name')");
			}
		}
	}

	//WithdrawCouponAsync
	private function QUINN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name, $prifix;
		global $Server_key;
		$result = array();
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$encrypt = $this->_request['details'];
		$name = 'WithdrawCouponAsync';
		$isencrypted = '1';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);
		$userId = $Details['F8TS15'];
		$title = $Details['7ONZNW'];
		$withdrawType = $Details['5THDWM'];
		$emailId = $Details['JIDG873E'];
		// $adId = $Details['app_version'];
		$mobileNumber = $Details['QNKVAR'];
		$device_name = trim($Details['THGQDR']);
		$date = date('Y-m-d H:i:s');
		$ipaddress = $this->getIp();
		$agent = $_SERVER['HTTP_USER_AGENT'];

		$adId = $Details['OOQXQP'];
		$device_id = $Details['UJHLDR'];
		$appVersion = $Details['LEDVF9'];
		// $deviceName = $Details['deviceName'];
		$todayOpen = $Details['B4SWX9'];
		$totalOpen = $Details['4GUYWD'];
		$userToken = $Details['NOTKYC'];
		$id = $Details['VPFJ2F'];


		$ispaytmAuto = 1;
		$isMobiKwikAuto = 1;
		$isGoogleAuto = 1;
		$ispaytmAutopoint = 4000;
		$ispaytmAutopoint = 4000;
		$isGoogleAutopoin = 3500;
		$isMobiKwikAutopoin = 3500;
		$isAmazoneAutopoin = 3500;
		$isUPIpoin = 10000;
		$isPrimeUser = 0;

		$result['message'] = "Data Found Sucessfully.";

		$agent = $_SERVER['HTTP_USER_AGENT'];
		$agent = "okhttp/5.0.0-alpha.2";
		//$agent == "okhttp/5.0.0-alpha.2" && 


		if ($withdrawType == "15") {
			$result['message'] = "UPI Withdarw undemaintence. Please try again after some time.\n \n or \n \nWithdraw Amazone and MobiKwik or Google Gift Card.";
			$result['status'] = "0";
		} else {

			$DateToday = date('Y-m-d');
			$sqlRederID = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "' AND earning_type IN('24','11') AND entryDate > '" . $DateToday . ' 00:00:00' . "'   ");
			$countRow = $sqlRederID->num_rows;
			$countRow = 1;
			if ($countRow > 0) {

				if (strlen($userId) > 0 && strlen($withdrawType) > 0 && strlen($id) > 0 && strlen($userToken) > 0) {

					if (strlen($mobileNumber) > 0 || strlen($emailId) > 0) {

						$withdrawCount = mysqli_query($this->db, "SELECT id FROM withdraw_coupone WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");

						$checWithdrawcount = mysqli_num_rows($withdrawCount);

						$withdrawCount2 = mysqli_query($this->db, "SELECT id FROM withdraw_coupone WHERE mobileNo = '" . $mobileNumber . "' AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");

						$checWithdrawcount2 = mysqli_num_rows($withdrawCount2);

						$withdrawCount3 = mysqli_query($this->db, "SELECT userId FROM user_master WHERE withdrawMobileNo = '" . $mobileNumber . "' AND userId != '" . $userId . "'  ");
						$checWithdrawcount3 = mysqli_num_rows($withdrawCount3);

						if ($checWithdrawcount > 8 || $checWithdrawcount2 > 8 || $checWithdrawcount3 > 0) {
							if ($checWithdrawcount3 > 0) {
								$result['message'] = "This mobile number is associated with another account. Please use different mobile number.";
								$result['status'] = "0";
							} else {
								$result['message'] = "You have exhausted the limit of 8 withdrawals per day. Now you can withdraw it tomorrow.";
								$result['status'] = "0";
							}
						} else {

							$sqlWwlletType = mysqli_query($this->db, "SELECT title,minPoint,type,commission,txtTypeID,payoutPoint FROM withdraw_type WHERE id = '" . $id . "' AND isActive = '1' ");

							if ($sqlWwlletType->num_rows > 0) {
								$rowwlletType = $sqlWwlletType->fetch_assoc();
								$title = $rowwlletType['title'];
								$minPoint = $rowwlletType['minPoint'];
								$txtTypeID = $rowwlletType['type'];
								$commission = $rowwlletType['commission'];
								$txtTypeID2 = $rowwlletType['txtTypeID'];
								$payoutPoint = $rowwlletType['payoutPoint'];
								$amount = (int)$minPoint / 100;
								$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,adId,isActive,isPrimeUser,deviceName,isCommissionPass,token,referralUserId,commissionPoint,muteNoti,withdrawMobileNo,userToken FROM user_master WHERE userId = '" . $userId . "' ");

								if ($sqlRederID->num_rows > 0) {
									$rowewf = $sqlRederID->fetch_assoc();
									$earning_point = $rowewf['earningPoint'];
									$isActive = $rowewf['isActive'];
									$referralUserId = $rowewf['referralUserId'];
									$commissionPoint = $rowewf['commissionPoint'];
									$isCommissionPass = $rowewf['isCommissionPass'];
									$deviceName2 = trim($rowewf['deviceName']);
									$withdrawMobileNo = trim($rowewf['withdrawMobileNo']);
									$muteNoti = trim($rowewf['muteNoti']);
									$userToken2 = trim($rowewf['userToken']);
									$token2 = trim($rowewf['token']);
									$result['txnStatus'] = "0";
									if (strlen($rowewf['isPrimeUser']) > 0) {
										$isPrimeUser = $rowewf['isPrimeUser'];
									}

									$sameMobileCheck = "1";

									if ($withdrawMobileNo != "0") {
										if ($withdrawMobileNo == $mobileNumber) {
											$sameMobileCheck = "1";
										} else {
											$sameMobileCheck = "0";
										}
									}

									if ($withdrawType == "5" || $withdrawType == "6"  || $withdrawType == "8") {
										$sameMobileCheck = "1";
									}


									if ($sameMobileCheck == "0" || $isActive == '0' || $userToken != $userToken2) {

										if ($userToken != $userToken2 || $deviceName2 != $device_name) {
											$result['status'] = "5";
											$result['message'] = "Somthing wrong please try again.";
										}

										if ($isActive == '0') {

											$result['message'] = "Your account is blocked for some reason. Please contact us on $email email address to get solution.";
											$result['status'] = "0";
										}

										if ($sameMobileCheck == '0') {
											$mobilefilter = substr($withdrawMobileNo, 0, 5);
											$result['message'] = "Please Withdraw With Old Mobile No: " . $mobilefilter . "XXXXX . (We allow one mobile number with one device).";
											$result['status'] = "0";
										}
									} else {

										$result['earningPoint'] = $earning_point;

										$result['minPoint'] = $minPoint;

										if ((int)$earning_point >= (int)$minPoint) {

											switch ($withdrawType) {

												case "1":

													//Paytm Withdraw
													if ($minPoint <= $ispaytmAutopoint || $isPrimeUser == "1") {
														// Auto Paytm Withdraw
														$paytmParams = array();
														$paytmParams["subwalletGuid"] = "0c23a61b-e39c-4f5b-98b3-a7e9c2a7380d";
														$paytmParams["orderId"] = "O" . $userId . "ID" . rand(1, 10000);
														$paytmParams["beneficiaryPhoneNo"] = $mobileNumber;
														$paytmParams["beneficiaryName"] = "$App_Name App";
														$paytmParams["comments"] = "$App_Name App";
														$paytmParams["amount"] = number_format($amount, 2);
														$post_data = json_encode($paytmParams, JSON_UNESCAPED_SLASHES);
														$checksum = PaytmChecksum::generateSignature($post_data, "wOf8I&aVQXvvNdah");
														$x_mid = "Mobave66649036465605";
														$x_checksum = $checksum;
														$url = "https://dashboard.paytm.com/bpay/api/v1/disburse/order/wallet/gratification";
														$json = array();
														$ch = curl_init($url);
														curl_setopt($ch, CURLOPT_POST, true);
														curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
														curl_setopt($ch, CURLOPT_HTTPHEADER, array(
															"Content-Type: application/json",
															"x-mid: " . $x_mid,
															"x-checksum: " . $x_checksum
														));
														curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
														$response = curl_exec($ch);
														curl_close($ch);
														$json = array();
														$json = json_encode($response);
														$apiresponse = json_decode($response, true);
														if ($apiresponse['statusCode'] == "DE_002") {
															// if ('a' == 'a'){
															// Sucess Auto
															$queryAuto = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','1' ,'" . $id . "','" . $ipaddress . "', '' ,' Direct Wallet Transfer','' , '" . $date . "' ,'" . $device_name . "' ) ");
															if ($queryAuto === true) {
																$finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "', '" . $title . "')");
																$passCommsion = 0;
																// Commission Pass Code	
																if (strlen($referralUserId) > 0 &&  $referralUserId != "0" && $isCommissionPass == "1") {
																	$sqlRefrealCount = mysqli_query($this->db, "SELECT userId FROM user_master WHERE referralUserId = '" . $userId . "'  ");
																	if (mysqli_num_rows($sqlRefrealCount) <= 20) {
																		// If Refer COunt Below Than Pass
																		$sqlRederRefr = mysqli_query($this->db, "SELECT earningPoint,isCommissionAllow,token,referEarningPoint,muteNoti FROM user_master WHERE userId = '" . $referralUserId . "' ");
																		if (mysqli_num_rows($sqlRederRefr) > 0) {
																			$rowReferData = $sqlRederRefr->fetch_assoc();
																			$isCommissionAllow = $rowReferData['isCommissionAllow'];
																			$referEarningPoint = $rowReferData['referEarningPoint'];
																			$muteNoti = $rowReferData['muteNoti'];
																			$RefearningPoint = $rowReferData['earningPoint'];
																			if ($isCommissionAllow == "1" && (int)$commission > 0) {
																				$Reffinalearning_point = (int)$RefearningPoint + (int)$commission;
																				$ReffEarning_point = (int)$referEarningPoint + (int)$commission;
																				$Refsqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $Reffinalearning_point . "' , referEarningPoint='" . $ReffEarning_point . "'  WHERE userId = '" . $referralUserId . "' ");
																				$passCommsion = (int)$commission;
																				mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $referralUserId . "', '" . $commission . "','12', '1','" . $Reffinalearning_point . "', 'Referral commission')");
																			}
																		}
																	}
																}
																$totalcommissionPoint = (int)$commissionPoint + $passCommsion;
																$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' ,withdrawMobileNo='" . $mobileNumber . "' , commissionPoint='" . $totalcommissionPoint . "' WHERE userId = '" . $userId . "' ");
																if ($sqlwalletupdate) {
																	$this->senWithdrawNoChanneSucesslNoti($token2, "");
																	$result['earningPoint'] = $finalearning_point;
																	$result['message'] = "We have successfully transferred money to your Paytm wallet, please check. Give 5 Star rating & review on playstore.";
																	$result['status'] = "1";
																	$result['txnStatus'] = "5";
																}
															}
														} else {
															// Failed Auto
															$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
															if ($query === TRUE) {
																$finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
																$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");
																if ($sqlwalletupdate) {
																	$result['earningPoint'] = $finalearning_point;
																	$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
																	$result['status'] = "1";
																	$result['txnStatus'] = "5";
																	$result['msgFail'] = "Auto Failed";
																}
															}
														}
													} else {
														// Manual Withdraw 
														// $query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
														// if ($query === TRUE) {
														// 	$finalearning_point = (int)$earning_point - (int)$minPoint;
														// 	mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
														// 	$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");
														// 	if ($sqlwalletupdate) {
														// 		$result['earningPoint'] = $finalearning_point;
														// 		$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
														// 		$result['status'] = "1";
														// 		$result['msgFail'] = "Auto Off";
														// 		$result['txnStatus'] = "5";
														// 	}
														// }


														if ($amount == "1" || $amount == "2" || $amount == "5" || $amount == "10") {

															switch ($amount) {
																case "1":
																	$xml = file_get_contents("https://infotecharmy.in/instant/api.php?token=FH74O&s1=1234567890&s2=" . $mobileNumber . "&s3=1&s4=install");
																	$apiresponse = json_decode($xml, true);
																	$status = $apiresponse['userpayment'];
																	break;
																case "2":
																	$xml = file_get_contents("https://infotecharmy.in/instant/api.php?token=FH74O&s1=1234567890&s2=" . $mobileNumber . "&s3=2&s4=install");
																	$apiresponse = json_decode($xml, true);
																	$status = $apiresponse['userpayment'];
																	break;
																case "5":
																	$xml = file_get_contents("https://infotecharmy.in/instant/api.php?token=FH74O&s1=1234567890&s2=" . $mobileNumber . "&s3=5&s4=install");
																	$apiresponse = json_decode($xml, true);
																	$status = $apiresponse['userpayment'];
																	break;
																case "10":
																	$xml = file_get_contents("https://infotecharmy.in/instant/api.php?token=FH74O&s1=1234567890&s2=" . $mobileNumber . "&s3=10&s4=install");
																	$apiresponse = json_decode($xml, true);
																	$status = $apiresponse['userpayment'];
																	break;
																default:
																	$status = "Failed";
															}

															if ($status == "Success") {

																$queryAuto = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','100','" . $emailId . "','" . $mobileNumber . "','1' ,'" . $id . "','" . $ipaddress . "', '' ,' Direct Wallet Transfer','' , '" . $date . "' ,'" . $device_name . "' ) ");

																if ($queryAuto === true) {
																	$finalearning_point = (int)$earning_point - (int)$minPoint;

																	mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "', '" . $title . "')");

																	$totalcommissionPoint = (int)$commissionPoint + $passCommsion;
																	$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' ,withdrawMobileNo='" . $mobileNumber . "' , commissionPoint='" . $totalcommissionPoint . "' WHERE userId = '" . $userId . "' ");
																	if ($sqlwalletupdate) {

																		$this->senWithdrawNoChanneSucesslNoti($token2, "");
																		$result['earningPoint'] = $finalearning_point;
																		$result['message'] = "We have successfully transferred money to your Paytm wallet, please check. Give 5 Star rating & review on playstore.";
																		$result['status'] = "1";
																		$result['txnStatus'] = "5";
																	}
																}
															} else {
																$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
																if ($query === TRUE) {
																	$finalearning_point = (int)$earning_point - (int)$minPoint;
																	mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");

																	$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");

																	if ($sqlwalletupdate) {
																		$result['earningPoint'] = $finalearning_point;
																		$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
																		$result['status'] = "1";
																		$result['msgFail'] = "Auto Off";
																		$result['txnStatus'] = "5";
																	}
																}
															}
														} else {
															$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
															if ($query === TRUE) {
																$finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
																$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");
																if ($sqlwalletupdate) {
																	$result['earningPoint'] = $finalearning_point;
																	$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
																	$result['status'] = "1";
																	$result['msgFail'] = "Auto Off";
																	$result['txnStatus'] = "5";
																}
															}
														}
													}
													break;
												case "2":
													//Redeem Code Withdraw
													if ($minPoint <= $isGoogleAutopoin || $isPrimeUser == "1") {
														$sqlReder = mysqli_query($this->db, "SELECT id,couponCode FROM coupone_codes WHERE points = '" . $minPoint . "' AND isSettle = '0' LIMIT 1 ");
														if (mysqli_num_rows($sqlReder) > 0) {
															// Auto Withdraw COupone 

															$date = date('Y-m-d H:i:s');
															$rowewf = $sqlReder->fetch_assoc();
															$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','1' ,'" . $id . "','" . $ipaddress . "', '" . $rowewf['couponCode'] . "' ,'','' , '" . $date . "' ,'" . $device_name . "' ) ");
															if ($query === TRUE) {
																$finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
																// $sqlwalletupdate = mysqli_query($this->db,"UPDATE user_master SET earningPoint='".$finalearning_point."' WHERE userId = '".$userId."' ");
																$passCommsion = 0;
																// Commission Pass Code	
																if (strlen($referralUserId) > 0 &&  $referralUserId != "0" && $isCommissionPass == "1") {
																	$sqlRefrealCount = mysqli_query($this->db, "SELECT userId FROM user_master WHERE referralUserId = '" . $userId . "'  ");
																	if (mysqli_num_rows($sqlRefrealCount) <= 20) {
																		// If Refer COunt Below Than Pass
																		$sqlRederRefr = mysqli_query($this->db, "SELECT earningPoint,isCommissionAllow,token,referEarningPoint,muteNoti FROM user_master WHERE userId = '" . $referralUserId . "' ");
																		if ($sqlRederRefr->num_rows > 0) {

																			$rowReferData = $sqlRederRefr->fetch_assoc();
																			$isCommissionAllow = $rowReferData['isCommissionAllow'];
																			$referEarningPoint = $rowReferData['referEarningPoint'];
																			$muteNoti = $rowReferData['muteNoti'];
																			$RefearningPoint = $rowReferData['earningPoint'];

																			if ($isCommissionAllow == "1" && (int)$commission > 0) {

																				$Reffinalearning_point = (int)$RefearningPoint + (int)$commission;

																				$ReffEarning_point = (int)$referEarningPoint + (int)$commission;

																				$Refsqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $Reffinalearning_point . "' , referEarningPoint='" . $ReffEarning_point . "'  WHERE userId = '" . $referralUserId . "' ");
																				$passCommsion = (int)$commission;

																				mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $referralUserId . "', '" . $commission . "','12', '1','" . $Reffinalearning_point . "', 'Referral commission')");
																			}
																		}
																	}
																}

																$totalcommissionPoint = (int)$commissionPoint + $passCommsion;
																$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "', withdrawMobileNo='" . $mobileNumber . "'  , commissionPoint='" . $totalcommissionPoint . "' WHERE userId = '" . $userId . "' ");

																if ($sqlwalletupdate) {

																	// $rowewf2 = $sqlRederID2->fetch_assoc();
																	//               $token2 = $rowewf2['token'];
																	$sqlwalletupdate2 = mysqli_query($this->db, "UPDATE coupone_codes SET userId='" . $userId . "' , deliveryDate='" . $date . "' ,isSettle = '1'  WHERE id = '" . $rowewf['id'] . "' ");
																	$this->senWithdrawNoChanneSucesslNotiCoupone($token2, "");
																	$result['message'] = "Your Redeem Code has been created successfully. Please check your withdrawal history.";
																	$result['status'] = "1";
																	$result['txnStatus'] = "5";
																} else {
																	$result['message'] = "Something went wrong,.Please try again after some time.";
																	$result['status'] = "0";
																	$result['txnStatus'] = "5";
																}
															} else {
																$result['message'] = "Something went wrong,.Please try again after some time.";
																$result['status'] = "0";
																$result['txnStatus'] = "0";
															}
														} else {
															// manual Withdraw COupone 
															$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
															if ($query === TRUE) {
																$finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
																$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "', withdrawMobileNo='" . $mobileNumber . "'  WHERE userId = '" . $userId . "' ");
																if ($sqlwalletupdate) {
																	$result['earningPoint'] = $finalearning_point;
																	$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
																	$result['status'] = "1";
																	$result['txnStatus'] = "0";
																} else {
																	$result['message'] = "Something went wrong. Please try again.";
																	$result['status'] = "0";
																}
															} else {
																$result['message'] = "Something went wrong. Please try again after some time.";
																$result['status'] = "0";
															}
														}
													} else {
														// manual Withdraw COupone 
														$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
														if ($query === TRUE) {
															$finalearning_point = (int)$earning_point - (int)$minPoint;
															mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "'  WHERE userId = '" . $userId . "' ");
															if ($sqlwalletupdate) {
																$result['earningPoint'] = $finalearning_point;
																$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
																$result['status'] = "1";
																$result['txnStatus'] = "0";
															} else {
																$result['message'] = "Something went wrong.Please try again.";
																$result['status'] = "0";
															}
														} else {
															$result['message'] = "Something went wrong,.Please try again after some time.";
															$result['status'] = "0";
														}
													}
													break;
												case "3":
													//BGMI  Withdraw
													$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
													if ($query === TRUE) {
														$finalearning_point = (int)$earning_point - (int)$minPoint;
														mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "', withdrawMobileNo='" . $mobileNumber . "'  WHERE userId = '" . $userId . "' ");
														if ($sqlwalletupdate) {
															$result['earningPoint'] = $finalearning_point;
															$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
															$result['status'] = "1";
															$result['txnStatus'] = "0";
														}
													}
													break;
												case "4":
													//FF Diamond  Withdraw
													$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
													if ($query === TRUE) {
														$finalearning_point = (int)$earning_point - (int)$minPoint;
														mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");
														if ($sqlwalletupdate) {
															$result['earningPoint'] = $finalearning_point;
															$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
															$result['status'] = "1";
															$result['txnStatus'] = "0";
														}
													}
													break;
												case "5":
													//Paytm Withdraw
													if ($minPoint <= $isMobiKwikAutopoin) {

														$finalearning_point = (int)$earning_point - (int)$minPoint;
														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");
														// Auto MobiKwik
														$txnid = uniqid();
														$txnid = "$prifix-" . $txnid;
														$amount = number_format($amount, 2);
														$apisecret = "nHqcEaDgr4YA7C5VnUdfBJQGR2aR3EkyMJMURgyf6qLChp44";
														$api_user_id = "hfVzRttMyLLV98fFqaS5qbva4bf75tMcvukrsjdNhwhwqdw4";
														$concat = $amount . "|" . $api_user_id . "|" . $txnid . "|" . $apisecret;
														$hash = hash("sha512", $concat);
														$urlrEQ = "https://api.komparify.com/api/v2/recharge?search_type=voucher&number=" . $mobileNumber . "&operator=2003&recharge_type=R&value=" . $amount . "&letitgothrough=1&connection_type=prepaid&region=0&api_user_id=hfVzRttMyLLV98fFqaS5qbva4bf75tMcvukrsjdNhwhwqdw4&txnid=" . $txnid . "&securehash=" . $hash . "&decimal_value=" . number_format($amount, 2) . "&user_message=$App_NameApplication";
														$crl = curl_init();
														curl_setopt($crl, CURLOPT_URL, $urlrEQ);
														curl_setopt($crl, CURLOPT_FRESH_CONNECT, true);
														curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
														$response = curl_exec($crl);
														$apiresponse = json_decode($response, true);
														if ($apiresponse['error'] == "false" && $apiresponse['order'] == "true") {
															$queryAuto = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','100','" . $emailId . "','" . $mobileNumber . "','1' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '" . $date . "' ,'" . $device_name . "' ) ");
															if ($queryAuto === true) {
																// $finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "', '" . $title . "')");
																// $sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' ,withdrawMobileNo='" . $mobileNumber . "'  WHERE userId = '" . $userId . "' ");
																if ($sqlwalletupdate) {
																	$this->senWithdrawNoChanneSucesslNoti($token2, "");
																	$result['earningPoint'] = $finalearning_point;
																	$result['message'] = "We have successfully transferred money to your MobiKwik wallet, please check. Give 5 Star rating & review on playstore.";
																	$result['status'] = "1";
																	$result['txnStatus'] = "5";
																}
															}
														} else {
															// Failed Auto
															$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','" . $this->_request['details'] . "' , '' ,'" . $device_name . "' ) ");
															if ($query === TRUE) {
																// $finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "','" . $title . "')");
																// $sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");
																if ($sqlwalletupdate) {
																	$result['earningPoint'] = $finalearning_point;
																	$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
																	$result['status'] = "1";
																	$result['txnStatus'] = "5";
																	$result['msgFail'] = "Auto Failed";
																}
															}
														}
													} else {
														//Manual Withdraw 
														$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
														if ($query === TRUE) {
															$finalearning_point = (int)$earning_point - (int)$minPoint;
															mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "','" . $title . "')");
															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");
															if ($sqlwalletupdate) {
																$result['earningPoint'] = $finalearning_point;
																$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.....";
																$result['status'] = "1";
																$result['msgFail'] = "Auto Off";
																$result['txnStatus'] = "5";
															}
														}
													}
													break;
												case "6":
													//Paytm Withdraw
													if ($minPoint <= $isAmazoneAutopoin) {

														$finalearning_point = (int)$earning_point - (int)$minPoint;
														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");

														// Auto Amazone
														$txnid = uniqid();
														$txnid = "$prifix-" . $txnid;
														$amount = number_format($amount, 2);
														$apisecret = "nHqcEaDgr4YA7C5VnUdfBJQGR2aR3EkyMJMURgyf6qLChp44";
														$api_user_id = "hfVzRttMyLLV98fFqaS5qbva4bf75tMcvukrsjdNhwhwqdw4";
														$concat = $amount . "|" . $api_user_id . "|" . $txnid . "|" . $apisecret;
														$hash = hash("sha512", $concat);
														$urlrEQ = "https://api.komparify.com/api/v2/recharge?search_type=voucher&number=" . $mobileNumber . "&operator=2005&recharge_type=R&value=" . $amount . "&letitgothrough=1&connection_type=prepaid&region=0&api_user_id=hfVzRttMyLLV98fFqaS5qbva4bf75tMcvukrsjdNhwhwqdw4&txnid=" . $txnid . "&securehash=" . $hash . "&decimal_value=" . number_format($amount, 2) . "&user_message=$App_NameApplication";
														$crl = curl_init();
														curl_setopt($crl, CURLOPT_URL, $urlrEQ);
														curl_setopt($crl, CURLOPT_FRESH_CONNECT, true);
														curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);
														$response = curl_exec($crl);
														$apiresponse = json_decode($response, true);
														if ($apiresponse['error'] == "false" && $apiresponse['order'] == "true") {
															$queryAuto = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','100','" . $emailId . "','" . $mobileNumber . "','1' ,'" . $id . "','" . $ipaddress . "', '' ,'" . $txnid . "','' , '" . $date . "' ,'" . $device_name . "' ) ");

															if ($queryAuto === true) {

																// $finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "', '" . $title . "')");

																// $sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' ,withdrawMobileNo='" . $mobileNumber . "'  WHERE userId = '" . $userId . "' ");
																if ($sqlwalletupdate) {

																	$this->senWithdrawNoChanneSucesslNoti($token2, "");
																	$result['earningPoint'] = $finalearning_point;
																	$result['message'] = "We have successfully transferred money to your MobiKwik wallet, please check. Give 5 Star rating & review on playstore.";
																	$result['status'] = "1";
																	$result['txnStatus'] = "5";
																}
															}
														} else {
															// Failed Auto
															$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
															if ($query === TRUE) {
																// $finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "','" . $title . "')");

																// $sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");

																if ($sqlwalletupdate) {
																	$result['earningPoint'] = $finalearning_point;
																	$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
																	$result['status'] = "1";
																	$result['txnStatus'] = "5";
																	$result['msgFail'] = "Auto Failed";
																}
															}
														}
													} else {
														//Manual Withdraw 
														$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
														if ($query === TRUE) {
															$finalearning_point = (int)$earning_point - (int)$minPoint;
															mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "','" . $title . "')");

															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");

															if ($sqlwalletupdate) {
																$result['earningPoint'] = $finalearning_point;
																$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.....";
																$result['status'] = "1";
																$result['msgFail'] = "Auto Off";
																$result['txnStatus'] = "5";
															}
														}
													}

													break;
												case "8":
													sleep(rand(3, 15));
													//UPITransfer Withdraw
													if ($minPoint <= $isUPIpoin) {
														if ((int)$earning_point >= (int)$minPoint) {

															$finalearning_point = (int)$earning_point - (int)$minPoint;
															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");

															if (mysqli_affected_rows($this->db)) {
																$amount = (int)$payoutPoint / 100;
																$txnid =  "$prifix" . $userId . "ID" . rand(100, 1000000);
																$response = file_get_contents("http://taskpaydeal.com/UPITransfer/CBZ-reacharge3.php?UPIID=" . $mobileNumber . "&amount=" . $amount . "&appName=$App_NameApp&userId=" . $userId . "&txnID=" . $txnid);
																$apiresponse = json_decode($response, true);

																if ($apiresponse['status_code'] == "200") {
																	$queryAuto = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','100','" . $emailId . "','" . $mobileNumber . "','1' ,'" . $id . "','" . $ipaddress . "', '' ,'" . $txnid . "','' , '" . $date . "' ,'" . $device_name . "' ) ");

																	if ($queryAuto === true) {

																		// $finalearning_point = (int)$earning_point - (int)$minPoint;
																		mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "', '" . $title . "')");

																		// $sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE userId = '" . $userId . "' ");
																		if ($sqlwalletupdate) {

																			$this->senWithdrawNoChanneSucesslNoti($token2, "");
																			$result['earningPoint'] = $finalearning_point;
																			$result['message'] = "We have successfully transferred money to your UPI Bank account.\n \nCredit Amount in 5-10 Minites.\n";
																			$result['status'] = "1";
																			$result['txnStatus'] = "5";
																		}
																	}
																} else {
																	$finalearning_point = (int)$earning_point;
																	$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");

																	$ErrorMessage = $apiresponse['message'];
																	$result['message'] = "There is a technical issue at your bank please try after some time.\nOr\nEnter Valid Bank UPI ID.\n";
																	$result['status'] = "0";
																}
															}
														}
													} else {
														//Manual Withdraw 
														$query = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , 'Penfig' ,'" . $device_name . "' ) ");
														if ($query === TRUE) {
															$finalearning_point = (int)$earning_point - (int)$minPoint;
															mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "','" . $title . "')");

															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE userId = '" . $userId . "' ");

															if ($sqlwalletupdate) {
																$result['earningPoint'] = $finalearning_point;
																$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.....";
																$result['status'] = "1";
																$result['msgFail'] = "Auto Off";
																$result['txnStatus'] = "5";
															}
														}
													}
													break;
												default:
													$result['message'] = "Something wrong please try again.";
													$result['status'] = "0";
											}
										} else {
											$result['message'] = "You do not have enough points to withdraw. Earn more points and try again.";
											$result['status'] = "0";
										}
									}
								}
							} else {
								$result['message'] = "This withdraw type is disabled for now, Please use another withdraw type.";
								$result['status'] = "0";
							}
						}
					} else {
						$result['message'] = "Please Enter Valid Data";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Please Login Again.";
					$result['status'] = "5";
				}
			} else {
				$result['message'] = "Please play one Game or Complite One Task before Withdraw amount.\n \nआपको Withdraw कर ने के लिए एक गेम प्ले करना होगा या एक टास्क करना पड़ेगा ";
				$result['status'] = "0";
			}
		}


		$result['adFailUrl'] = "https://sportsgurupro.com";
		$result['nextWithdrawAmount'] = "5";
		// 		$result['txnStatus'] = "5";
		$this->response($this->json($result), 200);
	}

	//getNotificationList
	private function CVISDGVDSL()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();
		$Details = json_decode($this->_request['details'], true);
		$device_id = $Details['ZN5COT'];
		$userId = $Details['FESFDS'];
		$adId = $Details['TS4H07'];
		$date = date('Y-m-d H:i:s');

		$result['BottomBanner']['image'] = "https://mycashbazar.com/BannerAd/3rswithdrawsmall.gif";
		$result['BottomBanner']['screenNo'] = "18";


		$result['TopBanner']['image'] = "https://mycashbazar.com/BannerAd/3rswithdrawsmall.gif";
		$result['TopBanner']['screenNo'] = "18";

		$sql1 = mysqli_query($this->db, "SELECT * FROM notification WHERE isActive = '1' ORDER BY id DESC");
		if (mysqli_num_rows($sql1) > 0) {
			while ($rltsetting = mysqli_fetch_array($sql1, MYSQLI_ASSOC)) {
				$result['notificationList'][] = $rltsetting;
			}
			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";
		} else {
			$result['message'] = "No Data Found.";
			$result['status'] = "1";
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['isShowInterstitial'] = "0"; // 1 = Interstitial, 2 = Rewarded, 0 = No ads

		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['type'] = "0";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>$App_Name Provides 100% Withdraw to All Users.</marquee>";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}
	//getTaskDetails
	private function URIEL()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();
		$Details = json_decode($this->_request['details'], true);
		$gameId = $Details['JMNH4R'];
		$userId = $Details['QB3GCM'];
		$adId = $Details['ONRZQD'];
		$appVersion = $Details['QTD4A3'];
		$deviceName = $Details['W5PN7T'];
		$deviseId = $Details['OGH7Z2'];
		$todayOpen = $Details['VP9Q6N'];
		$totalOpen = $Details['4FY9R3'];
		$setting = mysqli_query($this->db, "SELECT * FROM task_offer WHERE id = '" . $gameId . "' ");

		if (mysqli_num_rows($setting) > 0) {
			$result['taskDetails'] = $setting->fetch_assoc();
			$result['taskDetails']['footstep'] = json_decode($result['taskDetails']['footstep'], true);


			$result['taskDetails']['shareTitle'] = "Share & Earn Unlimited Points";
			$result['taskDetails']['shareMessage'] = "Get extra points when your friend will complete this offer from your referral link.";
			$result['taskDetails']['shareBtnNote'] = "Share Link & Get";
			$result['taskDetails']['shareNote'] = "Note: To complete this offer, you or your friend must follow the steps and the terms &amp; conditions.";

			$data = array(
				array('bgcolor' => "#FFFFFF",  "fontcolor" => "#000000", "steps" => "1. Any fraud activity will block your Account and all payment will be Cancelled."),
				array('bgcolor' => "#FFFFFF",  "fontcolor" => "#000000", "steps" => "2. This app must not be installed in your device earlier."),
			);

			$result['taskDetails']['tncList'] = $data;
			$result['status'] = "1";

			$taskUrl = sprintf($result['taskDetails']['url'], $userId);

			if (strpos($taskUrl, "&subid=") !== false) {
				$taskUrl = $taskUrl . $userId;
			} else {
				$taskUrl = sprintf($taskUrl, $userId);;
			}
			if (strpos($taskUrl, 'GID') !== false) {
				$taskUrl = str_replace('GID', $adId, $taskUrl);
			}
			$result['taskDetails']['url'] = $taskUrl;

			$result['taskDetails']['imageUploadTitle'] = "Please Upload Screenshot.";
			$result['taskDetails']['campaignId'] = "151";
			$result['homeNote'] = "";
		} else {
			$result['message'] = "No Data Found.";
			$result['status'] = "2";
		}

		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>TaskPay Provides 100% Withdraw to All Users.</marquee>";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['isShowInterstitial'] = "0"; // 1 = Interstitial, 2 = Rewarded, 0 = No ads

		// if(rand(8,169) % 5== 0 )
		// {
		// 	$result['isShowInterstitial'] = "1"; // 1 = Interstitial, 2 = Rewarded, 0 = No ads
		// }

		// if(rand(10,140) % 7== 0 )
		// {
		// 	$result['isShowInterstitial'] = "2"; // 1 = Interstitial, 2 = Rewarded, 0 = No ads
		// }

		// $result['isShowNativeAd'] = "0";

		$this->response($this->json($result), 200);
	}

	//SubmitQueryHelp
	private function ZARA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		$Details = json_decode($this->_request['details'], true);
		$emailId = $Details['R93ENB'];
		$mobileNumber = $Details['7PTWTF'];
		$query = $Details['2T0EK7'];
		$appVersion = $Details['NYCIDR'];
		$deviceName = $Details['PDDQDV'];
		$adId = $Details['7WWUQD'];
		$todayOpen = $Details['R9DTNP'];
		$totalOpen = $Details['G315WN'];
		$userId = $Details['W702F0'];
		$deviseId = $Details['F3LQIH'];
		$Image = $Details['0WAONR'];

		$transactionId = $Details['GBHJGHB'];
		$withdrawId = $Details['POJJBHR'];
		$ticketId = $Details['JHVGHVB'];
		$isCloseTicket = $Details['HJWDVGB'];

		$encrypt = $this->_request['details'];
		$name = 'SubmitQueryHelp';
		$isencrypted = '1';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);

		if ($withdrawId == NULL) {
			$withdrawId = "0";
		}


		$result = array();

		$result['ticketId'] = $ticketId;

		$fileName1  =  $_FILES['image1']['name'];
		$tempPath1  =  $_FILES['image1']['tmp_name'];
		$fileSize1  =  $_FILES['image1']['size'];

		$valid_extensions = array('jpg', 'png');

		$upload_path = '../upload/';

		if ($fileName1 != NULL) {

			if (!empty($fileName1)) {
				$fileExt1 = strtolower(pathinfo($fileName1, PATHINFO_EXTENSION));
				if (in_array($fileExt1, $valid_extensions)) {
					if ($fileSize1 < 5000000) {
						move_uploaded_file($tempPath1, $upload_path . $fileName1);
					} else {

						$result['message'] = "Sorry, your file is too large, it should be < 5 MB.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Sorry, we allow to upload only JPG, PNG files";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "Please Select file.";
				$result['status'] = "0";
			}

			if ($result['status'] != "0") {

				$fileName1 = "http://eazyearning.com/Api/upload/" . $fileName1;

				$sqinsert = mysqli_query($this->db, "INSERT INTO help_faq(emailId,userId,query,deviseId,mobileNo,image,withdrawId) VALUES('" . $emailId . "', '" . $userId . "', '" . $query . "','" . $deviseId . "','" . $mobileNumber . "', '" . $fileName1 . "', '" . $withdrawId . "')");

				if ($sqinsert === TRUE) {
					if (strlen($withdrawId) > 0 && strlen($transactionId) > 0) {
						$last_id = $this->db->insert_id;
						$result['ticketId'] = $last_id;
						$sql = "UPDATE withdraw_coupone SET raisedTicketId = '" . $last_id . "' WHERE id = '" . $withdrawId . "' AND txnID = '" . $transactionId . "' ";
						mysqli_query($this->db, $sql);
					}
					$result['message'] = "Thank you for contacting us, we will get back to you soon!";
					$result['status'] = "1";
				} else {
					$result['message'] = "Something wrong try again.1";
					$result['status'] = "0";
				}
			}
		} else {
			if (strlen($isCloseTicket) > 0 && $isCloseTicket == '1') {
				$sql = "UPDATE withdraw_coupone SET raisedTicketId = '0' WHERE id = '" . $withdrawId . "' AND txnID = '" . $transactionId . "' ";
				$result['ticketId'] = '0';
			} elseif (strlen($ticketId) > 0) {
				$sql = "UPDATE help_faq SET query = '" . $query . "' WHERE id = '" . $ticketId . "'";
			} else {
				$sql = "INSERT INTO help_faq(emailId,userId,query,deviseId,mobileNo,withdrawId) VALUES('" . $emailId . "', '" . $userId . "', '" . $query . "','" . $deviseId . "','" . $mobileNumber . "','" . $withdrawId . "')";
			}

			$insert = mysqli_query($this->db, $sql);
			if ($insert === TRUE) {
				if (strlen($isCloseTicket) > 0 && $isCloseTicket == '1') {
					$result['message'] = "We have closed your ticket, Thank you for contacting us!";
				} elseif (strlen($ticketId) > 0) {
					$result['message'] = "We have updated your ticket details, we will get back to you soon!";
				} else {
					if (strlen($withdrawId) > 0 && strlen($transactionId) > 0) {
						$last_id = $this->db->insert_id;
						$result['ticketId'] = $last_id;
						$sql = "UPDATE withdraw_coupone SET raisedTicketId = '" . $last_id . "' WHERE id = '" . $withdrawId . "' AND txnID = '" . $transactionId . "' ";
						mysqli_query($this->db, $sql);
					}
					$result['message'] = "Thank you for contacting us, we will get back to you soon!";
				}
				$result['status'] = "1";
			} else {
				$result['message'] = "Something went wrong, please try again.";
				$result['status'] = "0";
			}
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['tigerInApp'] = "";

		$this->response($this->json($result), 200);
	}


	//GetQueryHelpTicketDetails
	private function RAVAN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		$Details = json_decode($this->_request['details'], true);
		$appVersion = $Details['NDSS2M'];
		$deviceName = $Details['MR00JD'];
		$adId = $Details['JHFJJ5'];
		$todayOpen = $Details['VBC3QI'];
		$totalOpen = $Details['2UHDTP'];
		$userId = $Details['7S5LYR'];
		$deviseId = $Details['W4VOEZ'];

		$ticketId = $Details['H3UQQR'];

		$result = array();

		$sql = mysqli_query($this->db, "SELECT * FROM help_faq WHERE id = '" . $ticketId . "'");
		if (mysqli_num_rows($sql) > 0) {
			$raw = $sql->fetch_assoc();
			$result['query'] = $raw['query'];
			$result['reply'] = $raw['reply'];
			$result['image'] = $raw['image'];
			$result['status'] = "1";
			$result['message'] = "We have updated your ticket details, we will get back to you soon!";
		} else {
			$result['status'] = "0";
			$result['message'] = "Sorry, we are unable to find this ticket id!";
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['tigerInApp'] = "";

		$this->response($this->json($result), 200);
	}


	//getTaskImageUpload
	private function ZUDIO()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		$result = array();
		$Details = json_decode($this->_request['details'], true);
		$taskId = $Details['VNSOVC'];
		$userId = $Details['DIMGHD'];
		$taskTitle = $Details['1F0V0B'];
		$adId = $Details['AHPKQ2'];

		$fileName1  =  $_FILES['image1']['name'];
		$tempPath1  =  $_FILES['image1']['tmp_name'];
		$fileSize1  =  $_FILES['image1']['size'];

		$valid_extensions = array('jpg', 'png');

		$upload_path = '../upload/';

		if (!empty($fileName1)) {
			$fileExt1 = strtolower(pathinfo($fileName1, PATHINFO_EXTENSION));
			if (in_array($fileExt1, $valid_extensions)) {
				if ($fileSize1 < 5000000) {
					move_uploaded_file($tempPath1, $upload_path . $fileName1);
				} else {

					$result['message'] = "Sorry, your file is too large, it should be < 5 MB.";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "Sorry, we allow to upload only JPG, PNG files";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Please Select file.";
			$result['status'] = "0";
		}

		if ($result['status'] != "0") {

			$fileName1 = "http://eazyearning.com/Api/upload/" . $fileName1;

			$sqinsert = mysqli_query($this->db, "INSERT INTO taskUserImage (userId,taskId,image1,taskTitle) VALUES('" . $userId . "', '" . $taskId . "', '" . $fileName1 . "', '" . $taskTitle . "') ");
			if ($sqinsert === TRUE) {
				$result['message'] = "Your image is uploaded successfully. Your reward points will be credited withing 24 hours.";
				$result['status'] = "1";
			}
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}

	//getScratchcard
	private function APPLE()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$adId = $Details['OQ1WGE'];
		$userId = $Details['I4BR27'];
		$totalEarning = 0;
		$scratchCardList = mysqli_query($this->db, "SELECT * FROM scratch_card WHERE   userId = '" . $userId . "' ORDER BY id DESC ");

		while ($cardlist = mysqli_fetch_array($scratchCardList, MYSQLI_ASSOC)) {
			if ($cardlist['isScratched'] == '1') {
				$totalEarning = $totalEarning + $cardlist['scratchCardPoints'];
			}
			$result['scratchCardList'][] = $cardlist;
		}

		$lastscratchdate = mysqli_query($this->db, "SELECT * FROM scratch_card WHERE   userId = '" . $userId . "' AND isScratched = 1  ORDER BY scratchedDate DESC LIMIT 1 ");
		$lastscratchedate = mysqli_fetch_array($lastscratchdate, MYSQLI_ASSOC);

		$result['lastScratchedDate'] = $lastscratchedate['scratchedDate'];

		$result['todayDate'] =  date("Y-m-d H:i:s");
		$result['scratchTime'] = "30";
		$result['backImage'] = "http://eazyearning.com/Api/upload/backscratch.png";
		$result['frontImage'] = "http://eazyearning.com/Api/upload/frontscratch.png";

		$result['helpVideoUrl'] = "";

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";
		$result['totalScratchCardEarning'] = $totalEarning;
		$result['message'] = "Data Found Sucessfully.";
		$result['status'] = "1";
		$this->response($this->json($result), 200);
	}
	//saveScratchcard
	private function BLUE()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$adId = $Details['OT9BUX'];
		$userId = $Details['G5FXTP'];
		$points = $Details['OMAW30'];
		$id = $Details['4D9WT2'];

		$agent = $_SERVER['HTTP_USER_AGENT'];

		if ($userId > 0 && $agent == "okhttp/5.0.0-alpha.2") {

			$scratchCardList = mysqli_query($this->db, "SELECT * FROM scratch_card WHERE   id = '" . $id . "'  AND userId = '" . $userId . "' ");
			$rowewf = $scratchCardList->fetch_assoc();
			$lastScratchDate = $rowewf['scratchedDate'];

			$todayD = date('Y-m-d H:i:s');
			$from_time = strtotime($lastScratchDate);
			$to_time = strtotime($todayD);
			$diff_minutes = round(abs($from_time - $to_time) / 60, 2);
			if (mysqli_num_rows($scratchCardList) > 0) {

				if ($rowewf['isScratched'] == 0) {

					if ($diff_minutes > 30) {

						if ($points == $rowewf['scratchCardPoints']) {

							$sqlRederID = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "' ");
							$rowewf = $sqlRederID->fetch_assoc();
							$finalearning_point = $rowewf['earningPoint'] + $points;

							$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $points . "', '20', '1','" . $finalearning_point . "','scratch card Earning')");

							$qry2 = mysqli_query($this->db, "UPDATE scratch_card SET isScratched='1' , scratchedDate = '" . date("Y-m-d H:i:s") . "' WHERE id = '" . $id . "'  AND userId = '" . $userId . "' ");

							if ($qry1 == true &&  $qry2 == true) {
								$lastscratchdate = mysqli_query($this->db, "SELECT * FROM scratch_card WHERE   userId = '" . $userId . "' AND isScratched = 1  ORDER BY scratchedDate DESC LIMIT 1 ");
								$lastscratchedate = mysqli_fetch_array($lastscratchdate, MYSQLI_ASSOC);


								$tid = $this->gen_uuid();
								$result['userDetails']['userToken'] = $tid;
								$result['userToken'] = $tid;

								$qry2 = mysqli_query($this->db, "UPDATE user_master SET earningPoint= '" . $finalearning_point . "' ,userToken = '" . $tid . "'   WHERE userId = '" . $userId . "' ");

								$result['lastScratchedDate'] = $lastscratchedate['scratchedDate'];
								$result['earningPoint'] =  $finalearning_point;

								$totalEarning = 0;
								$scratchCardList = mysqli_query($this->db, "SELECT * FROM scratch_card WHERE   userId = '" . $userId . "' ORDER BY id DESC ");
								while ($cardlist = mysqli_fetch_array($scratchCardList, MYSQLI_ASSOC)) {
									if ($cardlist['isScratched'] == '1') {
										$totalEarning = $totalEarning + $cardlist['scratchCardPoints'];
									}
								}
								$result['totalScratchCardEarning'] = $totalEarning;

								$result['message'] = "Data found successfully 1";
								$result['status'] = "1";
							} else {
								$result['message'] = "Something went wrong 1";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "Something went wrong, please try again. points";
							$result['status'] = "0";
						}
					} else {

						$result['message'] = "30 minutes are not over, please try again after some time ";
						$result['status'] = "0";
					}
				} else {

					$result['message'] = "You have already scratched this card.";
					$result['status'] = "1";
				}
			} else {

				$result['message'] = "Something went wrong, please try again. user";
				$result['status'] = "0";
			}
		} else {

			$result['message'] = "Something went wrong, please try again. user";
			$result['status'] = "0";
		}
		$result['isTodayTaskCompleted'] = "0";
		$result['todayDate'] =  date("Y-m-d H:i:s");

		$result['scratchTime'] = "30";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}


	//getGiveAwayList
	private function FLOWER()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		global $Telegram_url;
		global $Insta_url;
		$Details = json_decode($this->_request['details'], true);
		$date = date('Y-m-d H:i:s');
		$data = array(
			array('icon' => "https://eazyearning.com/Api/images/in.png",  "title" => "Instagram", "url" => "$Insta_url"),

			array('icon' => "https://eazyearning.com/Api/images/yo.png", "title" => "Youtube", "url" => "$Youtube_url"),

			array('icon' => "https://eazyearning.com/Api/images/te.png", "title" => "Telegram", "url" => "$Telegram_url")
		);

		$result['socialMedia'] = $data;

		// $result['helpVideoUrl'] = $Youtube_url;


		$sql1 = mysqli_query($this->db, "SELECT * FROM giveaway_coupon_codes WHERE isDisplay = '1' AND  startDate < '" . $date . "' AND endDate > '" . $date . "' ORDER BY displayIndex DESC");
		if (mysqli_num_rows($sql1) > 0) {
			while ($rltsetting = mysqli_fetch_array($sql1, MYSQLI_ASSOC)) {
				$result['giveawayCodeList'][] = $rltsetting;
			}
		}

		$result['note'] = "<b>Step1:</b> Go to our social media page<br/><b>Step2:</b> Copy giveaway code<br/><b>Step3:</b> Paste giveaway code here & Claim reward";

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['message'] = "Data Found Sucessfully.";
		$result['status'] = "1";
		$this->response($this->json($result), 200);
	}
	//getWatchVideoList
	private function WHITE()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date('Y-m-d');
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['KBOOXQ'];
		$total = 0;
		$data = array(

			array('video_id' => "1", 'video_points' => rand(5, 27), "ads_type" => "1", "title" => "Upto 50 Points", "desc" => "Watch video and get"),

			array('video_id' => "2", 'video_points' => rand(5, 10), "ads_type" => "2", "title" => "Upto 20 Points", "desc" => "Watch this video and get"),

			array('video_id' => "3", 'video_points' => rand(10, 30), "ads_type" => "2", "title" => "Upto 30 Points", "desc" => "Watch this video and get"),

			array('video_id' => "4", 'video_points' => rand(2, 8), "ads_type" => "1", "title" => "Upto 40 Points", "desc" => "Watch this video and get"),

			array('video_id' => "5", 'video_points' => rand(8, 30), "ads_type" => "1", "title" => "Upto 50 Points", "desc" => "Watch this video and get"),

			array('video_id' => "6", 'video_points' => rand(5, 20), "ads_type" => "1", "title" => "Upto 60 Points", "desc" => "Watch this video and get"),

			array('video_id' => "7", 'video_points' => rand(2, 10), "ads_type" => "2", "title" => "Upto 70 Points", "desc" => "Watch this video and get"),

			array('video_id' => "8", 'video_points' => rand(10, 25), "ads_type" => "2", "title" => "Upto 80 Points", "desc" => "Watch this video and get"),

			array('video_id' => "9", 'video_points' => rand(2, 8), "ads_type" => "1", "title" => "Upto 90 Points", "desc" => "Watch this video and get"),

			array('video_id' => "10", 'video_points' => rand(5, 20), "ads_type" => "1", "title" => "Upto 100 Points", "desc" => "Watch this video and get")

		);

		$result['watchVideoList'] = $data;
		$result['todayDate'] =  date("Y-m-d H:i:s");

		if ($userId > 0) {
			$lastDayquerry = mysqli_query($this->db, "SELECT * FROM watch_video_points WHERE userId = '" . $userId . "'   ORDER BY id DESC limit 1");
			$day = mysqli_fetch_array($lastDayquerry, MYSQLI_ASSOC);
			$isReset = $day['isReset'];
			$lastWatchedVideoId = $day['video_id'];
			$addDate = $day['add_date'];
			$entrydate = $day['entryDate'];

			$totalpoints = mysqli_query($this->db, "SELECT userId,points,video_id,add_date FROM watch_video_points WHERE add_date = '" . $date . "'   AND  userId = '" . $userId . "'  ORDER BY id DESC ");

			while ($tp = mysqli_fetch_array($totalpoints, MYSQLI_ASSOC)) {
				$result['watchedVideoList'][] = $tp;
			}
			if (mysqli_num_rows($lastDayquerry) > 0) {
				if ($date == $addDate) {
					$result['lastVideoWatchedDate'] = $entrydate;
					$result['lastWatchedVideoId'] = $lastWatchedVideoId;
					$result['message'] = "Data Found Sucessfully.";
					$result['status'] = "1";
				} else {
					$result['lastWatchedVideoId'] = '0';
					$result['lastVideoWatchedDate'] =  NULL;
					$result['message'] = "Data Found Sucessfully 1 ";
					$result['status'] = "1";
				}
			} else {
				$result['lastWatchedVideoId'] = '0';
				$result['lastVideoWatchedDate'] =  NULL;
				$result['message'] = "Data Not Found 2";
				$result['status'] = "1";
			}
		} else {
			$result['lastWatchedVideoId'] = '0';
			$result['lastVideoWatchedDate'] =  NULL;
			$result['message'] = "Data Not Found 2";
			$result['status'] = "1";
		}

		$result['watchTime'] = "70"; // 30 minutes

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock Watch Video feature.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "31";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Watch Video feature.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}

	//saveGiveAway
	private function SKY()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		// $Details = json_decode($this->_request['details'], true);

		$couponCode = $Details['TMK2QD'];
		$userId = $Details['9OGBPX'];
		$deviseId = $Details['IDT9EA'];
		$encrypt = $this->_request['details'];
		$isencrypted = '1';
		$name="saveGiveAway";
		$log['log'] = $this->log($encrypt, $name, $isencrypted);
		$todayDate = date('Y-m-d H:i:s');
		$findcoupon1 = mysqli_query($this->db, "SELECT * FROM giveaway_coupon_codes WHERE couponCode = '" . $couponCode . "' ");
		$coupon = mysqli_fetch_array($findcoupon1, MYSQLI_ASSOC);
		$startDate = $coupon['startDate'];
		$endDate = $coupon['endDate'];
		$count = $coupon['count'];
		$points = $coupon['points'];


		if ($todayDate >= $startDate && $todayDate <= $endDate) {
			
			$findcoupon2 = mysqli_query($this->db, "SELECT * FROM giveaway_history WHERE couponCode = '" . $couponCode . "' ");
			if (mysqli_num_rows($findcoupon2) < $count) {

				$findcoupon3 = mysqli_query($this->db, "SELECT * FROM giveaway_history WHERE userId = '" . $userId . "' AND couponCode = '" . $couponCode . "' ");
				$userexist = mysqli_fetch_array($findcoupon3, MYSQLI_ASSOC);
				$existuser = $userexist['userId'];
				$deviseIdDB = $userexist['deviseId'];

				if ($userId != $existuser && $deviseId != $deviseIdDB) {

					$withdrawCount = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "' AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
					$checWithdrawcount = mysqli_num_rows($withdrawCount);

					//  if ($checWithdrawcount > 0) {
						$sqlRederID = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "' ");
						$rowewf = $sqlRederID->fetch_assoc();
						$earning_point = $rowewf['earningPoint'];
						$finalearning_point = (int)$earning_point + (int)$points;

						$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $points . "', '19', '1','" . $finalearning_point . "','Giveaway Earning')");

						$qry2 = mysqli_query($this->db, "INSERT INTO giveaway_history(userId, points,couponCode,entryDate,deviseId) VALUES ('" . $userId . "', '" . $points . "', '" . $couponCode . "','" . $todayDate . "','" . $deviseId . "')");
						
						if ($qry1 == true &&  $qry2 == true) {

							$tid = $this->gen_uuid();
							$result['userDetails']['userToken'] = $tid;
							$result['userToken'] = $tid;

							$qry3 = mysqli_query($this->db, "UPDATE user_master SET earningPoint = '" . $finalearning_point . "' ,userToken = '" . $tid . "'  WHERE userId = '" . $userId . "' ");
							$result['earningPoint'] = $finalearning_point;
							$result['couponPoints'] = $points;
							$result['message'] = "Data found successfully 1";
							$result['status'] = "1";
						} else {
							$result['message'] = "Something went wrong 1";
							$result['status'] = "0";
						}
					// } 
					// else {
						// $result['message'] = "Please play one game before redeem giveaway code.\n \nआपको giveaway कोड रिडीम कर ने के लिए एक गेम प्ले करना होगा";
						// $result['status'] = "0";
						// $result['btnName'] = $coupon['btnName'];
						// $result['screenNo'] = $coupon['screenNo'];
					// }
				} else {
					$result['message'] = "You have already claimed reward for this giveaway code";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "Limit for this giveaway code is over";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "This giveaway code is expired";
			$result['status'] = "0";
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}

	function checkwatchvideo($videoid, $point)
	{
		switch ($videoid) {
			case "1":
				if ($point >= 5 && $point <= 30) {
					return true;
				} else {
					return false;
				}
				break;


			case "2":
				if ($point >= 2 && $point <= 20) {
					return true;
				} else {
					return false;
				}
				break;

			case "3":
				if ($point >= 10 && $point <= 30) {
					return true;
				} else {
					return false;
				}
				break;

			case "4":
				if ($point >= 2 && $point <= 10) {
					return true;
				} else {
					return false;
				}
				break;
			case "5":
				if ($point >= 9 && $point <= 35) {
					return true;
				} else {
					return false;
				}
				break;
			case "6":
				if ($point >= 2 && $point <= 42) {
					return true;
				} else {
					return false;
				}
				break;
			case "7":
				if ($point >= 10 && $point <= 22) {
					return true;
				} else {
					return false;
				}
				break;
			case "8":
				if ($point >= 10 && $point <= 42) {
					return true;
				} else {
					return false;
				}
				break;
			case "9":
				if ($point >= 14 && $point <= 45) {
					return true;
				} else {
					return false;
				}
				break;
			case "10":
				if ($point >= 4 && $point <= 20) {
					return true;
				} else {
					return false;
				}
				break;

			default:
				return false;
		}
	}
	//saveWatchVideo
	private function IAN()
	{

		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$ipaddress = $this->getIp();
		$date = date('Y-m-d');
		$td = date('Y-m-d');

		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['HAT032'];
		$videoId = $Details['243Y40'];
		$points = $Details['KBG462'];
		$adId = $Details['DM2OOC'];
		$userToken = $Details['39OMIT'];
		$checkpoint = $this->checkwatchvideo($videoId, $points);

		$date = date("Y-m-d H:i:s");
		$dateOnly = date("Y-m-d");
		$td = date('Y-m-d');

		$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayTask = mysqli_num_rows($sql1);

		if ($checkpoint) {

			// if($totalTodayTask > 0){
			if (strlen($userId) > 0 && (int)$userId  > 0 && strlen($userToken) > 0) {

				$lastDayquerry = mysqli_query($this->db, "SELECT * FROM watch_video_points WHERE userId = '" . $userId . "'  AND isReset = '0'  ORDER BY id DESC limit 1");
				$day = mysqli_fetch_array($lastDayquerry, MYSQLI_ASSOC);
				$lastearnday = $day['add_date'];
				$lastWatchedVideoId = $day['video_id'];
				$entryDate = $day['entryDate'];
				$add_date = $day['add_date'];
				$isReset = $day['isReset'];

				$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,userToken FROM user_master WHERE userId = '" . $userId . "' ");
				$rowewf = $sqlRederID->fetch_assoc();
				$earning_point = $rowewf['earningPoint'];
				$userToken2 = $rowewf['userToken'];

				if ($userToken2 != $userToken) {

					$result['message'] = "Something went wrong. Login Again.";
					$result['status'] = "5";
				} else {
					$todayD = $date;
					$entryD = $entryDate;

					$from_time = strtotime($todayD);
					$to_time = strtotime($entryD);
					$diff_minutes = round(abs($from_time - $to_time) / 60, 2);
					if ($dateOnly == $add_date) {
						if ($diff_minutes > 30) {
							$finalearning_point = (int)$earning_point + (int)$points;
							$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $points . "', '18', '1','" . $finalearning_point . "','Watch Video Earning')");

							$qry2 = mysqli_query($this->db, "INSERT INTO watch_video_points(userId, points,video_id,add_date,adId,ipAddress,isReset) VALUES ('" . $userId . "', '" . $points . "', '" . $videoId . "','" . $td . "','" . $adId . "','" . $ipaddress . "','0')");

							if ($qry1 == true &&  $qry2 == true) {
								$lastDayquerry = mysqli_query($this->db, "SELECT * FROM watch_video_points WHERE userId = '" . $userId . "'   ORDER BY id DESC limit 1");
								$day = mysqli_fetch_array($lastDayquerry, MYSQLI_ASSOC);


								$tid = $this->gen_uuid();
								$result['userDetails']['userToken'] = $tid;
								$result['userToken'] = $tid;

								$qry3 = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' userToken = '" . $tid . "'  WHERE userId = '" . $userId . "' ");


								$result['earningPoint'] = $finalearning_point;
								$entrydate = $day['entryDate'];
								$lastWatchedVideoId1 = $day['video_id'];
								$result['lastVideoWatchedDate'] = $entrydate;
								$result['lastWatchedVideoId'] = $lastWatchedVideoId1;
								$result['todayDate'] = date("Y-m-d H:i:s");

								$result['message'] = "Data found successfully 1";
								$result['status'] = "1";
							} else {
								$result['message'] = "Something went wrong 1";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "30 minutes are not over, please try after some time";
							$result['status'] = "0";
						}
					} else {

						// $qry3 = mysqli_query($this->db, "UPDATE user_master SET earningPoint='".$finalearning_point."'  WHERE userId = '" . $userId . "' ");

						$finalearning_point = (int)$earning_point + (int)$points;

						$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $points . "', '18', '1','" . $finalearning_point . "','Watch Video Earning')");

						$qry2 = mysqli_query($this->db, "INSERT INTO watch_video_points(userId, points,video_id,add_date,adId,ipAddress,isReset) VALUES ('" . $userId . "', '" . $points . "', '" . $videoId . "','" . $td . "','" . $adId . "','" . $ipaddress . "','0')");

						if ($qry1 == true &&  $qry2 == true) {
							$lastDayquerry = mysqli_query($this->db, "SELECT * FROM watch_video_points WHERE userId = '" . $userId . "'   ORDER BY id DESC limit 1");
							$day = mysqli_fetch_array($lastDayquerry, MYSQLI_ASSOC);
							$entrydate1 = $day['entryDate'];
							$qry3 = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "'  WHERE userId = '" . $userId . "' ");
							$ep1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "'  ");
							$ep = $ep1->fetch_assoc();
							$result['earningPoint'] = $ep['earningPoint'];

							$lastWatchedVideoId1 = $day['video_id'];
							$result['lastVideoWatchedDate'] = $entrydate1;
							$result['lastWatchedVideoId'] = $lastWatchedVideoId1;
							$result['todayDate'] = date("Y-m-d H:i:s");
							$result['message'] = "Data found successfully 2";
							$result['status'] = "1";
						} else {
							$result['message'] = "Something went wrong 2";
							$result['status'] = "0";
						}
					}
				}
			} else {
				$result['message'] = "Something went wrong.";
				$result['status'] = "5";
			}
			// } else {
			// 	$result['message'] = "Complete Task to earn with Watch Video.";
			// 	$result['status'] = "0";
			// }
		} else {
			$result['message'] = "Something went wrong-validate";
			$result['status'] = "0";
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";

		// $result['isShowAds'] = rand(0, 1);

		$result['watchTime'] = "70"; // 30 minutes

		$this->response($this->json($result), 200);
	}


	//getRewardScreenList

	private function HOPE()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$token = $Details['DZ9OZM'];
		$userId = $Details['VHOOE5'];
		$appVersion = $Details['PWWGF4'];
		$deviceName = $Details['FQDZGG'];
		$deviseId = $Details['OFI5WW'];
		$adId = $Details['NZK0OZ'];
		$todayOpen = $Details['O8HQJQ'];
		$totalOpen = $Details['Y4L931'];
		$dayy = $Details['R4O044'];
		$ipaddress = $this->getIp();
		$date = date('Y-m-d');
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();

		$country = "IN";
		$data = array(
			array('day_id' => "1", 'day_points' => "5"),

			array('day_id' => "2", 'day_points' => "10"),

			array('day_id' => "3", 'day_points' => "15"),

			array('day_id' => "4", 'day_points' => "20"),

			array('day_id' => "5", 'day_points' => "25"),

			array('day_id' => "6", 'day_points' => "30"),

			array('day_id' => "7", 'day_points' => "35"),

			array('day_id' => "8", 'day_points' => "40"),

			array('day_id' => "9", 'day_points' => "45"),

			array('day_id' => "10", 'day_points' => "50"),

			array('day_id' => "11", 'day_points' => "60"),

			array('day_id' => "12", 'day_points' => "70"),

			array('day_id' => "13", 'day_points' => "80"),

			array('day_id' => "14", 'day_points' => "90"),

			array('day_id' => "15", 'day_points' => "100")
		);


		$imploded = "0";
		if (strlen($userId) > 0 && $userId != "0") {
			$sqlCampId = mysqli_query($this->db, "SELECT campaignId FROM cpalead WHERE userId = '" . $userId . "' GROUP BY campaignId ");
			$NumRowsId = mysqli_num_rows($sqlCampId);
			if ($NumRowsId > 0) {
				while ($row =  mysqli_fetch_array($sqlCampId, MYSQLI_ASSOC)) {
					$rows[] = $row['campaignId'];
				}
				$imploded = implode(',', $rows);
			}
		}

		$tasklist = mysqli_query($this->db, "SELECT id,title,icon,description,images,points,url,screenNo,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE  campaignId NOT IN  (" . $imploded . ") AND isActive = '1' order by RAND() LIMIT 5");
		if (mysqli_num_rows($tasklist) > 0) {
			while ($rlt11 = mysqli_fetch_array($tasklist, MYSQLI_ASSOC)) {
				$rlt11['screenNo'] = "12";
				$result['taskList'][] = $rlt11;
			}
		}
		/////////////// WATCH WEBSITE //////////
		$result['dailyBonus']['isWatchWebsite'] = "0";
		$result['dailyBonus']['watchWebsiteUrl'] = "https://sportsgurupro.com";
		$result['dailyBonus']['watchWebsiteTime'] = "20"; // in seconds
		//////////////////////////////////////////
		$result['dailyBonus']['data'] = $data;
		$totalTodayTask = 0;
		if (strlen($userId) > 0) {
			$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayTask = mysqli_num_rows($sql1);
			$result['todayCompletedTask'] = $totalTodayTask;

			$ep1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "'  ");
			$ep = $ep1->fetch_assoc();
			$result['earningPoint'] = $ep['earningPoint'];

			$lastDay = mysqli_query($this->db, "SELECT no_of_day,isReset,add_date FROM daily_attendance_point WHERE userId = '" . $userId . "'   ORDER BY id DESC limit 1");
			$day = mysqli_fetch_array($lastDay, MYSQLI_ASSOC);
			$isReset = $day['isReset'];
			$lastDay = $day['no_of_day'];
			$addDate = $day['add_date'];
			$dateDiffer = $this->dateDiffInDays($date, $addDate);

			$Today = $lastDay + 1;

			$isToday =  $dayy - $lastDay;

			if ($isReset == "0") {
				$result['dailyBonus']['lastClaimedDay'] = $day['no_of_day'];
				if ($dateDiffer == '0') {
					$result['dailyBonus']['isTodayClaimed'] = "1";
				} elseif ($dateDiffer == '1') {
					$result['dailyBonus']['isTodayClaimed'] = "0";
				} else {
					$result['dailyBonus']['lastClaimedDay'] = '0';
					$result['dailyBonus']['isTodayClaimed'] = "0";
				}
			} else {
				if ($dateDiffer == '0') {
					$result['dailyBonus']['lastClaimedDay'] = '10';
					$result['dailyBonus']['isTodayClaimed'] = "1";
				} else {
					$result['dailyBonus']['lastClaimedDay'] = '0';
					$result['dailyBonus']['isTodayClaimed'] = "0";
				}
			}

			$result['message'] = "Data Found";
			$result['status'] = "1";
		} else {
			$totalTodayTask = 100000;
			$result['todayCompletedTask'] = "100000";
			$result['dailyBonus']['lastClaimedDay'] = '0';
			$result['dailyBonus']['isTodayClaimed'] = "0";
			$result['message'] = "You have to login to earn money";
			$result['status'] = "1";
		}

		$totalTodayTask = 100000;
		$result['todayCompletedTask'] = "100000";

		$i = -1;
		$newUserId = $userId;
		if (strlen($userId) == 0 && (int)$userId == 0) {
			$newUserId = "GU_" . rand(10, 1000000);
		}

       //torox

		// $i++;
		// $result['rewardDataList'][$i]['title'] = "";
		// $result['rewardDataList'][$i]['image'] = "https://eazyearning.com/Api/images/torox.png";
		// $result['rewardDataList'][$i]['url'] = "";
		// $result['rewardDataList'][$i]['displayImage'] = "https://eazyearning.com/Api/images/torox.png";
		// $result['rewardDataList'][$i]['type'] = "singleslider";
		// $result['rewardDataList'][$i]['isViewAll'] = "0";
		// $result['rewardDataList'][$i]['isBorder'] = "0";
		// $result['rewardDataList'][$i]['screenNo'] = "2";
		// $result['rewardDataList'][$i]['bgColor'] = "#FFFFFF";
		// $data = array(
		// 	array("image" => 'https://eazyearning.com/Api/images/torox.png', "screenNo" => '2')
		// );
		// $result['rewardDataList'][$i]['data'] = $data;

        // pubscale

		// $i++;
		// $result['rewardDataList'][$i]['title'] = "";
		// $result['rewardDataList'][$i]['image'] = "https://eazyearning.com/Api/images/pubscale.png";
		// $result['rewardDataList'][$i]['url'] = "";
		// $result['rewardDataList'][$i]['displayImage'] = "https://eazyearning.com/Api/images/pubscale.png";
		// $result['rewardDataList'][$i]['type'] = "singleslider";
		// $result['rewardDataList'][$i]['isViewAll'] = "0";
		// $result['rewardDataList'][$i]['isBorder'] = "0";
		// $result['rewardDataList'][$i]['screenNo'] = "2";
		// $result['rewardDataList'][$i]['bgColor'] = "#FFFFFF";
		// $data = array(
		// 	array("image" => 'https://eazyearning.com/Api/images/pubscale.png', "screenNo" => '2')
		// );
		// $result['rewardDataList'][$i]['data'] = $data;
 
		// 15 days login

		$i++;
		$result['rewardDataList'][$i]['title'] = "";
		$result['rewardDataList'][$i]['image'] = "https://eazyearning.com/Api/images/15days.png";
		$result['rewardDataList'][$i]['url'] = "";
		$result['rewardDataList'][$i]['displayImage'] = "https://eazyearning.com/Api/images/15days.png'";
		$result['rewardDataList'][$i]['type'] = "singleslider";
		$result['rewardDataList'][$i]['isViewAll'] = "0";
		$result['rewardDataList'][$i]['isBorder'] = "0";
		$result['rewardDataList'][$i]['screenNo'] = "51";
		$result['rewardDataList'][$i]['bgColor'] = "#FFFFFF";
		$data = array(
			array("image" => 'https://eazyearning.com/Api/images/15days.png', "screenNo" => '51')
		);
		$result['rewardDataList'][$i]['data'] = $data;


		//playtimes and adjump

		$i++;
		$result['rewardDataList'][$i]['isTodayTaskCompleted'] = "1";
		$result['rewardDataList'][$i]['note'] = "Earn upto 150 points daily!";
		$result['rewardDataList'][$i]['iconBGColor'] = "#2C63FE";
		$result['rewardDataList'][$i]['title'] = "Easy Earning Deals";
		$result['rewardDataList'][$i]['subTitle'] = "";
		$result['rewardDataList'][$i]['type'] = "grid";
		$result['rewardDataList'][$i]['isViewAll'] = "0";
		$result['rewardDataList'][$i]['isBorder'] = "0";
		$result['rewardDataList'][$i]['icon'] = "https://cdn-icons-png.flaticon.com/128/560/560514.png";
		$result['rewardDataList'][$i]['isActive'] = "1";
		$result['rewardDataList'][$i]['screenNo'] = "0";
		$result['rewardDataList'][$i]['columnCount'] = "2";
		$result['rewardDataList'][$i]['bgColor'] = "#F0F4FF";

		$j = 0;
		$gridData[$j]['isTodayTaskCompleted'] = "1";
		$gridData[$j]['taskCount'] = "3";
		$gridData[$j]['note'] = "Earn upto 220";
		$gridData[$j]['iconBGColor'] = "#FBB41A";
		$gridData[$j]['title'] = "Invite & Earn";
		$gridData[$j]['subTitle'] = "Invite & Earn Your Friend and earn reward!";
		$gridData[$j]['type'] = "inviteearn";
		$gridData[$j]['isViewAll'] = "0";
		$gridData[$j]['isBorder'] = "0";
		$gridData[$j]['icon'] = "https://eazyearning.com/add_image/62_dailylogin210.png";
		$gridData[$j]['isActive'] = "1";
		$gridData[$j]['screenNo'] = "8";
		$gridData[$j]['bgColor'] = "#FEFAEF";
		$gridData[$j]['image'] = "https://eazyearning.com/Api/images/plgames.png";


		$j++;
		$gridData[$j]['note'] = "Big earn!";
		$gridData[$j]['taskCount'] = "3";
		$gridData[$j]['iconBGColor'] = "#FF5E5B";
		$gridData[$j]['url'] = "";
		$gridData[$j]['title'] = "Text Typing";
		$gridData[$j]['subTitle'] = "Play Text Typing Game and EARN!";
		$gridData[$j]['type'] = "texttyping";
		$gridData[$j]['isViewAll'] = "0";
		$gridData[$j]['isBorder'] = "1";
		$gridData[$j]['icon'] = "https://eazyearning.com/add_image/89_earnmore21.png";
		$gridData[$j]['isActive'] = "1";
		$gridData[$j]['screenNo'] = "66";
		$gridData[$j]['bgColor'] = "#FFF3F3";
		$gridData[$j]['image'] = "https://eazyearning.com/Api/images/plgames.png";

		$result['rewardDataList'][$i]['data'] = $gridData;


       // shar and earn
		
	   $i++;
	   $result['rewardDataList'][$i]['title'] = "";
	   $result['rewardDataList'][$i]['image'] = "https://eazyearning.com/Api/images/ahare.png";
	   $result['rewardDataList'][$i]['url'] = "";
	   $result['rewardDataList'][$i]['displayImage'] = "https://eazyearning.com/Api/images/ahare.png";
	   $result['rewardDataList'][$i]['type'] = "singleslider";
	   $result['rewardDataList'][$i]['isViewAll'] = "0";
	   $result['rewardDataList'][$i]['isBorder'] = "0";
	   $result['rewardDataList'][$i]['screenNo'] = "57";
	   $result['rewardDataList'][$i]['bgColor'] = "#FFFFFF";
	   $data = array(
		   array("image" => 'https://eazyearning.com/Api/images/ahare.png', "screenNo" => '57')
	   );
	   $result['rewardDataList'][$i]['data'] = $data;

        //everflow

		$i++;
		$result['rewardDataList'][$i]['title'] = "Special Offerwalls";
		$result['rewardDataList'][$i]['image'] = "https://eazyearning.com/Api/images/everfloqw.png";
		$result['rewardDataList'][$i]['url'] = "https://eazyearning.com/everflow_file/everflow.php?userId=" . $newUserId . "&gaid=" . $adId;
		$result['rewardDataList'][$i]['displayImage'] = "";
		$result['rewardDataList'][$i]['type'] = "singleslider";
		$result['rewardDataList'][$i]['isViewAll'] = "0";
		$result['rewardDataList'][$i]['isBorder'] = "0";
		$result['rewardDataList'][$i]['screenNo'] = "15";
		$result['rewardDataList'][$i]['bgColor'] = "#FFFFFF";
		$data1 = array(
			array("image" => 'https://eazyearning.com/Api/images/everfloqw.png', "url" => "https://eazyearning.com/RewardGuru/everflow_file/index.php?userId=" . $newUserId . "&gaid=" . $adId, "screenNo" => '15')
		);
		$result['rewardDataList'][$i]['data'] = $data1;

	    // appsprize

		// $i++;
		// $result['rewardDataList'][$i]['title'] = "";
		// $result['rewardDataList'][$i]['image'] = "https://eazyearning.com/Api/images/appsprize.png";
		// $result['rewardDataList'][$i]['url'] = "";
		// $result['rewardDataList'][$i]['displayImage'] = "https://eazyearning.com/Api/images/appsprize.png";
		// $result['rewardDataList'][$i]['type'] = "singleslider";
		// $result['rewardDataList'][$i]['isViewAll'] = "0";
		// $result['rewardDataList'][$i]['isBorder'] = "0";
		// $result['rewardDataList'][$i]['screenNo'] = "57";
		// $result['rewardDataList'][$i]['bgColor'] = "#FFFFFF";
		// $data = array(
		// 	array("image" => 'https://eazyearning.com/Api/images/appsprize.png', "screenNo" => '57')
		// );
		// $result['rewardDataList'][$i]['data'] = $data;
 
         // giveaway
		 
		$i++;
		$result['rewardDataList'][$i]['title'] = "";
		$result['rewardDataList'][$i]['image'] = "https://eazyearning.com/Api/images/giveaway8.png";
		$result['rewardDataList'][$i]['url'] = "";
		$result['rewardDataList'][$i]['displayImage'] = "https://eazyearning.com/Api/images/giveaway8.png";
		$result['rewardDataList'][$i]['type'] = "singleslider";
		$result['rewardDataList'][$i]['isViewAll'] = "0";
		$result['rewardDataList'][$i]['isBorder'] = "0";
		$result['rewardDataList'][$i]['screenNo'] = "57";
		$result['rewardDataList'][$i]['bgColor'] = "#FFFFFF";
		$data = array(
			array("image" => 'https://eazyearning.com/Api/images/giveaway8.png', "screenNo" => '57')
		);
		$result['rewardDataList'][$i]['data'] = $data;

		

		if ($country == "IN") {

			$i++;
			$result['rewardDataList'][$i]['type'] = "nativeAd";
		}
		// $i++;
		// $result['rewardDataList'][$i]['title'] = "";
		// $result['rewardDataList'][$i]['image'] = "https://gotask.co.in/add_image/32_everflow.png";
		// $result['rewardDataList'][$i]['url'] = "";
		// $result['rewardDataList'][$i]['displayImage'] = "https://gotask.co.in/add_image/32_everflow.png";
		// $result['rewardDataList'][$i]['type'] = "singleslider";
		// $result['rewardDataList'][$i]['isViewAll'] = "0";
		// $result['rewardDataList'][$i]['isBorder'] = "0";
		// $result['rewardDataList'][$i]['screenNo'] = "61";
		// $result['rewardDataList'][$i]['bgColor'] = "#FFFFFF";
		// $data = array(
		// 	array("image" => 'https://gotask.co.in/add_image/32_everflow.png', "url" => "", "screenNo" => '61')
		// );
		// $result['rewardDataList'][$i]['data'] = $data;



		// HOME DIALOG
		$resHomediloag = mysqli_query($this->db, "SELECT * FROM home_popup WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ORDER BY id DESC limit 1 ");
		if ($resHomediloag->num_rows > 0) {
			$result['homeDialog'] = $resHomediloag->fetch_assoc();
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['footerImage'] = "https://mycashbazar.com/Api/upload/rewardpagefooter.png";

		$result['isShowGiveawayCode'] = "0";
		$result['giveawayCode'] = "Game100";

		$result['isShowAdjoeLeaderboardIcon'] = "0";

		if (strlen($userId) > 0) {
			$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Daily Login Challenge.";
				$result['taskButton'] = "Complete Easy Task Now";
				//$result['taskId'] = "1";
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		$this->response($this->json($result), 200);
	}



	//getDailyBonus

	private function SDFVGBN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$Details = json_decode($this->_request['details'], true);

		// $decrypted = PHP_AES_Cipher::decrypt(self::Mkey, $this->_request['details']);
		// $Details = json_decode($decrypted, true);
		// $decrypted = MCrypt::decrypt($this->_request['details']);
		// $Details = json_decode($decrypted, true);
		$token = $Details['CV56BBBN'];
		$userId = $Details['YU76HHH'];
		$appVersion = $Details['KL9JHH'];
		$deviceName = $Details['SDC3XX'];
		$deviseId = $Details['CFRE4FV'];
		$adId = $Details['IUO8JJF'];
		$todayOpen = $Details['AQW2EED'];
		$totalOpen = $Details['ZXC34SD'];
		$dayy = $Details['NMBHH9J'];
		$ipaddress = $this->getIp();
		$date = date('Y-m-d');
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$country = $ip_detail['country'];
		$result = array();


		$data = array(
			array('day_id' => "1", 'day_points' => "5"),

			array('day_id' => "2", 'day_points' => "10"),

			array('day_id' => "3", 'day_points' => "15"),

			array('day_id' => "4", 'day_points' => "20"),

			array('day_id' => "5", 'day_points' => "25"),

			array('day_id' => "6", 'day_points' => "30"),

			array('day_id' => "7", 'day_points' => "35"),

			array('day_id' => "8", 'day_points' => "40"),

			array('day_id' => "9", 'day_points' => "45"),

			array('day_id' => "10", 'day_points' => "50"),

			array('day_id' => "11", 'day_points' => "60"),

			array('day_id' => "12", 'day_points' => "70"),

			array('day_id' => "13", 'day_points' => "80"),

			array('day_id' => "14", 'day_points' => "90"),

			array('day_id' => "15", 'day_points' => "100")
		);
		$result['dailyBonus']['data'] = $data;
		if (strlen($userId) > 0) {
			$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayTask = mysqli_num_rows($sql1);
			$totalTodayTask = 1;
			$result['todayCompletedTask'] = $totalTodayTask;

			$ep1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "'  ");
			$ep = $ep1->fetch_assoc();
			$result['earningPoint'] = $ep['earningPoint'];

			$lastDay = mysqli_query($this->db, "SELECT no_of_day,isReset,add_date FROM daily_attendance_point WHERE userId = '" . $userId . "'   ORDER BY id DESC limit 1");
			$day = mysqli_fetch_array($lastDay, MYSQLI_ASSOC);
			$isReset = $day['isReset'];
			$lastDay = $day['no_of_day'];
			$addDate = $day['add_date'];
			$dateDiffer = $this->dateDiffInDays($date, $addDate);

			$Today = $lastDay + 1;

			$isToday =  $dayy - $lastDay;

			if ($isReset == "0") {
				$result['dailyBonus']['lastClaimedDay'] = $day['no_of_day'];
				if ($dateDiffer == '0') {
					$result['dailyBonus']['isTodayClaimed'] = "1";
				} elseif ($dateDiffer == '1') {
					$result['dailyBonus']['isTodayClaimed'] = "0";
				} else {
					$result['dailyBonus']['lastClaimedDay'] = '0';
					$result['dailyBonus']['isTodayClaimed'] = "0";
				}
			} else {
				if ($dateDiffer == '0') {
					$result['dailyBonus']['lastClaimedDay'] = '10';
					$result['dailyBonus']['isTodayClaimed'] = "1";
				} else {
					$result['dailyBonus']['lastClaimedDay'] = '0';
					$result['dailyBonus']['isTodayClaimed'] = "0";
				}
			}
		}
		$result['message'] = "Data Found";
		$result['status'] = "1";

		if ($totalTodayTask > 0) {
			$result['isTodayTaskCompleted'] = "1";
		} else {
			$result['dailyBonus']['lastClaimedDay'] = '0';
			$result['dailyBonus']['isTodayClaimed'] = "0";
			$result['isTodayTaskCompleted'] = "0";
			$result['taskNote'] = "Please Complete Today Easy Task to claim your daily Reward.";
			$result['taskButton'] = "Complete Easy Task Now";
			$result['taskId'] = "1";
		}

		$this->response($this->json($result), 200);
	}


//HomeData
private function JENNA()
{
	if ($this->get_request_method() != "POST") {
		$this->response('', 406);
	}

	// $Details = json_decode($this->_request['details'], true);
	$decrypted = MCrypt::decrypt($this->_request['details']);
	$Details = json_decode($decrypted, true);
	$token = $Details['2Q7AEV'];
	$userId = $Details['Q2RHUR'];
	$appVersion = $Details['YWCDWZ'];
	$deviceName = $Details['KG1GUL'];
	$deviseId = $Details['TVO2PP'];
	$adId = $Details['Y8YOCE'];
	$todayOpen = $Details['OGDGDN'];
	$totalOpen = $Details['RWKL7B'];
	$dayy = $Details['WD2875'];
	$ipaddress = $this->getIp();
	$ip_detail['country'] = $this->iptocountry($ipaddress);
	$country = $ip_detail['country'];
	$date = date('Y-m-d');
	$result = array();
	$totaleverflow = "1000";
	$totalpubscale = "1000";
	$totaappsprize = "1000";
	$totaadjump = "1000";
	$totaoffertoro = "1000";
	global $WelcomeBonusPoint;

	// echo $userId;
	// $result['jhdfdf'] = $Details;
	// $userId = $Details['AOZ7OI'];

	if ($todayOpen == 1 && $totalOpen == 1) {
		$querry2 = mysqli_query($this->db, "UPDATE daily_attendance_point SET isReset= '1'  WHERE  userId = '" . $userId . "' ORDER BY id DESC LIMTI 1 ");
	}

	$result['fakeEarningPoint'] = "0";
	$result['packageInstallTrackingUrl'] = "http://surgex.media-412.com/click?escape=subs";
	$result['pid'] = "9";
	$result['offer_id'] = "1548";


	$result['nextWithdrawAmount'] = "5";

	$i = -1;


	if (strlen($userId) > 0) {
		$setting = mysqli_query($this->db, "SELECT * FROM user_master WHERE  userId = '" . $userId . "' ");
		if ($setting->num_rows > 0) {
			$everflow_query = mysqli_query($this->db, "SELECT SUM(coin_amount) as coin_amount FROM `everflow_history` WHERE userId='" . $userId . "'");

			if ($everflow_query->num_rows > 0) {

				$everflow = mysqli_fetch_assoc($everflow_query);
				$everflow  = $everflow['coin_amount'];
				$everflow_row = ($everflow * 100) / $totaleverflow;
			} else {
				$everflow_row = "0";
			}


			$pubscale_query = mysqli_query($this->db, "SELECT SUM(coin_amount) as coin_amount FROM `pubscale_history` WHERE userId='" . $userId . "'");
			if ($pubscale_query->num_rows > 0) {

				$pubscale1 = mysqli_fetch_assoc($pubscale_query);
				$pubscale2  = $pubscale1['coin_amount'];
				$pubscale_row = ($pubscale2 * 100) / $totalpubscale;
			} else {
				$pubscale_row = "0";
			}


			$appsprize_query = mysqli_query($this->db, "SELECT SUM(coin_amount) as coin_amount FROM `appsprize_history` WHERE userId='" . $userId . "'");

			if ($appsprize_query->num_rows > 0) {

				$appsprize = mysqli_fetch_assoc($appsprize_query);
				$appsprize  = $appsprize['coin_amount'];
				$appsprize_row = ($appsprize * 100) / $totaappsprize;
			} else {
				$appsprize_row = "0";
			}


			$adjump_query = mysqli_query($this->db, "SELECT SUM(coin_amount) as coin_amount FROM `adjump_history` WHERE userId='" . $userId . "'");

			if ($adjump_query->num_rows > 0) {

				$adjump = mysqli_fetch_assoc($adjump_query);
				$adjump  = $adjump['coin_amount'];
				$adjump_row = ($adjump * 100) / $totaadjump;
			} else {
				$appsprize_row = "0";
			}



			$offertoro_query = mysqli_query($this->db, "SELECT SUM(coin_amount) as coin_amount FROM `offertoro_history` WHERE userId='" . $userId . "'");

			if ($offertoro_query->num_rows > 0) {

				$offertoro = mysqli_fetch_assoc($offertoro_query);
				$offertoro  = $offertoro['coin_amount'];
				$offertoro_row = ($offertoro * 100) / $totaoffertoro;
			} else {
				$appsprize_row = "0";
			}
		}
	}

	// $data = array(

	// 	// array("image" => 'https://myrewardwallet.com/App/AppImage/HomeGrid/500.png', "screenNo" => '11'),
	// 	array("image" => 'https://gotask.co.in/Api/images/home/img/earningpubscale.png', "screenNo" => '51', "Progress" => isset($pubscale_row) ? $pubscale_row : "0", "name" => "pubscale"),
	// 	array("image" => 'https://gotask.co.in/Api/images/home/img/earningappprize.png', "screenNo" => '43', "Progress" => isset($appsprize_row) ? $appsprize_row : "0", "name" => "appsprize"),
	// 	array("image" => 'https://gotask.co.in/Api/images/home/img/earningeverflow.png', "screenNo" => '61', "Progress" => isset($everflow_row) ? $everflow_row : "0", "name" => "everflow"),
	// 	array("image" => 'https://gotask.co.in/Api/images/home/img/earningtorox.png', "screenNo" => '59', "Progress" => isset($offertoro_row) ? $offertoro_row : "0", "name" => "Torox"),
	// 	array("image" => 'https://gotask.co.in/Api/images/home/img/earningadjump.png', "screenNo" => '54', "Progress" => isset($adjump_row) ? $adjump_row : "0", "name" => "adjump"),
	// 	// array("image" => 'https://gotask.co.in/Api/images/home/img/PAYLTIME123.png', "screenNo" => '31'),
	// 	// array("image" => 'https://myrewardwallet.com/App/AppImage/adjpop.png', "screenNo" => '31')

	// );
	// $i++;
	// $result['mainDataList'][$i]['title'] = "Your Earning Progress";
	// $result['mainDataList'][$i]['type'] = "EarningProgress";
	// $result['mainDataList'][$i]['data'] = $data;



   $newUserId = $userId;
   if (strlen($userId) == 0 && (int)$userId == 0) {
	   $newUserId = "GU_" . rand(10, 1000000);
   }

      // earn extra and earning points

	$i++;
	$result['mainDataList'][$i]['isTodayTaskCompleted'] = "1";
	$result['mainDataList'][$i]['note'] = "Earn upto 150 points daily!";
	$result['mainDataList'][$i]['iconBGColor'] = "#2C63FE";
	$result['mainDataList'][$i]['title'] = "Easy Earning Deals";
	$result['mainDataList'][$i]['subTitle'] = "";
	$result['mainDataList'][$i]['type'] = "grid";
	$result['mainDataList'][$i]['isViewAll'] = "0";
	$result['mainDataList'][$i]['isBorder'] = "0";
	$result['mainDataList'][$i]['icon'] = "https://cdn-icons-png.flaticon.com/128/560/560514.png";
	$result['mainDataList'][$i]['isActive'] = "1";
	$result['mainDataList'][$i]['screenNo'] = "0";
	$result['mainDataList'][$i]['columnCount'] = "2";
	$result['mainDataList'][$i]['bgColor'] = "#F0F4FF";

	$j = 0;
	$gridData[$j]['isTodayTaskCompleted'] = "1";
	$gridData[$j]['taskCount'] = "3";
	$gridData[$j]['note'] = "Earn upto 220";
	$gridData[$j]['iconBGColor'] = "#FBB41A";
	$gridData[$j]['title'] = "Invite & Earn";
	$gridData[$j]['subTitle'] = "Invite & Earn Your Friend and earn reward!";
	$gridData[$j]['type'] = "inviteearn";
	$gridData[$j]['isViewAll'] = "0";
	$gridData[$j]['isBorder'] = "0";
	$gridData[$j]['icon'] = "https://cdn-icons-png.flaticon.com/128/3437/3437362.png";
	$gridData[$j]['isActive'] = "1";
	$gridData[$j]['screenNo'] = "63";
	$gridData[$j]['bgColor'] = "#FEFAEF";
	$gridData[$j]['fullImage'] = "https://eazyearning.com/Api/images/earn.png";


	$j++;
	$gridData[$j]['note'] = "Big earn!";
	$gridData[$j]['taskCount'] = "3";
	$gridData[$j]['iconBGColor'] = "#FF5E5B";
	
	$gridData[$j]['title'] = "Text Typing";
	$gridData[$j]['subTitle'] = "Play Text Typing Game and EARN!";
	$gridData[$j]['type'] = "texttyping";
	$gridData[$j]['isViewAll'] = "0";
	$gridData[$j]['isBorder'] = "1";
	$gridData[$j]['icon'] = "https://eazyearning.com/Api/images/ic_number_puzzle.png";
	$gridData[$j]['isActive'] = "1";
	$gridData[$j]['screenNo'] = "64";
	$gridData[$j]['bgColor'] = "#FFF3F3";
	$gridData[$j]['fullImage'] = "https://eazyearning.com/Api/images/15dya.png";

	$result['mainDataList'][$i]['gridData'] = $gridData;

	
//envite and earn
	
$i++;
$result['mainDataList'][$i]['title'] = "";
$result['mainDataList'][$i]['image'] = "https://eazyearning.com/Api/images/inviteearn.png";
$result['mainDataList'][$i]['url'] = "";
$result['mainDataList'][$i]['displayImage'] = "";
$result['mainDataList'][$i]['type'] = "singleslider";
$result['mainDataList'][$i]['isViewAll'] = "0";
$result['mainDataList'][$i]['isBorder'] = "0";
$result['mainDataList'][$i]['screenNo'] = "19";
$result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
$data1 = array(
	array("image" => 'https://eazyearning.com/Api/images/inviteearn.png', "screenNo" => '19')
);
$result['mainDataList'][$i]['data'] = $data1;


	//everflow

	$i++;
	$result['mainDataList'][$i]['title'] = "Special Offerwalls";
	$result['mainDataList'][$i]['image'] = "https://eazyearning.com/Api/images/everflow.png";
	$result['mainDataList'][$i]['url'] = "https://eazyearning.com/everflow_file/everflow.php?userId=" . $newUserId . "&gaid=" . $adId;
	$result['mainDataList'][$i]['displayImage'] = "";
	$result['mainDataList'][$i]['type'] = "singleslider";
	$result['mainDataList'][$i]['isViewAll'] = "0";
	$result['mainDataList'][$i]['isBorder'] = "0";
	$result['mainDataList'][$i]['screenNo'] = "15";
	$result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	$data1 = array(
		array("image" => 'https://eazyearning.com/Api/images/everflow.png', "url" => "https://eazyearning.com/RewardGuru/everflow_file/index.php?userId=" . $newUserId . "&gaid=" . $adId, "screenNo" => '15')
	);
	$result['mainDataList'][$i]['data'] = $data1;
	
// $i++;
// $result['mainDataList'][$i]['title'] = "";
// $result['mainDataList'][$i]['image'] = "https://gotask.co.in/Api/images/dotparing678.png";
// $result['mainDataList'][$i]['url'] = "";
// $result['mainDataList'][$i]['displayImage'] = "";
// $result['mainDataList'][$i]['type'] = "singleslider";
// $result['mainDataList'][$i]['isViewAll'] = "0";
// $result['mainDataList'][$i]['isBorder'] = "0";
// $result['mainDataList'][$i]['screenNo'] = "7";
// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
// $data1 = array(
// 	array("image" => 'https://gotask.co.in/Api/images/dotparing678.png', "screenNo" => '7')
// );
// $result['mainDataList'][$i]['data'] = $data1;



	// $i++;
	// $result['mainDataList'][$i]['isTodayTaskCompleted'] = "1";
	// $result['mainDataList'][$i]['note'] = "Earn upto 150 points daily!";
	// $result['mainDataList'][$i]['iconBGColor'] = "#2C63FE";
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['subTitle'] = "";
	// $result['mainDataList'][$i]['type'] = "grid";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['icon'] = "https://cdn-icons-png.flaticon.com/128/560/560514.png";
	// $result['mainDataList'][$i]['isActive'] = "1";
	// $result['mainDataList'][$i]['screenNo'] = "0";
	// $result['mainDataList'][$i]['columnCount'] = "2";
	// $result['mainDataList'][$i]['bgColor'] = "#F0F4FF";

	// $j = 0;
	// // $gridData[$j]['isTodayTaskCompleted'] = "1";
	// // $gridData[$j]['taskCount'] = "3";
	// // $gridData[$j]['note'] = "Earn upto 220";
	// // $gridData[$j]['iconBGColor'] = "#FBB41A";
	// // $gridData[$j]['title'] = "Invite & Earn";
	// // $gridData[$j]['subTitle'] = "Invite & Earn Your Friend and earn reward!";
	// // $gridData[$j]['type'] = "inviteearn";
	// // $gridData[$j]['isViewAll'] = "0";
	// // $gridData[$j]['isBorder'] = "0";
	// // $gridData[$j]['icon'] = "https://gotask.co.in/Api/images/home/appsprize21.png";
	// // $gridData[$j]['isActive'] = "1";
	// // $gridData[$j]['screenNo'] = "57";
	// // $gridData[$j]['bgColor'] = "#FEFAEF";
	// // $gridData[$j]['fullImage'] = "https://gotask.co.in/Api/images/home/appsprize21.png";


	// $j++;
	// $gridData[$j]['note'] = "Big earn!";
	// $gridData[$j]['taskCount'] = "3";
	// $gridData[$j]['iconBGColor'] = "#FF5E5B";

	// $gridData[$j]['title'] = "Pubscale";
	// $gridData[$j]['subTitle'] = "Play Game and EARN!";
	// $gridData[$j]['type'] = "Pubscale";
	// $gridData[$j]['isViewAll'] = "0";
	// $gridData[$j]['isBorder'] = "1";
	// $gridData[$j]['icon'] = "https://gotask.co.in/Api/images/home/playtime21.png";
	// $gridData[$j]['isActive'] = "1";
	// $gridData[$j]['screenNo'] = "2";
	// $gridData[$j]['bgColor'] = "#FFF3F3";
	// $gridData[$j]['fullImage'] = "https://gotask.co.in/Api/images/home/playtime21.png";

	// $result['mainDataList'][$i]['gridData'] = $gridData;

	/////////
	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['image'] = "https://gotask.co.in/Api/images/home/E5.png";
	// $result['mainDataList'][$i]['url'] = "";
	// $result['mainDataList'][$i]['displayImage'] = "";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "54";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// $data1 = array(
	// 	array("image" => 'https://gotask.co.in/Api/images/home/E5.png', "screenNo" => '54')
	// );

	// $result['mainDataList'][$i]['data'] = $data1;

	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['image'] = "https://gotask.co.in/Api/images/playtime156.png";
	// $result['mainDataList'][$i]['url'] = "";
	// $result['mainDataList'][$i]['displayImage'] = "";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "3";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// $data1 = array(
	// 	array("image" => 'https://gotask.co.in/Api/images/playtime156.png', "screenNo" => '3')
	// );
	// $result['mainDataList'][$i]['data'] = $data1;



	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['image'] = "https://gotask.co.in/Api/images/spin9877.png";
	// $result['mainDataList'][$i]['url'] = '';
	// $result['mainDataList'][$i]['displayImage'] = "";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "6";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// $data1 = array(
	// 	array("image" => 'https://gotask.co.in/Api/images/spin9877.png', "screenNo" => '6')
	// );
	// $result['mainDataList'][$i]['data'] = $data1;


	/////////


	// $i++;
	// $result['mainDataList'][$i]['isTodayTaskCompleted'] = "1";
	// $result['mainDataList'][$i]['note'] = "Earn upto 150 points daily!";
	// $result['mainDataList'][$i]['iconBGColor'] = "#2C63FE";
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['subTitle'] = "";
	// $result['mainDataList'][$i]['type'] = "grid";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['icon'] = "https://cdn-icons-png.flaticon.com/128/560/560514.png";
	// $result['mainDataList'][$i]['isActive'] = "1";
	// $result['mainDataList'][$i]['screenNo'] = "0";
	// $result['mainDataList'][$i]['columnCount'] = "2";
	// $result['mainDataList'][$i]['bgColor'] = "#F0F4FF";

	// $j = 0;
	// $gridData[$j]['isTodayTaskCompleted'] = "1";
	// $gridData[$j]['taskCount'] = "3";
	// $gridData[$j]['note'] = "Earn upto 220";
	// $gridData[$j]['iconBGColor'] = "#FBB41A";
	// $gridData[$j]['title'] = "Invite & Earn";
	// $gridData[$j]['subTitle'] = "Invite & Earn Your Friend and earn reward!";
	// $gridData[$j]['type'] = "inviteearn";
	// $gridData[$j]['isViewAll'] = "0";
	// $gridData[$j]['isBorder'] = "0";
	// $gridData[$j]['icon'] = "https://gotask.co.in/Api/images/home/daily21.png";
	// $gridData[$j]['isActive'] = "1";
	// $gridData[$j]['screenNo'] = "8";
	// $gridData[$j]['bgColor'] = "#FEFAEF";
	// $gridData[$j]['fullImage'] = "https://gotask.co.in/Api/images/home/daily21.png";


	// $j++;
	// $gridData[$j]['note'] = "Big earn!";
	// $gridData[$j]['taskCount'] = "3";
	// $gridData[$j]['iconBGColor'] = "#FF5E5B";
	// $gridData[$j]['title'] = "Pubscale";
	// $gridData[$j]['subTitle'] = "Play Game and EARN!";
	// $gridData[$j]['type'] = "Pubscale";
	// $gridData[$j]['isViewAll'] = "0";
	// $gridData[$j]['isBorder'] = "1";
	// $gridData[$j]['icon'] = "https://gotask.co.in/Api/images/home/earnmore21.png";
	// $gridData[$j]['isActive'] = "1";
	// $gridData[$j]['screenNo'] = "66";
	// $gridData[$j]['bgColor'] = "#FFF3F3";
	// $gridData[$j]['fullImage'] = "https://gotask.co.in/Api/images/home/earnmore21.png";

	// $result['mainDataList'][$i]['gridData'] = $gridData;

	/////////////////////////////

      //task balance

	$tasklist = mysqli_query($this->db, "SELECT id, title, icon, points, url, screenNo, description, endDate 
	FROM task_offer 
	ORDER BY RAND() DESC 
	LIMIT 1");
		if (mysqli_num_rows($tasklist) > 0) {
			
			$rlt11 = mysqli_fetch_array($tasklist, MYSQLI_ASSOC);
				$rlt11['screenNo'] = "65";
				$rlt11['isTaskBalanceDialog'] = "1";
				$result['taskBalance'] = $rlt11;

		}

         //playtimes

	$i++;
	$result['mainDataList'][$i]['title'] = "Ultimate Offerwalls";
	$result['mainDataList'][$i]['image'] = "https://eazyearning.com/Api/images/playtimes.png";
	$result['mainDataList'][$i]['url'] = "";
	$result['mainDataList'][$i]['displayImage'] = "";
	$result['mainDataList'][$i]['type'] = "singleslider";
	$result['mainDataList'][$i]['isViewAll'] = "0";
	$result['mainDataList'][$i]['isBorder'] = "0";
	$result['mainDataList'][$i]['screenNo'] = "31";
	$result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	$data1 = array(
		array("image" => 'https://eazyearning.com/Api/images/playtimes.png', "screenNo" => '31')

	);
	$result['mainDataList'][$i]['data'] = $data1;


	//tasklist

	$imploded = "0";
	if (strlen($userId) > 0 && $userId != "0") {
		$sqlCampId = mysqli_query($this->db, "SELECT campaignId FROM cpalead WHERE userId = '" . $userId . "' GROUP BY campaignId ");
		$NumRowsId = mysqli_num_rows($sqlCampId);
		if ($NumRowsId > 0) {
			while ($row =  mysqli_fetch_array($sqlCampId, MYSQLI_ASSOC)) {
				$rows[] = $row['campaignId'];
			}
			$imploded = implode(',', $rows);
		}
	}


	if ($country != "IN") {
		$result['message'] = "Tasks or Offers are not available.";
		$result['status'] = "2";
	} else {
		$tasklist = mysqli_query($this->db, "SELECT id,title,icon,description,images,points,url,screenNo,tagList,btnColor FROM task_offer WHERE  campaignId NOT IN  (" . $imploded . ") AND isActive = '1'  order by RAND() LIMIT 3");
		if (mysqli_num_rows($tasklist) > 0) {
			$i++;
			$result['mainDataList'][$i]['title'] = "Fast Earning Task";
			$result['mainDataList'][$i]['type'] = "taskList";
			$result['mainDataList'][$i]['isViewAll'] = "1";
			$result['mainDataList'][$i]['isBorder'] = "0";
			$result['mainDataList'][$i]['screenNo'] = "0";
			$result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
			while ($rlt11 = mysqli_fetch_array($tasklist, MYSQLI_ASSOC)) {
				$rlt11['screenNo'] = "65";
				$result['mainDataList'][$i]['data'][] = $rlt11;
			}
		}
	}

	// singletasklist

	$TaskSingle = mysqli_query($this->db, "SELECT id,title,icon,description,images,points,url,screenNo,btnName,btnColor,btnTextColor,isBlink,label,labelBgColor,labelTextColor,descriptionTextColor,titleTextColor,bgColor,isNewLable,displayImage,isShowBanner,isShareTask,ShareTaskPoint FROM task_offer WHERE  campaignId NOT IN  (" . $imploded . ") AND isActive = '1' AND taskType = '6' order by RAND() LIMIT 1");
	if (mysqli_num_rows($TaskSingle) > 0) {
		$i++;
		$result['mainDataList'][$i]['title'] = "Easy Task";
		$result['mainDataList'][$i]['type'] = "singleBigTask";
		$result['mainDataList'][$i]['isViewAll'] = "1";
		$result['mainDataList'][$i]['isBorder'] = "1";
		$result['mainDataList'][$i]['screenNo'] = "0";
		// $result['mainDataList'][$i]['isBlink'] = "1";
		// $result['mainDataList'][$i]['buttonText'] = "Claim Now";
		$result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
		$result['mainDataList'][$i]['pointBackgroundColor'] = "#FF6D00";
		$result['mainDataList'][$i]['pointTextColor'] = "#000000";


		while ($rlt1 = mysqli_fetch_array($TaskSingle, MYSQLI_ASSOC)) {
			$rlt1['screenNo'] = "65";
			$result['mainDataList'][$i]['data'][] = $rlt1;
		}
	}

         //scanandpay slider

	$data = array(
		
		array("image" => 'https://eazyearning.com/Api/images/offerwallimg/pubscale21.png', "screenNo" => '51'),
		// array("image" => 'https://rewardbuddy.co.in/Api/images/offerwallimg/adjump21.png', "screenNo" => '54')
		
	);
	$result['scanAndPaySlider'] = $data;

	// $data = array(

	// 	array("image" => 'https://gotask.co.in/Api/images/home/daily21.png', "screenNo" => '51'),
	// 	array("image" => 'https://gotask.co.in/Api/images/home/earnmore21.png', "screenNo" => '54'),
	// 	// array("image" => 'https://gotask.co.in/Api/images/home/share_with_friend.png', "screenNo" => '50'),
	// 	// array("image" => 'https://gotask.co.in/Api/images/home/share_with_friend.png', "screenNo" => '31')
	// 	// array("image" => 'https://gotask.co.in/New/App/img/EasyEarningcards/4.png', "screenNo" => '31'),
	// 	// array("image" => 'https://gotask.co.in/New/App/img/EasyEarningcards/1.png', "screenNo" => '14'),
	// 	// array("image" => 'https://gotask.co.in/New/App/img/EasyEarningcards/3.png', "screenNo" => '32'),
	// 	// array("image" => 'https://gotask.co.in/New/App/img/EasyEarningcards/2.png', "screenNo" => '8'),
	// 	// array("image" => 'https://gotask.co.in/New/App/img/EasyEarningcards/4.png', "screenNo" => '4')

	// );
	// $result['scanAndPaySlider'] = $data;






	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['image'] = "https://gotask.co.in/Api/images/home/GoTaskpubscale.png";
	// $result['mainDataList'][$i]['url'] = "";
	// $result['mainDataList'][$i]['displayImage'] = "https://gotask.co.in/Api/images/home/GoTaskpubscale.png";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "51";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// $data = array(
	// 	array("image" => 'https://gotask.co.in/Api/images/home/GoTaskpubscale.png', "screenNo" => '51')
	// );
	// $result['mainDataList'][$i]['data'] = $data;

	// Adjump Offerwall
	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['image'] = "https://gotask.co.in/Api/images/home/GoTaskAdjump.png";
	// $result['mainDataList'][$i]['url'] = "";
	// $result['mainDataList'][$i]['displayImage'] = "";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "54";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// $data1 = array(
	// 	array("image" => 'https://gotask.co.in/Api/images/home/GoTaskAdjump.png', "screenNo" => '54')
	// );
	// $result['mainDataList'][$i]['data'] = $data1;

	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['image'] = "https://xreward.in/App/images/Cards/punscale.png";
	// $result['mainDataList'][$i]['url'] = "";
	// $result['mainDataList'][$i]['displayImage'] = "https://cashbackzone.app/App/img/pubscale.json";
	// $result['mainDataList'][$i]['jsonImage'] = "https://cashbackzone.app/App/img/pubscale.json";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "50";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// $data = array(
	// 	// array("image" => 'https://xreward.in/App/upload/ADJUMPQP.json', "screenNo" => '57')
	// 	array("image" => 'https://xreward.in/App/images/extra/apprizw.png', "screenNo" => '57')
	// );
	// $result['mainDataList'][$i]['data'] = $data;



	// $newUserId = $userId;
	// if (strlen($userId) == 0 && (int)$userId == 0) {
	// 	$newUserId = "GU_" . rand(10, 1000000);
	// }
	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['image'] = "https://gotask.co.in/Api/images/banners/home_playtime.png";
	// $result['mainDataList'][$i]['url'] = "";
	// $result['mainDataList'][$i]['displayImage'] = "";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "2";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// $data1 = array(
	// 	array("image" => 'https://gotask.co.in/Api/images/torox.png', "screenNo" => '2', "url" => "https://torox.io/ifr/show/30444/" . $newUserId . "/15466")
	// );
	// $result['mainDataList'][$i]['data'] = $data1;





	// Level Earning
	$sqlstring = "SELECT id FROM tbl_level_earning WHERE isActive = '1' ORDER BY id DESC LIMIT 1";
	$milestonesData = mysqli_query($this->db, $sqlstring);
	if (mysqli_num_rows($milestonesData) > 0) {
		$maxLevelId = mysqli_fetch_array($milestonesData, MYSQLI_NUM)[0];
	}

	$lastClaimDate = date("2023-10-30 00:00:00");
	$sqlCampId = mysqli_query($this->db, "SELECT levelEarningId,entryDate FROM tbl_level_earning_history WHERE userId = '" . $userId . "' ORDER BY id DESC LIMIT 1");
	// $result['qry2'] = "SELECT levelEarningId FROM tbl_level_earning_history WHERE userId = '" . $userId . "' ORDER BY id DESC LIMIT 1";
	$lastClaimedLevelEarningId = 0;
	if (mysqli_num_rows($sqlCampId) > 0) {
		$claimedData = mysqli_fetch_array($sqlCampId, MYSQLI_NUM);
		$lastClaimedLevelEarningId = $claimedData[0];
		$lastClaimDate = $claimedData[1];
	}

	if ($lastClaimedLevelEarningId < $maxLevelId) {

		$sqlstring = "SELECT * FROM tbl_level_earning WHERE id >= $lastClaimedLevelEarningId AND  isActive = '1' ORDER BY id LIMIT 2";
		// $result['qry3'] = $sqlstring;
		$milestonesData = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($milestonesData) > 0 && strlen($userId) > 0 && (int)$userId > 0) {

			while ($rlContest = mysqli_fetch_array($milestonesData, MYSQLI_ASSOC)) {
				$levelEarningCursor[] = $rlContest;
			}
			if ($lastClaimedLevelEarningId == 0) {
				$currentLevelId = $levelEarningCursor[0]['id'];
				$data1 = "Level 0";
				$data2 = "Level 1";
			} else {
				$currentLevelId = $levelEarningCursor[1]['id'];
				$data1 = $levelEarningCursor[0]['title'];
				$data2 = $levelEarningCursor[1]['title'];
			}
		} else {
			$lastClaimedLevelEarningId = 0;
			$data1 = "Level 0";
			$data2 = "Level 1";
			$currentLevelId = 1;
		}

		$sqlstring = "SELECT * FROM tbl_level_earning WHERE id = '" . $currentLevelId . "'";
		// $result['qry4'] = $sqlstring;
		$completionPercent = 0;
		$milestonesData = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($milestonesData) > 0) {
			$rlt = mysqli_fetch_array($milestonesData, MYSQLI_ASSOC);
			$levelEarningPoints = $rlt['points'];

			//////////TASK///////////////		
			$totalItems = 0;
			$taskCompletionPercent = 0;
			if ($rlt['taskCount'] != 0) // 11 = tasks
			{
				$totalItems = $totalItems + 100;
				$taskQry = "SELECT count(id),sum(points) FROM cpalead WHERE userId = '" . $userId . "'  AND  entryDate > '" . $lastClaimDate . "'";
				$taskData = mysqli_query($this->db, $taskQry);

				$taskCusor = mysqli_fetch_array($taskData, MYSQLI_NUM);
				$noOfData = $taskCusor[0];
				if ($noOfData > 0) {
					$taskCompletionPercent = ($noOfData * 100) / $rlt['taskCount'];
				}
				if ($taskCompletionPercent > 100) {
					$taskCompletionPercent = 100;
				}
			}

			//////////REFER///////////////
			$referCompletionPercent = 0;
			if ($rlt['referCount'] != 0) // 13 = refer users
			{
				$totalItems = $totalItems + 100;
				$referQry = "SELECT count(userId) FROM user_master WHERE referralUserId  = '" . $userId . "' AND  entryDate > '" . $lastClaimDate . "'";
				// $result['qry4'] = $referQry;
				$referData = mysqli_query($this->db, $referQry);

				$taskCusor = mysqli_fetch_array($referData, MYSQLI_NUM);
				$noOfData = $taskCusor[0];
				if ($noOfData > 0) {
					$referCompletionPercent = ($noOfData * 100) / $rlt['referCount'];
				}
				if ($referCompletionPercent > 100) {
					$referCompletionPercent = 100;
				}
			}

			//////////PUBSCALE OFFER///////////////
			$pubscaleCompletionPercent = 0;
			if ($rlt['pubscaleCount'] != 0) // 40 =pubscale
			{
				$totalItems = $totalItems + 100;
				$pubscaleQry = "SELECT count(id),sum(coin_amount) FROM pubscale_history WHERE userId = '" . $userId . "' AND  entryDate > '" . $lastClaimDate . "'";
				$pubscaleData = mysqli_query($this->db, $pubscaleQry);

				$taskCusor = mysqli_fetch_array($pubscaleData, MYSQLI_NUM);
				$noOfData = $taskCusor[0];
				if ($noOfData > 0) {
					$pubscaleCompletionPercent = ($noOfData * 100) / $rlt['pubscaleCount'];
				}
				if ($pubscaleCompletionPercent > 100) {
					$pubscaleCompletionPercent = 100;
				}
			}

			//////////////////ADJOE///////////////////
			$adjoeCompletionPercent = 0;
			if ($rlt['adjoePoints'] != 0) // 24 = playtime adjoe (ONLY POINTS)
			{
				$totalItems = $totalItems + 100;
				$adjoeQry = "SELECT count(id),sum(coin_amount) FROM adjoe_history WHERE userId = '" . $userId . "'  AND  entryDate > '" . $lastClaimDate . "'";
				$adjoeData = mysqli_query($this->db, $adjoeQry);

				$taskCusor = mysqli_fetch_array($adjoeData, MYSQLI_NUM);
				$earnedPoints = $taskCusor[1];
				if ($earnedPoints > 0) {
					$adjoeCompletionPercent = ($earnedPoints * 100) / $rlt['adjoePoints'];
				}
				if ($adjoeCompletionPercent > 100) {
					$adjoeCompletionPercent = 100;
				}
			}

			if ($totalItems > 0) {
				$completionPercent = (($taskCompletionPercent + $referCompletionPercent + $pubscaleCompletionPercent + $adjoeCompletionPercent) * 100) / $totalItems;
			} else {
				$completionPercent = 0;
			}
		}

		$i++;

		$result['mainDataList'][$i]['currentLevelId'] = $currentLevelId;
		$result['mainDataList'][$i]['fromEarningLevel'] = $data1;
		$result['mainDataList'][$i]['toEarningLevel'] = $data2;
		$result['mainDataList'][$i]['levelEarningPercentage'] = $completionPercent;
		$result['mainDataList'][$i]['levelEarningPoints'] = $levelEarningPoints;
		$result['mainDataList'][$i]['note'] = "Earn daily!";
		$result['mainDataList'][$i]['iconBGColor'] = "#30B3B3";
		$result['mainDataList'][$i]['title'] = "Level Earning";
		$result['mainDataList'][$i]['label'] = "";
		$result['mainDataList'][$i]['subTitle'] = "";
		$result['mainDataList'][$i]['type'] = "level_earning"; //level_earning
		$result['mainDataList'][$i]['isViewAll'] = "0";
		$result['mainDataList'][$i]['isBorder'] = "0";
		$result['mainDataList'][$i]['screenNo'] = "53";
		$result['mainDataList'][$i]['icon'] = "https://cdn-icons-png.flaticon.com/512/31
		50/3150115.png";
		$result['mainDataList'][$i]['isActive'] = "1";
		$result['mainDataList'][$i]['bgColor'] = "#F2FFFF";
	}

	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['image'] = "https://gotask.co.in/Api/images/banners/home_playtime.png";
	// $result['mainDataList'][$i]['url'] = "";
	// $result['mainDataList'][$i]['displayImage'] = "";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "31";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// $data1 = array(
	// 	array("image" => 'https://porntube.vip/img/cbbanneradjoyemin.jpg', "screenNo" => '31')
	// );
	// $result['mainDataList'][$i]['data'] = $data1;


	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['image'] = "https://gotask.co.in/Api/images/home/GoTaskpubscale.png";
	// $result['mainDataList'][$i]['url'] = "";
	// $result['mainDataList'][$i]['displayImage'] = "https://gotask.co.in/Api/images/home/GoTaskpubscale.png";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "51";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// $data = array(
	// 	array("image" => 'https://gotask.co.in/Api/images/home/GoTaskpubscale.png', "screenNo" => '51')
	// );
	// $result['mainDataList'][$i]['data'] = $data;


	// Daily Target
	// 	$sqlCampId = mysqli_query($this->db, "SELECT milestoneId FROM tbl_daily_target_history WHERE userId = '" . $userId . "' AND entryDate LIKE '%" . $date . "%'");
	// 	// $result['QRY1'] = "SELECT milestoneId FROM tbl_milestone_history WHERE userId = '" . $userId . "' GROUP BY milestoneId";
	// 	$NumRowsId = mysqli_num_rows($sqlCampId);
	// 	if ($NumRowsId > 0) {
	// 		while ($row =  mysqli_fetch_array($sqlCampId, MYSQLI_ASSOC)) {
	// 			$rows[] = $row['milestoneId'];
	// 		}
	// 	}

	// 	$sqlstring = "SELECT * FROM tbl_daily_target WHERE isActive = '1' ORDER BY id DESC";
	// 	// $result['QRY'] = $sqlstring;

	// 	$milestonesData = mysqli_query($this->db, $sqlstring);
	// 	if (mysqli_num_rows($milestonesData) > 0) {
	// 		$i++;
	// 		$result['mainDataList'][$i]['type'] = "daily_target";
	// 		$result['mainDataList'][$i]['title'] = "🎯 Daily Target";
	// 		$result['mainDataList'][$i]['note'] = "Earn daily!";
	// 		$result['mainDataList'][$i]['iconBGColor'] = "#FFA0A3";
	// 		$result['mainDataList'][$i]['label'] = "• Live";
	// 		$result['mainDataList'][$i]['subTitle'] = "";		
	// 		$result['mainDataList'][$i]['isViewAll'] = "0";
	// 		$result['mainDataList'][$i]['isBorder'] = "0";
	// 		$result['mainDataList'][$i]['icon'] = "https://cdn-icons-png.flaticon.com/512/3150/3150115.png";
	// 		$result['mainDataList'][$i]['isActive'] = "1";
	// 		$result['mainDataList'][$i]['bgColor'] = "#FFFFFF";

	// 		while ($rlt = mysqli_fetch_array($milestonesData, MYSQLI_ASSOC)) {
	// 			$type = $rlt['type'];
	// 			$earningType = $rlt['earningType'];
	// 			$completionPercent = 0;
	// 			if ($earningType == '11') // 11 = tasks
	// 			{
	// 				$taskQry = "SELECT count(id),sum(points) FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate LIKE '%" . $date . "%'";
	// 				$taskData = mysqli_query($this->db, $taskQry);
	// 			} elseif ($earningType == '40') // 40 = Pubscale Offer
	// 			{
	// 				$taskQry = "SELECT count(id),sum(coin_amount) FROM pubscale_history WHERE userId = '" . $userId . "' AND entryDate LIKE '%" . $date . "%'";
	// 				$taskData = mysqli_query($this->db, $taskQry);
	// 			} elseif ($earningType == '24') // 24 = playtime adjoe (ONLY POINTS)
	// 			{
	// 				$taskQry = "SELECT count(id),sum(coin_amount) FROM adjoe_history WHERE userId = '" . $userId . "'  AND  entryDate LIKE '%" . $date . "%'";
	// 				$taskData = mysqli_query($this->db, $taskQry);
	// 			}
	// 			// $rlt['QUERY'] = $taskQry;
	// 			$taskCusor = mysqli_fetch_array($taskData, MYSQLI_NUM);
	// 			$noOfData = $taskCusor[0];
	// 			$earnedPoints = $taskCusor[1];
	// 			if ($noOfData > 0) {
	// 				if ($type == '0') // 0 = number target
	// 				{
	// 					$completionPercent = ($noOfData * 100) / $rlt['targetNumber'];
	// 				} else { //1 = points target
	// 					$completionPercent = ($earnedPoints * 100) / $rlt['targetPoints'];
	// 				}
	// 			}
	// 			if ($completionPercent > 100) {
	// 				$completionPercent = 100;
	// 			}
	// 			if (strlen($userId) == 0 || (int)$userId == 0) {
	// 				$noOfData = "0";
	// 				$earnedPoints = "0";
	// 				$completionPercent = "0";
	// 			}
	// 			$rlt['NoOfCompleted'] = $noOfData;
	// 			if ($earnedPoints == NULL) {
	// 				$rlt['earnedPoints'] = "0";
	// 			} else {
	// 				$rlt['earnedPoints'] = $earnedPoints;
	// 			}
	// 			if ($rows != NULL && in_array($rlt['id'], $rows))
	// 			{
	// 		  	  $rlt['isClaimed'] = "1";
	// 	        }
	// 			else
	// 			{
	// 			  $rlt['isClaimed'] = "0";
	// 			}
	// 			$rlt['completionPercent'] = $completionPercent;
	// 			$rlt['todayDate'] = date("Y-m-d H:i:s");
	// 			$result['mainDataList'][$i]['dailyRewardTodayDate'] = date("Y-m-d H:i:s");
	// 			$result['mainDataList'][$i]['dailyRewardEndDate'] = $date.' 23:59:59';
	// 			$result['mainDataList'][$i]['dailyTargetList'][] = $rlt;
	// 		}
	// 	}




	// if(rand(10,100) % 2== 0 )
	// {
	// $i++;
	// $result['mainDataList'][$i]['title']=""; 
	// $result['mainDataList'][$i]['image']="https://mycashbazar.com/Api/upload/gamebannercb.json"; 
	// $result['mainDataList'][$i]['url']=""; 
	// $result['mainDataList'][$i]['displayImage']="https://mycashbazar.com/Api/upload/gamebannercb.json"; 
	// $result['mainDataList'][$i]['jsonImage']="https://mycashbazar.com/Api/upload/gamebannercb.json"; 
	// $result['mainDataList'][$i]['type']="singleslider"; 
	// $result['mainDataList'][$i]['isViewAll']="0"; 
	// $result['mainDataList'][$i]['isBorder']="0"; 
	// $result['mainDataList'][$i]['screenNo']="8"; 
	// $result['mainDataList'][$i]['bgColor']="#FFFFFF"; 
	// $data1 = array(
	// 	array("image" => 'https://mycashbazar.com/Api/upload/gamebannercb.json',"jsonImage" => 'https://mycashbazar.com/Api/upload/gamebannercb.json', "screenNo" => '31')
	// );
	// $result['mainDataList'][$i]['data'] = $data1;

	// }else{
	// 	$i++;
	// 	$result['mainDataList'][$i]['title']=""; 
	// 	$result['mainDataList'][$i]['image']="https://gotask.co.in/Api/images/home/PrizeboxGame.json"; 
	// 	$result['mainDataList'][$i]['url']=""; 
	// 	$result['mainDataList'][$i]['displayImage']="https://gotask.co.in/Api/images/home/PrizeboxGame.json"; 
	// 	$result['mainDataList'][$i]['jsonImage']="https://gotask.co.in/Api/images/home/PrizeboxGame.json"; 
	// 	$result['mainDataList'][$i]['type']="singleslider"; 
	// 	$result['mainDataList'][$i]['isViewAll']="0"; 
	// 	$result['mainDataList'][$i]['isBorder']="0"; 
	// 	$result['mainDataList'][$i]['screenNo']="8"; 
	// 	$result['mainDataList'][$i]['bgColor']="#FFFFFF"; 
	// 	$data1 = array(
	// 		array("image" => 'https://gotask.co.in/Api/images/home/PrizeboxGame.json',"jsonImage" => 'https://gotask.co.in/Api/images/home/PrizeboxGame.json', "screenNo" => '31')
	// 	);
	// 	$result['mainDataList'][$i]['data'] = $data1;			
	// }


	// $TaskSingle = mysqli_query($this->db, "SELECT * FROM homeslider WHERE  id = '27' ");
	// if (mysqli_num_rows($TaskSingle) > 0) {
	// $i++;
	// $result['mainDataList'][$i]['title'] = "";
	// $result['mainDataList'][$i]['type'] = "singleslider";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "1";
	// $result['mainDataList'][$i]['screenNo'] = "0";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// while ($rlt1 = mysqli_fetch_array($TaskSingle, MYSQLI_ASSOC)) {
	// $rlt1['displayImage'] = $rlt1['image'];
	// $result['mainDataList'][$i]['data'][] = $rlt1;
	// }
	// }


	// $iconeSlider = mysqli_query($this->db, "SELECT * FROM homeiconelist WHERE  isActive = '1' ORDER BY lableIndex DESC LIMIT 0,7");
	// if (mysqli_num_rows($iconeSlider) > 0) {
	// $i++;
	// $result['mainDataList'][$i]['title'] = "Today Story";
	// $result['mainDataList'][$i]['type'] = "iconlist";
	// $result['mainDataList'][$i]['isViewAll'] = "0";
	// $result['mainDataList'][$i]['isBorder'] = "0";
	// $result['mainDataList'][$i]['screenNo'] = "0";
	// $result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// while ($rlt2 = mysqli_fetch_array($iconeSlider, MYSQLI_ASSOC)) {
	// $result['mainDataList'][$i]['data'][] = $rlt2;
	// }
	// }



	// $i++;
	// $result['mainDataList'][$i]['type'] = "nativeAd";


	// $i++;
	// $result['mainDataList'][$i]['type'] = "earnGrid";
	// $result['mainDataList'][$i]['title'] = "Earning Options";
	// $result['mainDataList'][$i]['url'] = "#FFFFFF";
	// $data = array(

	// 	// array("image" => 'https://gotask.co.in/Api/images/banners/earn2.png', "screenNo" => '31'),
	// 	// array("image" => 'https://gotask.co.in/Api/images/banners/earn1.png', "screenNo" => '11'),
	// 	array("image" => 'https://gotask.co.in/Api/images/banners/earn3.png', "screenNo" => '8'),
	// 	array("image" => 'https://gotask.co.in/Api/images/banners/earn4.png', "screenNo" => '14')

	// );

	// $result['mainDataList'][$i]['data'] = $data;


	// $imploded = "0";

	// if (strlen($userId) > 0 && $userId != "0") {
	// 	$sqlCampId = mysqli_query($this->db, "SELECT campaignId FROM cpalead WHERE userId = '" . $userId . "' GROUP BY campaignId ");
	// 	$NumRowsId = mysqli_num_rows($sqlCampId);
	// 	if ($NumRowsId > 0) {
	// 		while ($row =  mysqli_fetch_array($sqlCampId, MYSQLI_ASSOC)) {
	// 			$rows1[] = $row['campaignId'];
	// 		}
	// 		$imploded = implode(',', $rows1);
	// 	}
	// }



	if ($country == "IN") {


		// $i++;
		// $rlt2['title'] = "";
		// $rlt2['jsonImage'] = "";
		// $rlt2['screenNo'] = "5";
		// $rlt2['url'] = "https://taskpaydeal.com/app_image/homeslider/78_1rswirdraws.jpg";
		// $rlt2['image'] = "https://taskpaydeal.com/app_image/homeslider/78_1rswirdraws.jpg";
		// $rlt2['displayImage'] = "https://taskpaydeal.com/app_image/homeslider/78_1rswirdraws.jpg";
		// $rlt2['jsonImage'] = "";
		// $result['mainDataList'][$i]['data'][0]=$rlt2; 
		// $result['mainDataList'][$i]['title']=""; 
		// $result['mainDataList'][$i]['type']="singleslider"; 
		// $result['mainDataList'][$i]['isViewAll']="0"; 
		// $result['mainDataList'][$i]['isBorder']="0"; 
		// $result['mainDataList'][$i]['screenNo']="5"; 
		// $result['mainDataList'][$i]['bgColor']="#FFFFFF";



		// $i++;
		// $rlt2['title'] = "";
		// $rlt2['jsonImage'] = "";
		// $rlt2['screenNo'] = "11";
		// $rlt2['url'] = "https://play.google.com/store/apps/details?id=com.earnrewards.taskpay.paidtasks.earnmoney";
		// $rlt2['image'] = "https://gotask.co.in/Api/images/home/taskpayPromo.png";
		// $rlt2['displayImage'] = "https://gotask.co.in/Api/images/home/taskpayPromo.png";
		// $rlt2['jsonImage'] = "https://mycashbazar.com/ExtraImages/taskoffer_homepage5.json";
		// $result['mainDataList'][$i]['data'][0]=$rlt2; 
		// $result['mainDataList'][$i]['title']=""; 
		// $result['mainDataList'][$i]['type']="singleslider"; 
		// $result['mainDataList'][$i]['isViewAll']="0"; 
		// $result['mainDataList'][$i]['isBorder']="0"; 
		// $result['mainDataList'][$i]['screenNo']="2"; 
		// $result['mainDataList'][$i]['bgColor']="#FFFFFF"; 

		$i++;
		$result['mainDataList'][$i]['type'] = "nativeAd";
	}

	// $TaskSingle = mysqli_query($this->db, "SELECT * FROM homeslider WHERE  id = '20' ");

	// if (mysqli_num_rows($TaskSingle) > 0) {
	// 	$i++;
	// 	$result['mainDataList'][$i]['title'] = "";
	// 	$result['mainDataList'][$i]['type'] = "singleslider";
	// 	$result['mainDataList'][$i]['isViewAll'] = "0";
	// 	$result['mainDataList'][$i]['isBorder'] = "1";
	// 	$result['mainDataList'][$i]['screenNo'] = "0";
	// 	$result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
	// 	while ($rlt1 = mysqli_fetch_array($TaskSingle, MYSQLI_ASSOC)) {
	// 		$rlt1['displayImage'] = $rlt1['image'];
	// 		$result['mainDataList'][$i]['data'][] = $rlt1;
	// 	}
	// }

	// Quick Task
	$imploded = "0";
	$sqlCampId = mysqli_query($this->db, "SELECT ids FROM quicktask_history WHERE userId = '" . $userId . "'   GROUP BY ids ");
	// echo "SELECT ids FROM quicktask_history WHERE userId = '" . $userId . "'   GROUP BY ids";
	$NumRowsId = mysqli_num_rows($sqlCampId);
	if ($NumRowsId > 0) {
		while ($row =  mysqli_fetch_array($sqlCampId, MYSQLI_ASSOC)) {
			$rowsQuickTask[] = $row['ids'];
		}
		$imploded = implode(',', $rowsQuickTask);
	}

	// echo $imploded;
	if ($imploded == '') {
		$quicktask_querry = mysqli_query($this->db, "SELECT * FROM quicktask_modules WHERE  status = '1' ");
	} else {

		$quicktask_querry = mysqli_query($this->db, "SELECT * FROM quicktask_modules WHERE id NOT IN ($imploded) AND  status = '1' ");
	}

	if (mysqli_num_rows($quicktask_querry) > 0) {
		$i++;
		$result['mainDataList'][$i]['title'] = "Quick Tasks";
		$result['mainDataList'][$i]['type'] = "Quicktask";
		$result['mainDataList'][$i]['isViewAll'] = "0";
		$result['mainDataList'][$i]['isBorder'] = "0";
		$result['mainDataList'][$i]['screenNo'] = "52";
		$result['mainDataList'][$i]['iconBGColor'] = "#EFD000";
		$result['mainDataList'][$i]['bgColor'] = "#FFFFFF";
		while ($quicktask_result = mysqli_fetch_array($quicktask_querry, MYSQLI_ASSOC)) {
			$result['mainDataList'][$i]['data'][] = $quicktask_result;
		}
	}

	$result['adFailUrl'] = "https://sportsgurupro.com";

	if ($country == "IN") {
		$resHomediloag = mysqli_query($this->db, "SELECT * FROM home_popup WHERE startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ORDER BY RAND() LIMIT 1  ");
		if ($resHomediloag->num_rows > 0) {
			$result['homeDialog'] = $resHomediloag->fetch_assoc();
		}
	}


	$result['sideMenuList'] = json_decode(file_get_contents('sidemenu.json'), true);

	if (strlen($userId) > 0) {
		$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,referralCode,isNewJoin,referralUserId,token FROM user_master WHERE userId = '" . $userId . "' ");
		if ($sqlRederID->num_rows > 0) {
			$rowewf = $sqlRederID->fetch_assoc();
			$result['earningPoint'] = $rowewf['earningPoint'];
			$result['referralCode'] = $rowewf['referralCode'];
			$isNewJoin = $rowewf['isNewJoin'];
			$existtoken = $rowewf['token'];
			$referral_user_id = $rowewf['referralUserId'];
			if ($isNewJoin == "1") {
				if ($this->checktoken($existtoken) && strlen($referral_user_id) > 0  && $referral_user_id != '0') {
					$findDuplicateToken = mysqli_query($this->db, "SELECT userId FROM user_master WHERE token = '" . $existtoken . "' ");
					if ($findDuplicateToken->num_rows ==  1) {
						$sqlRederID1 = mysqli_query($this->db, "SELECT earningPoint,referralCode,isNewJoin FROM user_master WHERE userId = '" . $referral_user_id . "' ");
						$referral_user_data = $sqlRederID1->fetch_assoc();
						$earningPoint = (int)$referral_user_data['earningPoint'] + 100;
						$earningPointRefpoint = (int)$referral_user_data['referEarningPoint'] + 100;
						mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $referral_user_id . "', '100', '13', '1','" . $earningPoint . "','New User Join')");

						mysqli_query($this->db, "UPDATE user_master SET isNewJoin='0' WHERE userId = '" . $userId . "'  ");

						mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $earningPoint . "', referEarningPoint='" . $earningPointRefpoint . "' WHERE userId = '" . $referral_user_id . "'  ");
						if ($referral_user_id != '0') {
							$this->refreFrendNoti($referral_user_data['token'], "+100");
						}
					} else {
						mysqli_query($this->db, "UPDATE user_master SET isNewJoin='0' WHERE userId = '" . $userId . "'  ");
					}
				} else {
					mysqli_query($this->db, "UPDATE user_master SET isNewJoin='0' WHERE userId = '" . $userId . "'  ");
				}
			}
		}
	}

	$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,referralCode,referralLink,firstName,lastName,referralLinkDate,referEarningPoint FROM user_master WHERE userId = '" . $userId . "' ");
	if ($sqlRederID->num_rows > 0) {
		$rowewf = $sqlRederID->fetch_assoc();
		$result['earningPoint'] = $rowewf['earningPoint'];
		$result['totalReferralIncome'] = $rowewf['referEarningPoint'];
		$referralCode = $rowewf['referralCode'];
		$result['referralCode'] = $referralCode;
		$referralLink = $rowewf['referralLink'];

		if ($referralCode == "") {

			$sqlRefcode = mysqli_query($this->db, "SELECT id,referral_code FROM referral_master WHERE is_used ='0' limit 1");
			$rowNewCode = $sqlRefcode->fetch_assoc();
			$referralCode = $rowNewCode['referral_code'];

			$result['referralCode'] = $referralCode;

			mysqli_query($this->db, "UPDATE referral_master SET is_used = '1' WHERE id ='" . $rowNewCode['id'] . "' ");

			mysqli_query($this->db, "UPDATE user_master SET referralCode = '" . $referralCode . "' WHERE userId ='" . $userId . "' ");

			$referralLink = "";
		}

		$firstName = $rowewf['firstName'];
		$lastName = $rowewf['lastName'];
		$referralLinkDate = $rowewf['referralLinkDate'];
		$curreDate = date('Y-m-d');
		if ($referralLink == "0" || $this->dateDiffInDays($curreDate, $referralLinkDate) > 7 || $referralLink == "") {
			// $link = "https://gotask.co.in/app.php?";
			// $linkdata = array(
			// 	'referralCode' => $referralCode,
			// 	'firstName' => empty($firstName) ? "." : $firstName,
			// 	'lastName' => empty($lastName) ? "." : $lastName
			// );
			// $likLong = $link . http_build_query($linkdata);
			// $referralLink = $this->shorten_URL($likLong);
			$referralLink = "https://gotask.co.in/App/reffer.php?code=" . $referralCode;

			if (strlen($userId) > 0) {
				$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET referralLink='" . $referralLink . "',referralLinkDate='" . $curreDate . "' WHERE userId = '" . $userId . "'  ");
				if ($sqlwalletupdate === TRUE) {
					$result['status'] = "1";
					$result['referralLink'] = $referralLink;
				} else {
					$result['message'] = "Something went wrong, please try again.";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "Something went wrong, please try again.";
				$result['status'] = "0";
			}
		} else {
			$result['referralLink'] = $referralLink;
			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";
		}

		$result['displayTitle'] = "Get ₹10+₹10+₹10+.... Every referral";
		$result['displayMessage'] = "Invite your friends & earn 100 points ( 10Rs ) when they join and complete 1 task. GoTask is India's most trusted application on android, Now you can share the love with your friends.";

		$result['shareMessage'] = "💥 Share the Wealth: Earn More with GoTask!

*Share with Friends 🌐*: Spread the word! Share your referral code or link with friends, family, and colleagues.

*Multi-Tier Rewards 🌟*: The more friends you refer, the greater the rewards.

*Easy Redemption 🔄*: Choose from a variety of redemption options.

*Spread the Love ❤*: Enjoy the perks together! Encourage your friends to refer others and create a positive referral community

👇🏾 *Download Application*
" . $referralLink;
	}


	// $result['storyView'][0]['image']="https://i3.ytimg.com/vi/MCN-hESls-o/maxresdefault.jpg";
	// $result['storyView'][0]['date']="10-08-2022 10:00:00";
	// $result['storyView'][0]['screenNo']="2";
	// $result['storyView'][0]['clickUrl']="https://www.youtube.com/watch?v=MCN-hESls-o";
	// $result['storyView'][0]['description']="Like & subscribe video";


	// $result['storyView'][1]['image']="https://sportsgurupro.com/admin/images/homeslider/233_FastLoot.png";
	// $result['storyView'][1]['date']="10-08-2022 10:00:00";
	// $result['storyView'][1]['screenNo']="2";
	// $result['storyView'][1]['clickUrl']="https://sportsgurupro.com/TaskOffers?utm_source=google";
	// $result['storyView'][1]['description']="Click & Earn Money";


	// $result['storyView'][2]['image']="https://mycashbazar.com/AdsImages/MGL_squre_1.png";
	// $result['storyView'][2]['date']="10-08-2022 10:00:00";
	// $result['storyView'][2]['screenNo']="2";
	// $result['storyView'][2]['clickUrl']="https://873.go.mglgamez.com";
	// $result['storyView'][2]['description']="Click & Earn Money";


	$ep1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "'  ");
	$ep = $ep1->fetch_assoc();
	$result['earningPoint'] = $ep['earningPoint'];

	$earnnig_point = $ep['earningPoint'];
	// $result['points']=$earnnig_point;
	$welcome_qry = mysqli_query($this->db, "SELECT * FROM `earning_point_master` WHERE `userId` = '$userId' AND `earning_type` = '14'  AND `entryDate` LIKE '%$date%' LIMIT 1");
	$result['abc'] = "SELECT * FROM `earning_point_master` WHERE `userId` = '$userId' AND `earning_type` = '14'  AND `entryDate` LIKE '%$date%' LIMIT 1";
	if (mysqli_num_rows($welcome_qry) > 0) {
		$rlt1 = mysqli_fetch_array($welcome_qry, MYSQLI_ASSOC);
		if ($earnnig_point == $WelcomeBonusPoint) {
			$result['isShowWelcomeBonusPopup'] = "1";
			$result['welcomeBonus'] = $WelcomeBonusPoint;
		} else {
			$result['isShowWelcomeBonusPopup'] = "0";
			$result['welcomeBonus'] = "0";
		}
	} else {
		$result['isShowWelcomeBonusPopup'] = "0";
		$result['welcomeBonus'] = "0";
	}

	$result['pointValue'] = "100";
	// $result['aboutUsUrl'] = "https://gotask.co.in/aboutUs.html";
	$result['privacyPolicy'] = "https://gotask.co.in/PrivacyPolicy.html";
	$result['termsConditionUrl'] = "https://gotask.co.in/TermsConditions.html";
	$result['adFailUrl'] = "https://sportsgurupro.com";

	$result['todayDate'] = date('Y-m-d');

	$result['appVersion'] = "1.0.0";
	$result['appUrl'] = "https://play.google.com/store/apps/details?id=com.earn.topoffers.payout.surveys.upi";
	$result['isForceUpdate'] = "0";
	$result['updateMessage'] = "Please update app to get new features.";

	$result['telegramUrl'] = "https://t.me/GoTaskapps";
	$result['youtubeUrl'] = "https://www.youtube.com/@Gotask-pk8fw";
	$result['instagramUrl'] = "https://www.instagram.com/gotaskreward?igsh=MXNjenkybHA0Y25qNw==";
	$result['celebrationLottieUrl'] = "https://gotask.co.in/Api/images/home/party_celebrations.json";


	// $result['rewardLabel'] = "₹10";
	$result['isShowAccountDeleteOption'] = "1";
	$result['isShowGiveawayCode'] = "1";

	$sql1 = mysqli_query($this->db, "SELECT * FROM giveaway_coupon_codes WHERE isDisplay = '1' AND  startDate < '" . $date . "' AND endDate > '" . $date . "' ORDER BY displayIndex DESC");
	if (mysqli_num_rows($sql1) > 0) {
		while ($rltsetting = mysqli_fetch_array($sql1, MYSQLI_ASSOC)) {
			$rows[] = $rltsetting['couponCode'];
		
		}
	}	
	if (count($rows) > 0) {
		$giveawayCode = implode(',', $rows);
	}
	$result['giveawayCode'] = $giveawayCode;
	// $result['giveawayCode'] = "GAME100,PLAY100,GAME150";

	// $result['footerImage'] = "https://mycashbazar.com/Api/upload/rewardpagefooter.png";

	// LIVE APPLOVIN AD UNIT IDS
	$result['lovinBannerID'] = array("62f0f378251580eb", "c5a29aa01b92df3e", "a9fb1a05ebc775aa");
	$result['lovinInterstitialID'] = array("01f05deffcc0d8a2", "6536a0e362f1b58e", "f2e5833f63c67e9b", "7538d01051bca8fd");
	$result['lovinRewardID'] = array("89a461edca6bf153", "6f05b9b78847a421", "1f36d8b76938948a");
	$result['lovinAppOpenID'] = array("46f631a5f9f310dc");
	$result['lovinNativeID'] = array("9a3ae9157ccefb86", "8e10e3a1f97590af", "a7d464afd0025e9a");
	$result['lovinSmallNativeID'] = array("9668d3cde230b217", "73d87e7480aa8111", "0978a208501a2189");


	$result['isAppLovinAdShow'] = "0";

	if (strlen($userId) > 0) {
		if ($userId == "3104" || $userId == "1" || $userId == "34878") {
			$result['isAppLovinAdShow'] = "0";
		}
	}

	$result['isScanAndPayShow'] = "1";
	$result['poweredByScanAndImage'] = "https://gotask.co.in/Api/images/powered_by_image.png";
	$result['isShowAppPrize'] = "0";
	$result['appPrizeTargetCountryLocale'] = "IN";


	$result['isShowWhatsAppAuth'] = "0"; // Not used in app
	$result['adjoeKeyHash'] = "6d7a9a7589e769011ab5ad2709dc32dd";


	$result['offerToroAppId'] = "15656";
	$result['OfferToroSecretKey'] = "069b89f10fb50fcc3443157544033b47";
	  $result['isShowOfferToro'] = "0";


	$result['isShowAdjoeLeaderboardIcon'] = "0";
	$result['isTaskVisible'] = "1";
	$result['footerTaskIcon'] = "https://gotask.co.in/Api/images/data.json";
	$result['isShowFooterTaskIcon'] = "1";

	$result['isShowPlaytimeSDK'] = "1";

	$result['isShowPubScale'] = "1";
	$result['isShowAdjump'] = "1";

	$result['isShowHotOffers'] = "1";
	$result['hotOffersScreenNo'] = "2";

	$result['message'] = "Data Found Sucessfully.";
	$result['status'] = "1";

	$this->response($this->json($result), 200);
}

	//packageInstallTracking
	private function NAVRATRI()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		// $Details = json_decode($this->_request['details'], true);

		$userId = $Details['VFHRGE'];
		$packageId = $Details['OEZOAQ'];
		$url = $Details['I2MPLV'];
		$adId = $Details['7QXSVO'];
		$ipaddress = $this->getIp();

		$sqinsert = mysqli_query($this->db, "INSERT INTO packageInstallTracking (userId,packageId,url,adId,ipAddress) VALUES ('" . $userId . "', '" . $packageId . "', '" . $url . "', '" . $adId . "', '" . $ipaddress . "') ");

		if ($sqinsert) {
			$result['message'] = "Data inserted";
			$result['status'] = "1";
		} else {
			$result['message'] = "Something went wrong 1";
			$result['status'] = "0";
		}

		$this->response($this->json($result), 200);
	}
	//moreApps
	private function MAHASAGAR()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;

		$Details = json_decode($this->_request['details'], true);
		$result = array();
		$DeviceId = $Details['DV2R7Y'];
		$userId = $Details['IINHK8'];
		$appVersion = $Details['R5GWKT'];
		$deviceName = $Details['9Q2Z3S'];
		$adId = $Details['W5XY9Q'];
		$todayOpen = $Details['HJN784'];
		$totalOpen = $Details['EOAK3Y'];


		$data = array(
			array('id' => "1", 'title' => "Cricidea - Fantasy Prediction", 'icone' => "https://play-lh.googleusercontent.com/e2M4fBaZt5ZIofQnStGeVxYGrGqfsrVgDhSiSPzTScVS8chEV67dJKIFCvlQvV4O4w=w480-h960", 'bgImage' => "https://play-lh.googleusercontent.com/f2pFWl8c0SATrQIF-bc1qre8jdw2azrg6tf49wmp652w00xltddxmpk98xp-Z0GZk1gAEYQ=w1024-h500-rw", 'btnName' => "Install", 'rating' => "4.6", 'url' => "https://play.google.com/store/apps/details?id=com.sports.cricidea"),
			array('id' => "2", 'title' => "Prime Cricket", 'icone' => "https://play-lh.googleusercontent.com/ZChH-ovE4PTpyU2GkxB3Xj0-puYRPixy5vEr_aNF06hxUkSqqPO4HsC8uUXp8zC0UH7Q=w480-h960", 'bgImage' => "https://play-lh.googleusercontent.com/hnF3i-oM3r91BuX4BA0BqDeONBZINoR1IZbLPP1G9DgIrVp5Dr-QYWlttP383cs0wZU=w1024-h500", 'btnName' => "Install", 'rating' => "4.5", 'url' => "https://play.google.com/store/apps/details?id=com.prime.cricketteam"),
			array('id' => "3", 'title' => "Cricket Prime", 'icone' => "https://play-lh.googleusercontent.com/yxjpmrdmUE_NLaB-kqgM9OcNGMOThr_kSm9z90aU9pehdAn9vexSAcMp7cM6bPG5hoo1=w480-h960", 'bgImage' => "https://play-lh.googleusercontent.com/jAKGYteJm6muEMvRjsNaRNfsMFXF91orbDbOA9WuGfgBtD_ASICLi2t2D7o9A2zEm5E=w1024-h500", 'btnName' => "Install", 'rating' => "4.5", 'url' => "https://play.google.com/store/apps/details?id=com.team.cricketprime"),
			array('id' => "4", 'title' => "11 Dream", 'icone' => "https://play-lh.googleusercontent.com/YyHzWLkzwH-8L3t809DPEeK1Tg9xnwU3EPPaBk_CHWNEmqyibgGAguf4KicunXOrbAHb=w480-h960", 'bgImage' => "https://play-lh.googleusercontent.com/V_t4ZI6uA9l6WCbr1vXBSaOvkTDNEpUTHQoQUJMHLrErGJyHg89uy71MyuHeF5qcvOI=w1024-h500", 'btnName' => "Install", 'rating' => "4.5", 'url' => "https://play.google.com/store/apps/details?id=com.cricket.dreamteam"),
			array('id' => "4", 'title' => "Cricket Lineup - Prediction", 'icone' => "https://play-lh.googleusercontent.com/tL99c9ePE02bXoqVoyjwflpI1J6_BmHfO0d-ImEDIm7Koew6xjpEe8dyctyt2AjzGw=w480-h960", 'bgImage' => "https://play-lh.googleusercontent.com/Mi0QzCS_OCzSgWy2lqkM4hbp0BL_DWG3MH9gxfGz2a7GogD5-dJUGhKYnx0V54v0_g59=w1024-h500", 'btnName' => "Install", 'rating' => "4.5", 'url' => "https://play.google.com/store/apps/details?id=com.cricket.lineup"),
		);
		// $result['moreApps'] = $data;


		$result['isShowInterstitial'] = "1"; // 1 = Interstitial, 2 = Rewarded, 0 = No ads
		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;
		$result['message'] = "";
		$result['status'] = "1";
		$result['adFailUrl'] = "https://sportsgurupro.com";
		$this->response($this->json($result), 200);
	}
	//GetReferralDataAsync
	private function PAVAN()
	{
		if ($this->get_request_method() != "POST") {

			$this->response('', 406);
		}
		global $App_Name, $app_logo;
		$Details = json_decode($this->_request['details'], true);
		$result = array();
		$DeviceId = $Details['2QCZ2F'];
		$userId = $Details['WHKF74'];
		$appVersion = $Details['QLO8SX'];
		$deviceName = $Details['QQSSF7'];
		$adId = $Details['GIPSCD'];
		$todayOpen = $Details['S7H8DT'];
		$totalOpen = $Details['0FGUT1'];



		$data = array(
			array("id" => "1",	"icon" => "https://cdn-icons-png.flaticon.com/128/4140/4140048.png", "points" => "100",		"title" => "Sign up", "description" => "When a friend sign up, you will get 100 points in your wallet."),

			array("id" => "2", "icon" => "https://cdn-icons-png.flaticon.com/128/8233/8233792.png", "points" => "900", "title" => "Complete task", "description" => "When a friend completes task you will get 300+300+300 points. Up to 3 tasks."),

			array(
				"id" => "3",
				"icon" => "https://cdn-icons-png.flaticon.com/128/2583/2583264.png",
				"points" => "5% Extra",
				"title" => "Withdraw points",
				"description" => "When a friend withdraw poins, you will get 5% of withdrawn points credited in your wallet for lifetime."
			)
		);

		$result['inviteSlider'][0]['image'] = "http://eazyearning.com/Api/images/Newtasksilider/Refer_1.png";
		$result['inviteSlider'][0]['url'] = "";
		$result['inviteSlider'][0]['screenNo'] = "2";

		$result['inviteSlider'][1]['image'] = "http://eazyearning.com/Api/images/Newtasksilider/Refer_2.png";
		$result['inviteSlider'][1]['screenNo'] = "0";

		$result['inviteSlider'][2]['image'] = "http://eazyearning.com/Api/images/Newtasksilider/Refer_3.png";
		$result['inviteSlider'][2]['screenNo'] = "0";

		if (strlen($userId) > 0) {
			$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,referralCode,referralLink,firstName,lastName,referralLinkDate,referEarningPoint FROM user_master WHERE userId = '" . $userId . "' ");
			if ($sqlRederID->num_rows > 0) {
				$rowewf = $sqlRederID->fetch_assoc();
				$result['earningPoint'] = $rowewf['earningPoint'];
				$result['totalReferralIncome'] = $rowewf['referEarningPoint'];
				$referralCode = $rowewf['referralCode'];
				$result['referralCode'] = $referralCode;
				$referralLink = $rowewf['referralLink'];

				if ($referralCode == "") {

					$sqlRefcode = mysqli_query($this->db, "SELECT id,referral_code FROM referral_master WHERE is_used ='0' limit 1");
					$rowNewCode = $sqlRefcode->fetch_assoc();
					$referralCode = $rowNewCode['referral_code'];

					$result['referralCode'] = $referralCode;

					mysqli_query($this->db, "UPDATE referral_master SET is_used = '1' WHERE id ='" . $rowNewCode['id'] . "' ");

					mysqli_query($this->db, "UPDATE user_master SET referralCode = '" . $referralCode . "' WHERE userId ='" . $userId . "' ");

					$referralLink = "";
				}



				$firstName = $rowewf['firstName'];
				$lastName = $rowewf['lastName'];
				$referralLinkDate = $rowewf['referralLinkDate'];
				$curreDate = date('Y-m-d');
				// $result['homeNote']="<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";
				if ($referralLink == "0" || $this->dateDiffInDays($curreDate, $referralLinkDate) > 7 || $referralLink == "") {
					// $link = "http://eazyearning.com/app.php?";
					// $linkdata = array(
					// 	'referralCode' => $referralCode,
					// 	'firstName' => empty($firstName) ? "." : $firstName,
					// 	'lastName' => empty($lastName) ? "." : $lastName

					// );

					// $likLong = $link . http_build_query($linkdata);
					// $referralLink = $this->shorten_URL($likLong);
					$referralLink = "http://eazyearning.com/App/reffer.php?code=" . $referralCode;

					if (strlen($userId) > 0) {
						$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET referralLink='" . $referralLink . "',referralLinkDate='" . $curreDate . "' WHERE userId = '" . $userId . "'  ");

						if ($sqlwalletupdate === TRUE) {
							$result['status'] = "1";
							$result['referralLink'] = $referralLink;
						} else {
							$result['message'] = "Something went wrong, please try again.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "Something went wrong, please try again.";
						$result['status'] = "0";
					}
				} else {
					$result['referralLink'] = $referralLink;
					$result['message'] = "Data Found Sucessfully.";
					$result['status'] = "1";
				}

				// $values = parse_url($referralLink);
				// $code = ltrim($values['path'], '/');
				// $referralLink = "http://eazyearning.com/App/reffer.php?code=" . $code;


				$result['displayTitle'] = "Get ₹10+₹10+₹10+.... Every referral";
				$result['displayMessage'] = "Invite your friends & earn 1000 points (10 Rs) when they join and complete 1 task. $App_Name is India's most trusted application on android, Now you can share the love with your friends.";

				$result['shareMessage'] = "💥 Share the Wealth: Earn More with  $App_Name !

*Share with Friends 🌐*: Spread the word! Share your referral code or link with friends, family, and colleagues.
																
*Multi-Tier Rewards 🌟*: The more friends you refer, the greater the rewards.
																
*Easy Redemption 🔄*: Choose from a variety of redemption options.
																
*Spread the Love ❤*: Enjoy the perks together! Encourage your friends to refer others and create a positive referral community

				👇🏾 *Download Application*
				" . $referralLink;

				$result['shareMessageWhatsApp'] = "💥 Share the Wealth: Earn More with  $App_Name !

*Share with Friends 🌐*: Spread the word! Share your referral code or link with friends, family, and colleagues.
																
*Multi-Tier Rewards 🌟*: The more friends you refer, the greater the rewards.
																
*Easy Redemption 🔄*: Choose from a variety of redemption options.
																
*Spread the Love ❤*: Enjoy the perks together! Encourage your friends to refer others and create a positive referral community

				👇🏾 *Download Application*
				" . $referralLink;
				$result['shareMessageTelegram'] = "💥 Share the Wealth: Earn More with  $App_Name !

*Share with Friends 🌐*: Spread the word! Share your referral code or link with friends, family, and colleagues.
																
*Multi-Tier Rewards 🌟*: The more friends you refer, the greater the rewards.
																
*Easy Redemption 🔄*: Choose from a variety of redemption options.
																
*Spread the Love ❤*: Enjoy the perks together! Encourage your friends to refer others and create a positive referral community

				👇🏾 *Download Application*
				" . $referralLink;

				$result['howToWork'] = $data;

				$result['shareImage'] = $app_logo;

				$sqlRefrealCount = mysqli_query($this->db, "SELECT COUNT(*),referEarningPoint FROM user_master WHERE referralUserId = '" . $userId . "'  ");
				$row = $sqlRefrealCount->fetch_row();
				$result['totalReferrals'] = $row[0];
				// $result['referIncome'] = "Earn 15000 Rs.";
				$result['referIncome'] = "Earn Unlimited";
				$result['btnName'] = "Invite Now";
			} else {
				$result['message'] = "Something went wrong, please try again.";
				$result['status'] = "0";
			}
		} else {
			$result['status'] = "2";
			$result['message'] = "Something went wrong, please try again.";
		}
		$result['backgroundColor'] = "#ffffff";
		$result['inviteNoTextColor'] = "#333333";
		$result['inviteLabelTextColor'] = "#5A5A5A";
		$result['textColor'] = "#333333";
		$result['isshowhelp'] = "1";
		$result['btnTextColor'] = "#ffffff";
		$result['howToWork'] = $data;

		$refeUserId = mysqli_query($this->db, "SELECT SUM(points) AS sum,COUNT(id)
 AS count FROM earning_point_master WHERE userId = '" . $userId . "' AND earning_type = '13'");
		$referpointData = mysqli_fetch_assoc($refeUserId);

		if ($referpointData['count'] > 0) {

			$refercount = $referpointData['count'];
			$referpoint = $referpointData['sum'];
		} else {

			$refercount = "0";
			$referpoint = "0";
		}

		$result['totalreferCount'] = $refercount;
		$result['totalReferralIncome'] = $referpoint;
		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['type'] = "0";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>$App_Name Provides 100% Withdraw to All Users.</marquee>";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}


	private function faqData()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name;
		$result = array();
		$data = array(
			array('Q' => "How does the app pay its users?", 'A' => "User gets paid by UPI Id, Gift cards"),

			array('Q' => "Is the app free to use?", 'A' => "Yes It's 100% Free To Use"),

			array('Q' => "Is the app available worldwide or only in certain countries?", 'A' => "You can earn money sitting in any country"),

			array('Q' => "What type of tasks or activities can users complete to earn money?", 'A' => "User has choices to earn either by Completing task offers, Referral program, Scratch cards, Playtime games, Giveaways and many more."),

			array('Q' => "Are there any restrictions on how much money users can earn?", 'A' => "No There are no restriction"),

			array('Q' => "How does the app protect user privacy and data security?", 'A' => "We are very much serious about user data."),

			array('Q' => "How do users receive their earnings?", 'A' => "User earns in points and then redeem those points by UPI Id, Paytm Wallet, Gift cards "),

			array('Q' => "Is there customer support available if users have questions or issues with the app?", 'A' => "Yes you ask inside feedback section"),

			array('Q' => "Is there a minimum payout threshold?", 'A' => "We have very minimum payout at only 100 points")

		);

		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['type'] = "0";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>$App_Name Provides 100% Withdraw to All Users.</marquee>";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['data'] = $data;
		$result['message'] = "Data Found Sucessfully.";
		$result['status'] = "1";
		$this->response($this->json($result), 200);
	}

	//GetSpinData
	private function ROBBIN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;

		// $Details = json_decode($this->_request['details'],true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$adId = $Details['FXDQJ8'];
		$userId = $Details['74QITN'];
		$deviceName = $Details['ALJ4T7'];
		$deviceID = $Details['7ZGGDO'];

		$buttonImage = $Details['QXGWTZ'];
		$buttonTextColor = $Details['3KXTTW'];
		$spinImage = $Details['EQ4VYP'];
		$backgroundImage = $Details['W3OEQQ'];
		$labelBackgroundImage = $Details['5RQYQ8'];


		$appVersion = $Details['TT7V55'];
		$todayOpen = $Details['YW4EUD'];
		$totalOpen = $Details['Y1FIT7'];
		$DailySpinLimit = 12;
		$RemailSpin = 0;
		$DateToday = date('Y-m-d');
		$result = array();

		$checkSpin = mysqli_query($this->db, "SELECT id FROM spin_point WHERE adId = '" . $adId . "' AND dateAdd = '" . $DateToday . "' ");

		$earningpointsofuser = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "' ");

		$earpoint = $earningpointsofuser->fetch_assoc();

		$result['earningPoint'] = $earpoint['earningPoint'];

		$checkSpinNum = mysqli_num_rows($checkSpin);
		$result['checkSpinNum'] = $checkSpinNum;
		if ($checkSpinNum > 0) {
			$RemailSpin = $DailySpinLimit - $checkSpinNum;
		} else {
			$RemailSpin = $DailySpinLimit;
		}
		$lastDate = mysqli_query($this->db, "SELECT entryDate FROM spin_point WHERE adId = '" . $adId . "' ORDER BY id DESC limit 1");
		$lastDateNum = mysqli_num_rows($lastDate);
		if ($lastDateNum > 0) {
			$resapi = $lastDate->fetch_assoc();
			$result['lastDate'] = $resapi['entryDate'];
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		$result['todayDate'] = date('Y-m-d H:i:s');

		$data = array(
			array('block_id' => "1", 'block_points' => "5", 'block_bg' => "#DDA300", "block_text_color" => "#333333", "block_icon" => "https://cdn-icons-png.flaticon.com/512/1490/1490858.png"),

			array('block_id' => "2", 'block_points' => "10", 'block_bg' => "#59004D", "block_text_color" => "#FFCC66", "block_icon" => "https://cdn-icons-png.flaticon.com/512/1490/1490858.png"),

			array('block_id' => "3", 'block_points' => "5", 'block_bg' => "#DDA300", "block_text_color" => "#333333", "block_icon" => "https://cdn-icons-png.flaticon.com/512/1490/1490858.png"),

			array('block_id' => "4", 'block_points' => "0", 'block_bg' => "#59004D", "block_text_color" => "#FFCC66", "block_icon" => "https://cdn-icons-png.flaticon.com/512/1490/1490858.png"),

			array('block_id' => "5", 'block_points' => "10", 'block_bg' => "#DDA300", "block_text_color" => "#333333", "block_icon" => "https://cdn-icons-png.flaticon.com/512/1490/1490858.png"),

			array('block_id' => "6", 'block_points' => "5", 'block_bg' => "#59004D", "block_text_color" => "#FFCC66", "block_icon" => "https://cdn-icons-png.flaticon.com/512/1490/1490858.png"),

			array('block_id' => "7", 'block_points' => "0", 'block_bg' => "#DDA300", "block_text_color" => "#333333", "block_icon" => "https://cdn-icons-png.flaticon.com/512/1490/1490858.png"),

			array('block_id' => "8", 'block_points' => "10", 'block_bg' => "#59004D", "block_text_color" => "#FFCC66", "block_icon" => "https://cdn-icons-png.flaticon.com/512/1490/1490858.png")
		);

		$result['buttonImage'] = "http://eazyearning.com/Api/spin/design1/btn_spin_now.json";
		$result['spinImage'] = "http://eazyearning.com/Api/spin/design1/spin_circle.json";
		$result['buttonTextColor'] = "#ffffff";
		$result['labelBackgroundImage'] = "http://eazyearning.com/Api/spin/design1/bg_spin_number_label.png";
		$result['backgroundImage'] = "http://eazyearning.com/Api/spin/design1/background.json";
		$result['timerTextColor'] = "#ff0000";

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		$result['data'] = $data;
		$result['message'] = "Data Found Sucessfully.";
		$result['status'] = "1";

		$result['daily_spinner_limit'] = (string)$DailySpinLimit;
		$result['remain_spin'] = (string)$RemailSpin;
		$result['spinTime'] = "60";

		$result['tigerInApp'] = "";

		// $result['exitDialog']['title']="Watch Video and Earn Fast";
		// $result['exitDialog']['btnName']="Watch Video";
		// $result['exitDialog']['btnColor']="#F93647";
		// $result['exitDialog']['description']="How to earn Easy & Fast Point.";
		// $result['exitDialog']['image']="https://sportsgurupro.com/admin/images/homeslider/239_RedeemcodeProof2.jpg";
		// $result['exitDialog']['screenNo']="14";
		// $result['exitDialog']['url']="https://youtu.be/SOH80R0mB0g";

		// $flip = rand(0, 8);
		// if ($flip == '1' || $flip == '2' || $flip == '5') {

		// $result['floatingAds']['image'] = "https://mycashbazar.com/GIF/qureka.gif";
		// $result['floatingAds']['url'] = "https://sportsgurupro.com/Quiz/kbc-2022";
		// $result['floatingAds']['screenNo'] = "2";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;
		// } else {

		// $result['floatingAds']['image'] = "https://www.bigtricks.in/assets/bn.gif";
		// $result['floatingAds']['url'] = "https://t.me/mycashbazar";
		// $result['floatingAds']['screenNo'] = "2";


		// $result['topAds']['image'] = "https://mycashbazar.com/GIF/2rsWithdraw.gif";
		// $result['topAds']['screenNo'] = "5";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;
		// }

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		// $result['floatingAds']['image'] = "https://www.bigtricks.in/assets/bn.gif";
		// $result['floatingAds']['url'] = "https://t.me/rewardbox";
		// $result['floatingAds']['screenNo'] = "2";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		/////////////// COMPLETE TASK BEFORE SPIN //////////
		if (strlen($userId) > 0) {
			$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Daily Spin.";
				$result['taskButton'] = "Complete Easy Task Now";
				//$result['taskId'] = "1";
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		// if($RemailSpin == 12 || $RemailSpin == 11)
		// {
		// $result['isTodayTaskCompleted'] = "1";
		// }


		/////////////// WATCH WEBSITE //////////
		$result['isWatchWebsite'] = "0";
		$result['watchWebsiteUrl'] = "https://sportsgurupro.com";
		$result['watchWebsiteTime'] = "20"; // in seconds

		$this->response($this->json($result), 200);
	}



	private function getUserAgent()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$agent = $_SERVER['HTTP_USER_AGENT'];
		// echo ;

		$result['message'] = "Data Found Sucessfully.";
		$result['status'] = "1";
		$result['agent'] = $agent;
		$this->response($this->json($result), 200);
	}


	// saveshareoffer
	private function SITA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		// $Details = json_decode($this->_request['details'], true);

		$userId = $Details['BWUTJ6'];
		$offerId = $Details['RMQ2GP'];
		$length = 10;
		$characters = '0123456789TDNEpUTHQoQUJMHLrErGJyHg89uy71MyuHXYHZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		$URL = "http://eazyearning.com/ShareOffer/" . $randomString;
		if (strlen($userId) > 0 && strlen($offerId) > 0) {
			$sqinsert = mysqli_query($this->db, "INSERT INTO reffer_task_redirection (offerId,userId,offer_url) VALUES ('" . $offerId . "', '" . $userId . "', '" . $URL . "') ");
			if ($sqinsert) {
				$setting = mysqli_query($this->db, "SELECT * FROM task_offer WHERE id = '" . $offerId . "' ");
				if (mysqli_num_rows($setting) > 0) {
					$taskDetails = $setting->fetch_assoc();
					$result['shareUrl'] = $URL;
					$result['shareMessage'] = "Hi!! Unlock amazing rewards, " . $taskDetails['title'] . "

✅ " . $taskDetails['description'] . " & earn money!

🔗 Download now and start earning " . $URL;
					$result['shareMessageWhatsApp'] = "Hi!! Unlock amazing rewards, *" . $taskDetails['title'] . "* 

✅ " . $taskDetails['description'] . " & earn money! 

🔗 *Download now and start earning* " . $URL;
					$result['shareImage'] = $taskDetails['displayImage'];
					$result['message'] = "Data Found Sucessfully.";
					$result['status'] = "1";
				}
			} else {
				$result['message'] = "Data Not Found";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Data Not Found1";
			$result['status'] = "0";
		}
		$this->response($this->json($result), 200);
	}


	//SaveSpinData
	private function EAR()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Server_key;
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		// $Details = json_decode($this->_request['details'], true);
		$userId = $Details['LYS7IW'];
		$adId = $Details['W7ZITM'];
		$point = $Details['THMHVA'];
		$deviceName = $Details['XBTS28'];
		$appVersion = $Details['DXNG8J'];
		$deviseId = $Details['HBBP6O'];
		$todayOpen = $Details['Z5BBEI'];
		$totalOpen = $Details['TPNM0U'];
		$DailySpinLimit = 12;
		$RemailSpin = 0;
		$DateToday = date('Y-m-d');
		$result = array();
		$result['point'] = $point;
		$agent = $_SERVER['HTTP_USER_AGENT'];
		// 		$agent = "okhttp/3.12.13";

		$result['spinTime'] = "60";

		if ($agent == "okhttp/5.0.0-alpha.2") {
			// if ($point == "0" || $point == "1" || $point == "2" || $point == "4" || $point == "5" || $point == "6" || $point == "7") {
			if ($point == "0" || $point == "10"   || $point == "5") {

				// if ($adId == null || strlen($adId) == 0 || $point == "500") {

				if ($point == "500") {
					$result['message'] = "Something went wrong, please try again.";
					$result['status'] = "0";
				} else {
					if ((int)$point > 3 && (int)$point < 0) {
						$result['message'] = "Something went wrong, please try again.1";
						$result['status'] = "0";
					} else {
						$isActive = "1";
						$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,isSpinAllow FROM user_master WHERE userId = '" . $userId . "' ");
						if ($sqlRederID->num_rows > 0) {
							$rowewf = $sqlRederID->fetch_assoc();
							$earning_point = $rowewf['earningPoint'];
							$token = $rowewf['token'];
							$adId2 = $rowewf['adId'];
							$isActive = $rowewf['isActive'];
							$isSpinAllow = $rowewf['isSpinAllow'];
						}

						if ($isActive = "1" && $isSpinAllow == "1" && $adId2 == $adId) {

							$sqlSPinCount = mysqli_query($this->db, "SELECT id FROM spin_point WHERE userId = '" . $userId . "' AND dateAdd = '" . $DateToday . "' ");
							$spinUsed = $sqlSPinCount->num_rows;

							$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
							$totalTodayTask = mysqli_num_rows($sql1);
							if ($totalTodayTask > 0) {
								$result['spinEanble'] = "1";
							} else {
								$spinUsed = 15;
							}

							if ($spinUsed > $DailySpinLimit) {
								$result['message'] = "Spin from multiple device is not allowed, So please spin from old device OR Please contect us $email
 email address to get solution.";
								$result['status'] = "0";
							} else {
								$checkSpinUser = mysqli_query($this->db, "SELECT id FROM spin_point WHERE userId = '" . $userId . "' AND dateAdd = '" . $DateToday . "' ");

								if ($checkSpinUser->num_rows >= $DailySpinLimit) {
									$result['message'] = "Something went wrong, please login again. 2";
									$result['status'] = "0";
								} else {
									$checkSpin = mysqli_query($this->db, "SELECT id FROM spin_point WHERE  userId = '" . $userId . "'  AND dateAdd = '" . $DateToday . "' ");
									$checkSpinNum = mysqli_num_rows($checkSpin);
									if ($checkSpinNum > 0) {
										$RemailSpin = $DailySpinLimit - $checkSpinNum;
									} else {
										$RemailSpin = $DailySpinLimit;
									}


									$lastDate = "2019-10-17 07:27:37";
									$sqlLastDate = mysqli_query($this->db, "SELECT entryDate FROM spin_point WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1 ");
									if ($sqlLastDate->num_rows > 0) {
										$rowewf1 = $sqlLastDate->fetch_assoc();
										$lastDate = $rowewf1['entryDate'];
									}
									$currenttime = date('Y-m-d H:i:s');

									$start_date = new DateTime($lastDate);
									$since_start = $start_date->diff(new DateTime($currenttime));
									//$interval =  $since_start->i;

									$minutes = $since_start->days * 24 * 60;
									$minutes += $since_start->h * 60;
									$minutes += $since_start->i;
									// $minutes = 2;
									if ((int)$minutes > 60) {
										if ($RemailSpin > 0) {
											$sqinsert = mysqli_query($this->db, "INSERT INTO spin_point (userId,points,dateAdd,adId,deviceName) VALUES ('" . $userId . "', '" . $point . "', '" . $DateToday . "', '" . $adId . "', '" . $deviceName . "') ");
											// $result['query']="INSERT INTO spin_point (userId,points,dateAdd,adId) VALUES ('".$userId."', '".$point."', '".$DateToday."', '".$adId."') ";
											if ($sqinsert === TRUE) {


												$finalearning_point = (int)$earning_point + (int)$point;
												mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $point . "', '6', '1','" . $finalearning_point . "','Lucky Spin')");


												$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE userId = '" . $userId . "'  ");

												$ep1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "'  ");

												$ep = $ep1->fetch_assoc();
												// $result['earningPoint'] = $ep['earningPoint'];

												if ($sqlwalletupdate === TRUE) {
													$this->sendDailyLoginNoti($token, $point);
													$result['earningPoint'] = $ep['earningPoint'];
													$result['message'] = "Data Found Sucessfully.";
													$result['status'] = "1";
													$result['creditPoint'] = $point;
													$result['todayDate'] = date('Y-m-d H:i:s');
													$result['lastDate'] = date('Y-m-d H:i:s');
													$temp = (int)$RemailSpin - 1;
													$result['remain_spin'] = $temp;
												} else {
													$result['message'] = "Something went wrong, please try again.3";
													$result['status'] = "0";
												}
											} else {
												$result['message'] = "Something went wrong, please try again.4";
												$result['status'] = "0";
											}
										} else {
											$result['message'] = "You have exhausted 12 spin limit per day. It will be available again tomorrow.";
											$result['status'] = "0";
											$result['remain_spin'] = "0";
										}
									} else {

										$result['message'] = "Please try again after 1 hour. Your 1 hour is not completed." . $minutes;
										// $result['message'] = "Something went wrong, please try again after 1 hour. Your 1 hour is not Completed.";
										$result['status'] = "0";
									}
								}
							}
						} else {

							$result['message'] = "Your account is blocked for some reason. Please contact us on $email
 email address to get solution.";
							$result['status'] = "5";

							if ($isSpinAllow == "0") {
								$result['message'] = "Spin feature is disabled for your account. Please contact us on $email
 email address to get solution.";
								$result['status'] = "5";
							} else {

								$result['message'] = "Your account is blocked for some reason. Please contact us on $email
 email address to get solution.";
								$result['status'] = "5";
							}
						}
					}
				}
				$result['daily_spinner_limit'] = (string)$DailySpinLimit;
				$result['tigerInApp'] = "";
			} else {
				$result['message'] = "Something went wrong, please try again.5";
				$result['status'] = "0";
			}
		} else {

			$result['message'] = "Something went wrong, please try again.6";
			$result['status'] = "0";
		}

		$result['point'] = $point;
		if ((int)$point > 10) {
			$result['isShowAds'] = "1";
		} else {
			$result['isShowAds'] = "0";
		}
		$result['tigerInApp'] = "";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}
	//getImagePuzzleData
	private function BEAAR()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['88Y66R'];

		$imploded = "";
		$lastPuzzleDate =  date("2023-04-04 16:55:00");

		if (strlen($userId) > 0 && (int)$userId > 0) {
			$sqlRefcode1 = mysqli_query($this->db, "SELECT puzzleId FROM puzzle_history WHERE userId ='" . $userId . "' ");
			if (mysqli_num_rows($sqlRefcode1) > 0) {
				while ($row1 =  mysqli_fetch_array($sqlRefcode1, MYSQLI_ASSOC)) {
					$rows[] = $row1['puzzleId'];
				}
				$imploded = implode(',', $rows);
			}
			$sqlRefcode = mysqli_query($this->db, "SELECT id,entryDate FROM puzzle_history WHERE userId ='" . $userId . "' ORDER BY id DESC LIMIT 1");
			if (mysqli_num_rows($sqlRefcode) > 0) {
				$row = $sqlRefcode->fetch_assoc();
				$lastPuzzleDate = $row['entryDate'];
			}
		}
		$lastDayquerry = "";
		if ($imploded == "") {
			$lastDayquerry = "SELECT * FROM puzzle_images WHERE isActive = '1' AND startDate < '" . $date . "' AND endDate > '" . $date . "'   ORDER BY id ASC limit 1";
		} else {
			$lastDayquerry = "SELECT * FROM puzzle_images WHERE id NOT IN  (" . $imploded . ") AND isActive = '1' AND startDate < '" . $date . "' AND endDate > '" . $date . "'   ORDER BY id ASC limit 1";
		}

		if (strlen($lastDayquerry) > 0) {
			$lastDayquerry = mysqli_query($this->db, $lastDayquerry);
			if (mysqli_num_rows($lastDayquerry) > 0) {
				$row = $lastDayquerry->fetch_assoc();
				$result = $row;
				$result['status'] = "1";
				$result['message'] = "Data found successfully";
			} else {
				$result['message'] = "Currently there is no puzzle available to solve. Try again after some time.";
				$result['status'] = "2";
			}
		}
		$result['lastPuzzleDate'] = $lastPuzzleDate;
		$result['puzzleTimer'] =  "120"; // in minutes		
		$result['todayDate'] =  date("Y-m-d H:i:s");
		// $result['helpVideoUrl'] = $Youtube_url;

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock Image Puzzle.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "31";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Image Puzzle.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		$this->response($this->json($result), 200);
	}
	//saveImagePuzzleData
	private function BHOPI()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['UZNNN7'];
		$point = $Details['YH93RQ'];
		$puzzleId = $Details['2PX9X4'];
		$userToken = $Details['T1NGGU'];
		$result['status'] = "1";
		$result['message'] = "Data found successfully";

		$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
		$totalTodayTask = mysqli_num_rows($sql1);
		if (strlen($userId) > 0 && (int)$userId > 0 && $totalTodayTask > 0 && strlen($puzzleId) > 0 && strlen($userToken) > 0) {

			$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
			$totalTodayTask = mysqli_num_rows($sql1);

			if ($totalTodayTask > 0) {
				$lastDayquerry1 = mysqli_query($this->db, "SELECT id FROM puzzle_history WHERE  puzzleId = '" . $puzzleId . "' AND userId = '" . $userId . "' ");
				if (mysqli_num_rows($lastDayquerry1) > 0) {
					$result['message'] = "You have alredy claimed this puzzle reward.";
					$result['status'] = "0";
				} else {
					$lastDayquerry = mysqli_query($this->db, "SELECT * FROM puzzle_images WHERE  id = '" . $puzzleId . "' ");
					if (mysqli_num_rows($lastDayquerry) > 0) {
						$row = $lastDayquerry->fetch_assoc();
						$points = $row['points'];

						$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,isSpinAllow,userToken FROM user_master WHERE userId = '" . $userId . "' ");
						if ($sqlRederID->num_rows > 0) {
							$rowewf = $sqlRederID->fetch_assoc();
							$earning_point = $rowewf['earningPoint'];
							$token = $rowewf['token'];
							$adId2 = $rowewf['adId'];
							$userToken2 = $rowewf['userToken'];


							if ($userToken == $userToken2) {
								$sqinsert = mysqli_query($this->db, "INSERT INTO puzzle_history(ipAddress,userId, puzzleId, points) VALUES ('" . $ipaddress . "', '" . $userId . "', '" . $puzzleId . "', '" . $points . "' )");
								if ($sqinsert === TRUE) {
									$finalearning_point = (int)$earning_point + (int)$points;

									$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $points . "', '21', '1','" . $finalearning_point . "','Puzzle Game')");


									$tid = $this->gen_uuid();
									$result['userDetails']['userToken'] = $tid;
									$result['userToken'] = $tid;
									$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' ,userToken = '" . $tid . "'  WHERE userId = '" . $userId . "'  ");
									if ($sqlwalletupdate === TRUE) {
										$result['earningPoint'] = $finalearning_point;
										$result['message'] = "Data Found Sucessfully.";
										$result['status'] = "1";
									} else {
										$result['message'] = "Something went wrong.";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "Something went wrong. Login Again";
								$result['status'] = "5";
							}
						}
					} else {
						$result['message'] = "Something went wrong.";
						$result['status'] = "0";
					}
				}
			} else {
				$result['message'] = "You have not completed today's Task & Game";
				$result['status'] = "0";
			}
		}
		$result['puzzleTimer'] =  "120";
		$result['lastPuzzleDate'] = date("Y-m-d H:i:s");
		$result['todayDate'] =  date("Y-m-d H:i:s");
		// $result['helpVideoUrl'] = $Youtube_url;
		$this->response($this->json($result), 200);
	}
	//getQuizData
	private function YOSEF()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['619FAQ'];

		$lastDayquerry = mysqli_query($this->db, "SELECT * FROM quiz_master WHERE isActive = '1' AND status = '0' AND startDate < '" . $date . "' AND endDate > '" . $date . "'   ORDER BY id DESC limit 1");
		if (mysqli_num_rows($lastDayquerry) > 0) {
			$row = $lastDayquerry->fetch_assoc();
			$result = $row;
			$quizId = $row['id'];
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
		} else {
			$result['message'] = "Currently there is no quiz available. Try again after some time.";
			$result['status'] = "2";
		}
		if (strlen($userId) > 0 && (int)$userId > 0) {
			$ep1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "'  ");
			$ep = $ep1->fetch_assoc();
			$result['earningPoint'] = $ep['earningPoint'];

			$answer = mysqli_query($this->db, "SELECT userAnswer FROM quiz_history WHERE userId = '" . $userId . "' AND quizId = '" . $quizId . "'");
			if (mysqli_num_rows($answer) > 0) {
				$userAnswer = $answer->fetch_assoc();
				$result['userAnswer'] = $userAnswer['userAnswer'];
			}
		}

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "http://eazyearning.com/Api/upload/tataiplwin.jpg";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = "https://play.google.com/store/apps/details?id=sportsguru.ipl.cricket.expert";

		if (strlen($userId) > 0) {
			$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Quiz.";
				$result['taskButton'] = "Complete Easy Task Now";
				//$result['taskId'] = "1";
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		$this->response($this->json($result), 200);
	}
	//saveQuizData
	private function XOCHITL()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['9OH2B8'];
		$point = $Details['2P0P7A'];
		$quizId = $Details['9CWGVL'];
		$selectedAnswer = $Details['OIOOP4'];

		$result['status'] = "1";
		$result['message'] = "Data found successfully";



		$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
		$totalTodayTask = mysqli_num_rows($sql1);

		if ($totalTodayTask > 0) {
			if (strlen($quizId) > 0 && strlen($selectedAnswer) > 0) {
				$sql1 = mysqli_query($this->db, "SELECT id FROM quiz_history WHERE userId = '" . $userId . "' AND quizId = '" . $quizId . "' ");
				if ($sql1->num_rows > 0) {
					$fetchhistory = $sql1->fetch_assoc();
					$historyId = $fetchhistory['id'];
					$sqinsert = mysqli_query($this->db, "UPDATE quiz_history SET userAnswer = '" . $selectedAnswer . "'  WHERE id ='" . $historyId . "' ");
					if ($sqinsert === TRUE) {
						$result['message'] = "Quiz answer has been updated successfully.";
						$result['status'] = "1";
					}
				} else {
					$sqinsert = mysqli_query($this->db, "INSERT INTO quiz_history(ipAddress,userId, quizId, userAnswer) VALUES ('" . $ipaddress . "', '" . $userId . "', '" . $quizId . "', '" . $selectedAnswer . "' )");
					if ($sqinsert === TRUE) {
						$result['message'] = "Quiz answer has been submitted successfully.";
						$result['status'] = "1";
					}
				}
			} else {
				$result['message'] = "Someting wrong try again.";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "You have not completed today's Task & Game";
			$result['status'] = "0";
		}


		if (strlen($userId) > 0 && (int)$userId > 0) {
			$ep1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "'  ");
			$ep = $ep1->fetch_assoc();
			$result['earningPoint'] = $ep['earningPoint'];
		}

		$this->response($this->json($result), 200);
	}
	///getQuizHistory
	private function WILLIAM()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['QQ48HI'];
		$type = $Details['N9PLFR'];
		$total = 0;
		$result['todayDate'] =  date("Y-m-d H:i:s");
		$PAGE_NO = $Details['MQSI17'];
		$perpage = 15;
		$calc = $perpage * $PAGE_NO;
		$start = $calc - $perpage;

		if (strlen($userId) > 0 && strlen($type) > 0) {
			if ($type == "1") { // my quiz
				$sql1 = mysqli_query($this->db, "SELECT id FROM quiz_history WHERE userId = '" . $userId . "'  ");
				$total = mysqli_num_rows($sql1);
				//mysqli_free_result($sql1);
				if ($total > 0) {
					//$sql = mysqli_query($this->db, "SELECT * FROM quiz_history WHERE userId = '" . $userId . "' ORDER BY id DESC LIMIT " . $start . "," . $perpage . " ");

					$sql = mysqli_query($this->db, "SELECT t1.*,t2.question,t2.image,t2.answer,t2.optionA,t2.optionB,t2.optionC,t2.optionD,t2.points as quizPoints FROM quiz_history as t1 left join quiz_master as t2 on t2.id = t1.quizId WHERE t1.userId = '" . $userId . "' ORDER BY t1.id DESC LIMIT " . $start . "," . $perpage . " ");

					//$num = mysqli_num_rows($sql);
					$NumRows = mysqli_num_rows($sql);
					if ($NumRows > 0) {
						$totalPages = ceil($total / $perpage);
						$result['totalPage'] = $totalPages;
						$result['totalIteam'] = $total;
						$result['currentPage'] = $PAGE_NO;
						$result['message'] = "Data Found Sucessfully.";
						$result['status'] = "1";
						while ($rlt = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
							$result['quizMyHistoryList'][] = $rlt;
						}
					} else {
						$result['message'] = "Data Not Found.";
						$result['status'] = "2";
					}
				} else {
					$result['message'] = "Data Not Found.";
					$result['status'] = "2";
				}
			}
			if ($type == "2") { // all quiz
				$sql1 = mysqli_query($this->db, "SELECT id FROM quiz_master WHERE isActive = '1'  ");
				$total = mysqli_num_rows($sql1);
				//mysqli_free_result($sql1);
				if ($total > 0) {
					$sql = mysqli_query($this->db, "SELECT * FROM quiz_master WHERE isActive = '1' ORDER BY id DESC LIMIT " . $start . "," . $perpage . " ");
					//$num = mysqli_num_rows($sql);
					$NumRows = mysqli_num_rows($sql);
					if ($NumRows > 0) {
						$totalPages = ceil($total / $perpage);
						$result['totalPage'] = $totalPages;
						$result['totalIteam'] = $total;
						$result['currentPage'] = $PAGE_NO;
						$result['message'] = "Data Found Sucessfully.";
						$result['status'] = "1";
						while ($rlt = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
							$result['quizAllHistoryList'][] = $rlt;
						}
					} else {
						$result['message'] = "Data Not Found.";
						$result['status'] = "2";
					}
				} else {
					$result['message'] = "Data Not Found.";
					$result['status'] = "2";
				}
			}
			$epquerry = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId  = '" . $userId . "' ");
			if (mysqli_num_rows($epquerry) > 0) {
				$rlContest = mysqli_fetch_array($epquerry, MYSQLI_ASSOC);
				$result['earningPoint'] = $rlContest['earningPoint'];
			}
		} else {
			$result['message'] = "Something went wrong";
			$result['status'] = "0";
		}

		$this->response($this->json($result), 200);
	}
	//getDailyRewardList
	private function ALIAN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		$Details = json_decode($this->_request['details'], true);

		// $decrypted = MCrypt::decrypt($this->_request['details']);
		// $Details = json_decode($decrypted, true);
		$token = $Details['65S0ZN'];
		$userId = $Details['NFLLED'];
		$appVersion = $Details['W5OWX6'];
		$deviceName = $Details['3XWTHQ'];
		$deviseId = $Details['DMIW6T'];
		$adId = $Details['QXHTSB'];
		$todayOpen = $Details['021I5R'];
		$totalOpen = $Details['43553X'];

		$ipaddress = $this->getIp();
		$date = date('Y-m-d');
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$TodayOnlydate = date('Y-m-d');


		$result['data'][0]['type'] = "dailyLogin";
		$result['data'][0]['title'] = "Daily Login";
		$result['data'][0]['description'] = "Claim today's login points.";
		$result['data'][0]['totalCount'] = "1";
		$result['data'][0]['screenNo'] = "14";
		$result['data'][0]['icon'] = "https://cdn-icons-png.flaticon.com/128/9399/9399562.png";
		$result['data'][0]['bgColor'] = "#fff4e0";
		$result['data'][0]['buttoncolor'] = "#fc891e";
		$result['data'][0]['buttonText'] = "Claim Now";
		$result['data'][0]['buttonTextColor'] = "#ffffff";
		$chkattndns = mysqli_query($this->db, "SELECT * from daily_attendance_point WHERE userId ='" . $userId . "' AND add_date ='" . $TodayOnlydate . "' ORDER BY id DESC limit 1");
		if ($chkattndns->num_rows > 0) {
			$result['data'][0]['isCompleted'] = "1";
			$result['data'][0]['buttonText'] = "Completed";
			$result['data'][0]['totalCompleted'] = "1";
		} else {
			$result['data'][0]['isCompleted'] = "0";
			$result['data'][0]['totalCompleted'] = "0";
		}


		$result['data'][1]['type'] = "watchVideo";
		$result['data'][1]['title'] = "Watch Video & Earn";
		$result['data'][1]['description'] = "Watch 5 videos today.";
		$result['data'][1]['totalCount'] = "5";
		$result['data'][1]['screenNo'] = "21";
		$result['data'][1]['icon'] = "https://cdn-icons-png.flaticon.com/128/3074/3074767.png";
		$result['data'][1]['bgColor'] = "#fffafc";
		$result['data'][1]['buttoncolor'] = "#e60056";
		$result['data'][1]['buttonText'] = "Watch Now";
		$result['data'][1]['buttonTextColor'] = "#ffffff";
		$sql1 = mysqli_query($this->db, "SELECT id FROM watch_video_points WHERE userId = '" . $userId . "'  AND add_date ='" . $TodayOnlydate . "' ");
		$totalTodayTask = mysqli_num_rows($sql1);
		if ($totalTodayTask > 0) {
			if ($totalTodayTask > 4) {
				$result['data'][1]['buttonText'] = "Completed";
				$result['data'][1]['isCompleted'] = "1";
				$result['data'][1]['totalCompleted'] = "5";
			} else {
				$result['data'][1]['isCompleted'] = "0";
				$result['data'][1]['totalCompleted'] = $totalTodayTask;
			}
		} else {
			$result['data'][1]['isCompleted'] = "0";
			$result['data'][1]['totalCompleted'] = "0";
		}


		$result['data'][2]['type'] = "taskOffers";
		$result['data'][2]['title'] = "Complete Task";
		$result['data'][2]['description'] = "Complete today's 5 easy task offers.";
		$result['data'][2]['totalCount'] = "5";
		$result['data'][2]['screenNo'] = "11";
		$result['data'][2]['icon'] = "https://cdn-icons-png.flaticon.com/128/1527/1527478.png";
		$result['data'][2]['bgColor'] = "#f7faff";
		$result['data'][2]['buttoncolor'] = "#1463f6";
		$result['data'][2]['buttonText'] = "Do Now";
		$result['data'][2]['buttonTextColor'] = "#ffffff";
		$sql2 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayTask = mysqli_num_rows($sql2);
		if ($totalTodayTask > 0) {
			if ($totalTodayTask > 4) {
				$result['data'][2]['buttonText'] = "Completed";
				$result['data'][2]['isCompleted'] = "1";
				$result['data'][2]['totalCompleted'] = "5";
			} else {
				$result['data'][2]['isCompleted'] = "0";
				$result['data'][2]['totalCompleted'] = $totalTodayTask;
			}
		} else {
			$result['data'][2]['isCompleted'] = "0";
			$result['data'][2]['totalCompleted'] = "0";
		}


		$result['data'][3]['type'] = "referFriends";
		$result['data'][3]['title'] = "Refer Your Friends";
		$result['data'][3]['description'] = "Share your referal link with your friends & earn points when they signup with your referral code.";
		$result['data'][3]['totalCount'] = "3";
		$result['data'][3]['screenNo'] = "8";
		$result['data'][3]['icon'] = "https://cdn-icons-png.flaticon.com/128/4753/4753285.png";
		$result['data'][3]['bgColor'] = "#fcfdf2";
		$result['data'][3]['buttoncolor'] = "#9ab218";
		$result['data'][3]['buttonText'] = "Refer Now";
		$result['data'][3]['buttonTextColor'] = "#ffffff";
		$sql2 = mysqli_query($this->db, "SELECT userId FROM user_master WHERE referralUserId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayTask = mysqli_num_rows($sql2);
		if ($totalTodayTask > 0) {
			if ($totalTodayTask > 2) {
				$result['data'][3]['buttonText'] = "Completed";
				$result['data'][3]['isCompleted'] = "1";
				$result['data'][3]['totalCompleted'] = "3";
			} else {
				$result['data'][3]['isCompleted'] = "0";
				$result['data'][3]['totalCompleted'] = $totalTodayTask;
			}
		} else {
			$result['data'][3]['isCompleted'] = "0";
			$result['data'][3]['totalCompleted'] = "0";
		}

		$DateToday = date('Y-m-d');
		$result['todayDate'] = date('Y-m-d H:i:s');
		$result['endDate'] = $DateToday . ' 23:59:59';

		$result['message'] = "Data Found";
		$result['status'] = "1";

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";
		$sqlIsClaimed = mysqli_query($this->db, "SELECT id FROM daily_reward_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalClaimed = mysqli_num_rows($sqlIsClaimed);
		if ($totalClaimed > 0) {
			$result['isClaimedDailyReward'] = "1";
		} else {
			$result['isClaimedDailyReward'] = "0";
		}
		$result['totalPoints'] = "100";
		$result['note'] = "Complete today's daily reward list and claim extra <b>" . $result['totalPoints'] . "</b> reward points.";
		$result['isShowInterstitial'] = "1"; // interstitial , 2= rewarded

		$this->response($this->json($result), 200);
	}
	//saveDailyReward
	private function TITANIC()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$token = $Details['FFNO2A'];
		$userId = $Details['RRNEAK'];
		$appVersion = $Details['WPVSWN'];
		$deviceName = $Details['O0AAWC'];
		$deviseId = $Details['F1MDEC'];
		$adId = $Details['RNMCQK'];
		$todayOpen = $Details['NEDVPS'];
		$totalOpen = $Details['7GLWP8'];
		$userToken = $Details['92QTXW'];
		$dayy = $Details['I3399W'];
		$ipaddress = $this->getIp();
		$date = date('Y-m-d');
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$TodayOnlydate = date('Y-m-d');
		$date = date('Y-m-d');
		$points = "100";

		if ($userId > 0) {
			$sqlIsClaimed = mysqli_query($this->db, "SELECT id FROM daily_reward_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalClaimed = mysqli_num_rows($sqlIsClaimed);
			if ($totalClaimed == 0) {
				$isDailyLoginComplite = "0";
				$isWatchVideoComplite = "0";
				$isTaskOfferComplite = "0";
				$isReferComplite = "0";

				$chkattndns = mysqli_query($this->db, "SELECT * from daily_attendance_point WHERE userId ='" . $userId . "' AND add_date ='" . $TodayOnlydate . "' ORDER BY id DESC limit 1");
				if ($chkattndns->num_rows > 0) {
					$isDailyLoginComplite = "1";
				} else {
					$isDailyLoginComplite = "0";
				}

				$sql1 = mysqli_query($this->db, "SELECT id FROM watch_video_points WHERE userId = '" . $userId . "'  AND add_date ='" . $TodayOnlydate . "' ");
				$totalTodayTask = mysqli_num_rows($sql1);
				if ($totalTodayTask > 0) {
					if ($totalTodayTask > 4) {
						$isWatchVideoComplite = "1";
					} else {
						$isWatchVideoComplite = "0";
					}
				} else {
					$isWatchVideoComplite = "0";
				}


				$sql2 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
				$totalTodayTask = mysqli_num_rows($sql2);
				if ($totalTodayTask > 0) {
					if ($totalTodayTask > 4) {
						$isTaskOfferComplite = "1";
					} else {
						$isTaskOfferComplite = "0";
					}
				} else {
					$isTaskOfferComplite = "0";
				}

				$sql5 = mysqli_query($this->db, "SELECT userId FROM user_master WHERE referralUserId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
				$totalTodayTask = mysqli_num_rows($sql5);
				if ($totalTodayTask > 0) {
					if ($totalTodayTask > 2) {
						$isReferComplite = "1";
					} else {
						$isReferComplite = "0";
					}
				} else {
					$isReferComplite = "0";
				}

				if ($isDailyLoginComplite == "1" && $isWatchVideoComplite == "1" && $isTaskOfferComplite == "1" && $isReferComplite == "1") {
					$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,isSpinAllow,userToken FROM user_master WHERE userId = '" . $userId . "' ");
					if ($sqlRederID->num_rows > 0) {
						$rowewf = $sqlRederID->fetch_assoc();
						$earning_point = $rowewf['earningPoint'];
						$token = $rowewf['token'];
						$adId2 = $rowewf['adId'];
						$userToken2 = $rowewf['userToken'];

						if ($userToken == $userToken2) {
							$sqinsert = mysqli_query($this->db, "INSERT INTO daily_reward_history(userId, points) VALUES ('" . $userId . "', '" . $points . "')");
							if ($sqinsert === TRUE) {

								$finalearning_point = (int)$earning_point + (int)$points;

								$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $points . "', '25', '1','" . $finalearning_point . "','Daily Rewards')");

								$tid = $this->gen_uuid();
								$result['userDetails']['userToken'] = $tid;
								$result['userToken'] = $tid;

								$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint = '" . $finalearning_point . "' ,userToken = '" . $tid . "' WHERE userId = '" . $userId . "'  ");
								if ($sqlwalletupdate === TRUE) {
									$result['earningPoint'] = $finalearning_point;
									$result['message'] = "Your daily reward points has been claimed successfully.";
									$result['status'] = "1";
									$result['points'] = $points;
								} else {
									$result['message'] = "Something went wrong.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "Something went wrong.";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "Something went wrong. Login Again";
							$result['status'] = "5";
						}
					} else {
						$result['message'] = "Something went wrong, please try again later.";
						$result['status'] = "0";
					}
				} else {

					if ($isDailyLoginComplite == "0") {
						$result['message'] = "Please complete today's daily login.";
						$result['status'] = "0";
					} elseif ($isWatchVideoComplite == "0") {
						$result['message'] = "Please watch 5 videos today.";
						$result['status'] = "0";
					} elseif ($isTaskOfferComplite == "0") {
						$result['message'] = "Please complete 3 task offers.";
						$result['status'] = "0";
					} elseif ($isReferComplite == "0") {
						$result['message'] = "Please refer your 2 friends today.";
						$result['status'] = "0";
					}
				}
			} else {
				$result['message'] = "You have already claimed today's daily reward.";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later.";
			$result['status'] = "0";
		}
		$this->response($this->json($result), 200);
	}
	//getGamesList
	private function BUTAN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$perpage = 50;
		$userId = $Details['2U6W3U'];
		$appVersion = $Details['NFGQI5'];
		$deviceName = $Details['9OWSIQ'];
		$deviseId = $Details['EIJJQW'];
		$adId = $Details['DVC6WQ'];
		$todayOpen = $Details['5V4S03'];
		$totalOpen = $Details['9ZZOXW'];
		$userToken = $Details['4TDMO6'];
		$PAGE_NO = $Details['KN0DI6'];
		$calc = $perpage * $PAGE_NO;
		$start = $calc - $perpage;
		$date = date('Y-m-d H:i:s');

		$resSlider = mysqli_query($this->db, "SELECT * FROM geme_slider WHERE  isActive = '1' ORDER BY sliderIndex DESC LIMIT 0,7");
		if (mysqli_num_rows($resSlider) > 0) {
			while ($rlContest = mysqli_fetch_array($resSlider, MYSQLI_ASSOC)) {
				$result['homeSlider'][] = $rlContest;
			}
			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";
		} else {
			$result['message'] = "No Data Found Sucessfully.";
			$result['status'] = "0";
		}
		$result['homeNote'] = "";
		// $result['homeNote']="<iframe width='100%' height='85px'  scrolling='no' src='https://sportsgurupro.com/api/ads.php' frameBorder='0'></iframe>";
		$sqlRederID = mysqli_query($this->db, "SELECT id FROM game_list WHERE isActive = '1' ");
		$total = mysqli_num_rows($sqlRederID);
		if ($total > 0) {
			$sql = mysqli_query($this->db, "SELECT id,title,bigBanner,mainScreenNo,url FROM game_list WHERE isActive = '1' ORDER BY gIndex DESC LIMIT " . $start . "," . $perpage . " ");

			$num = mysqli_num_rows($sql);
			$NumRows = mysqli_num_rows($sql);
			if ($NumRows > 0) {
				$totalPages = ceil($total / $perpage);
				$result['totalPage'] = $totalPages;
				$result['totalIteam'] = $total;
				$result['currentPage'] = $PAGE_NO;
				$result['message'] = "Data Found Sucessfully.";
				$result['status'] = "1";
				while ($rlContest = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
					$result['gameList'][] = $rlContest;
				}
			}
		}

		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		$result['isShowInterstitial'] = "0"; // 1 = interstitial, 2 = rewarded

		$this->response($this->json($result), 200);
	}
	//getGamesDetails
	private function FEAR()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$userId = $Details['AWAV3J'];
		$appVersion = $Details['DXTKAT'];
		$deviceName = $Details['CYZGNR'];
		$deviseId = $Details['QAGOM6'];
		$adId = $Details['GYTBVA'];
		$todayOpen = $Details['UQTSXV'];
		$totalOpen = $Details['WTWYPW'];
		$userToken = $Details['4YQSSN'];
		$gameId = $Details['8TO8UB'];

		$strings = array(
			"Mozilla/5.0 (Linux; Android 10; SM-G960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36",
			"",
			"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36",
			"Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-G960U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.0 Chrome/75.0.3770.143 Mobile Safari/537.36",
			"Mozilla/5.0 (iPhone; CPU iPhone OS 13_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.1 Mobile/15E148 Safari/604.1",
			"Mozilla/5.0 (Linux; Android 8.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36",

			"Mozilla/5.0 (iPhone; CPU iPhone OS 12_4_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/113.1.317383162 Mobile/16G183 Safari/604.1",
			"Mozilla/5.0 (iPhone; CPU iPhone OS 10_15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/27.0 Mobile/15E148 Safari/605.1.15",
			"Mozilla/5.0 (Android 10; Mobile; rv:68.0) Gecko/68.0 Firefox/68.0",
			"Mozilla/5.0 (Mozilla/5.0 (Android 10; Mobile; LG-M255; rv:68.0) Gecko/68.0 Firefox/68.0",
			"",
			"Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-G975U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/11.1 Chrome/75.0.3770.143 Mobile Safari/537.36",

			"Mozilla/5.0 (iPhone; CPU iPhone OS 13_1_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.1 Mobile/15E148 Safari/604.1",
			"",
			"Mozilla/5.0 (Linux; Android 9; SM-A205U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.136 Mobile Safari/537.36",

			"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0",

			"Mozilla/5.0 (iPhone; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.25 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",

			""
		);

		shuffle($strings);
		$key = array_rand($strings);

		$setting = mysqli_query($this->db, "SELECT * FROM game_list WHERE id = '" . $gameId . "' ");

		if (mysqli_num_rows($setting) > 0) {
			$result['gameDetails'] = $setting->fetch_assoc();
			// if(rand(10,100) % 2== 0 )
			// {
			// $result['gameDetails']['isIndsAd'] = "1";
			// }
			// else
			// {	
			$result['gameDetails']['isIndsAd'] = "0";
			// }

			$result['homeNote'] = "";

			$result['gameDetails']['userAgent'] = $strings[$key];

			$result['status'] = "1";
			$result['gameDetails']['url'] = sprintf($result['gameDetails']['url'], $userId);
			// $result['homeNote']="<b>Note:</b> If you do any cheating in game play, You withdrawal request will not get accepted.</br></br><b>Hindi Note:</b> आप गेम्स में कोय भी चीटिंग करते हो तो आपका Withdraw Accept नहीं होगा.";
		} else {
			$result['message'] = "No Data Found.";
			$result['status'] = "0";
		}

		$this->response($this->json($result), 200);
	}
	//getChartData
	private function BANDRA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$token = $Details['ZHO6MI'];
		$userId = $Details['PIBW1P'];
		$appVersion = $Details['SAWWLT'];
		$deviceName = $Details['TJIWL1'];
		$deviseId = $Details['QFHHPO'];
		$adId = $Details['53VT4Z'];
		$todayOpen = $Details['CSWM1H'];
		$totalOpen = $Details['DGQNP5'];

		$ipaddress = $this->getIp();
		$date = date('Y-m-d');
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();

		$data = array(
			array('day' => "10 May", 'income' => "120", 'withdraw' => "120"),

			array('day' => "11 May", 'income' => "125", 'withdraw' => "125"),

			array('day' => "12 May", 'income' => "90", 'withdraw' => "80"),

			array('day' => "13 May", 'income' => "87", 'withdraw' => "10"),

			array('day' => "14 May", 'income' => "130", 'withdraw' => "120"),

			array('day' => "15 May", 'income' => "147", 'withdraw' => "147"),

			array('day' => "16 May", 'income' => "300", 'withdraw' => "200"),

		);

		$result['data'] = $data;
		$result['note'] = "Income & withdrawal details of last 7 days"; // income of 7 days
		$result['totalIncome7Day'] = "999"; // income of 7 days
		$result['totalWithdrawal7Day'] = "802"; // withdrawal of 7 days

		$result['totalIncome'] = "1500"; // income of 7 days
		$result['totalWithdrawal'] = "1303"; // withdrawal of 7 days

		$result['adFailUrl'] = "https://sportsgurupro.com";

		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";
		$result['status'] = "1";
		$result['message'] = "success";
		$this->response($this->json($result), 200);
	}
	//getRevealGameData
	private function HARIYANA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['TKIUI6'];
		$totalGameCount = "5";
		$remainGameCount = "10";

		$totalCount = "40";
		$selectionCount = "8";
		///////////////////////////////////////////////////////
		//REVEAL GAME: increase count calculation
		//==========
		//6 (selectionCount) X 5 (data array count) = 30 (totalCount)
		//7 (selectionCount) X 5 (data array count) = 35 (totalCount)
		//8 (selectionCount) X 5 (data array count) = 40 (totalCount)
		//9 (selectionCount) X 5 (data array count) = 45 (totalCount)
		//////////////////////////////////////////////////////

		$points = "10";

		$result['totalGameCount'] = $totalGameCount;
		$result['totalCount'] = $totalCount;
		$result['selectionCount'] = $selectionCount;
		$result['points'] = $points;

		$data = array(
			array('name' => "Coin", 'icon' => "https://cdn-icons-png.flaticon.com/128/1490/1490853.png"),

			array('name' => "Gem", 'icon' => "https://cdn-icons-png.flaticon.com/128/765/765093.png"),

			array('name' => "Gold", 'icon' => "https://cdn-icons-png.flaticon.com/128/5699/5699560.png"),

			array('name' => "Ring", 'icon' => "https://cdn-icons-png.flaticon.com/128/1019/1019141.png"),

			array('name' => "Pearl", 'icon' => "https://cdn-icons-png.flaticon.com/128/458/458622.png")
		);


		$result['data'] = $data;

		if (strlen($userId) > 0) {
			$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM tbl_reveal_game WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
			if ($totalTodayCount < $totalGameCount) {
				$result['status'] = "1";
				$result['message'] = "Data found successfully";
			} else {
				$result['message'] = "You have exhausted today's reveal game limit, please try again tomorrow.";
				$result['status'] = "2";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}

		$result['remainGameCount'] = $totalGameCount - $totalTodayCount;

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock Reaveal Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "31";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Reaveal Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line


		$this->response($this->json($result), 200);
	}
	//saveRevealGame
	private function SLOKA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['Q146BG'];

		$userToken = $Details['VTG3OO'];
		$adId = $Details['NQZSST'];
		$deviceName = $Details['VU3TOS'];

		$totalGameCount = "5";
		$remainGameCount = "10";

		$totalCount = "40";
		$selectionCount = "8";
		///////////////////////////////////////////////////////
		//REVEAL GAME: increase count calculation
		//==========
		//6 (selectionCount) X 5 (data array count) = 30 (totalCount)
		//7 (selectionCount) X 5 (data array count) = 35 (totalCount)
		//8 (selectionCount) X 5 (data array count) = 40 (totalCount)
		//9 (selectionCount) X 5 (data array count) = 45 (totalCount)
		//////////////////////////////////////////////////////

		$points = "10";
		$winningPoints = $Details['4SNEM2'];
		$result['totalGameCount'] = $totalGameCount;
		$result['totalCount'] = $totalCount;
		$result['selectionCount'] = $selectionCount;
		$result['points'] = $points;

		$data = array(
			array('name' => "Coins", 'icon' => "https://cdn-icons-png.flaticon.com/128/1490/1490853.png"),

			array('name' => "Diamond", 'icon' => "https://cdn-icons-png.flaticon.com/128/765/765093.png"),

			array('name' => "Gold", 'icon' => "https://cdn-icons-png.flaticon.com/128/5699/5699560.png"),

			array('name' => "Ring", 'icon' => "https://cdn-icons-png.flaticon.com/128/1019/1019141.png"),

			array('name' => "Pearl", 'icon' => "https://cdn-icons-png.flaticon.com/128/458/458622.png")
		);

		$result['data'] = $data;


		$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayTask = mysqli_num_rows($sql1);
		if ($totalTodayTask > 0) {
			if (strlen($userToken) > 0) {
				if (strlen($userId) > 0 && (int)$userId > 0) {
					if ($winningPoints == '0' || $winningPoints == $points) {
						$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM tbl_reveal_game WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
						$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
						if ($totalTodayCount < $totalGameCount) {
							$sqlRederID = mysqli_query($this->db, "SELECT revealGameEarningPoint,earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
							if ($sqlRederID->num_rows > 0) {
								$rowewf = $sqlRederID->fetch_assoc();
								$earning_point = $rowewf['earningPoint'];
								$revealGameEarningPoint = $rowewf['revealGameEarningPoint'];
								$token = $rowewf['token'];
								$adId2 = $rowewf['adId'];
								$userToken2 = $rowewf['userToken'];

								if ($userToken == $userToken2) {
									$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_reveal_game(userId, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
									if ($sqinsert === TRUE) {
										if ((int)$winningPoints > 0) {
											$finalRevealGameEarningPoint = (int)$revealGameEarningPoint + (int)$winningPoints;
											$finalearning_point = (int)$earning_point + (int)$winningPoints;

											$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '26', '1','" . $finalearning_point . "','Reveal Game')");


											$tid = $this->gen_uuid();
											$result['userDetails']['userToken'] = $tid;
											$result['userToken'] = $tid;

											$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' ,userToken = '" . $tid . "', revealGameEarningPoint='" . $finalRevealGameEarningPoint . "' WHERE userId = '" . $userId . "'");
											if ($sqlwalletupdate === TRUE) {
												$result['winningPoints'] = $winningPoints;
												$result['earningPoint'] = $finalearning_point;
												$result['message'] = "Data Found Sucessfully.";
												$result['status'] = "1";
											} else {
												$result['message'] = "Something went wrong.";
												$result['status'] = "0";
											}
										} else {
											$result['winningPoints'] = $winningPoints;
											$result['earningPoint'] = $earning_point;
											$result['message'] = "Data Found Sucessfully.";
											$result['status'] = "1";
										}
									} else {
										$result['message'] = "Something went wrong.";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong. Login Again";
									$result['status'] = "5";
								}
							} else {
								$result['message'] = "Something went wrong, please try again later.";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "You have exhausted today's Reveal Game limit, please try again tomorrow.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "Something went wrong, please try again later.1";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "You have not logged in. Please login";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "Something went wrong.";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Complete task to access reveal game.";
			$result['status'] = "0";
		}
		$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM tbl_reveal_game WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
		$result['remainGameCount'] = $totalGameCount - $totalTodayCount;
		$result['nextGameTimer'] =  "30"; //seconds
		// $result['helpVideoUrl'] = $Youtube_url;
		$this->response($this->json($result), 200);
	}
	//getWatchWebsiteData
	private function ALIYA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d H:i:s");
		$userId = $Details['G5KLW2'];

		$sqlstring = "SELECT t1.id,t1.title,t1.description,t1.url,t1.icon,t1.points,t1.watchTime,t1.nextLinkVisitTimer,t1.colorCode,t1.isActive, (SELECT COUNT(id) FROM tbl_watch_website_points_history WHERE userId = '" . $userId . "' AND websiteId = t1.id AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'),(SELECT entryDate FROM tbl_watch_website_points_history WHERE userId = '" . $userId . "' AND websiteId = t1.id AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "') FROM tbl_watch_website as t1";

		$watchWebsiteData = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($watchWebsiteData) > 0) {
			while ($rlt = mysqli_fetch_array($watchWebsiteData, MYSQLI_NUM)) {
				$watchedDate = $rlt[11];
				if (strlen($watchedDate) == 0) {
					$watchedDate = NULL;
				}
				$result['websiteList'][] = array('id' => $rlt[0], 'title' => $rlt[1], 'description' => $rlt[2], 'url' => $rlt[3], 'icon' => $rlt[4], 'points' => $rlt[5], 'watchTime' => $rlt[6], 'nextLinkVisitTimer' => $rlt[7], 'colorCode' => $rlt[8], 'isActive' => $rlt[9], 'isWatched' => $rlt[10], 'websiteWatchedDate' => $watchedDate);
			}
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
		} else {
			$result['message'] = "No Data Found";
			$result['status'] = "2";
		}

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Reaveal Game.";
				$result['taskButton'] = "Complete Easy Task Now";
				//$result['taskId'] = "1";
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1";
		$result['todayDate'] = date("Y-m-d H:i:s");

		$this->response($this->json($result), 200);
	}
	//saveWatchWebsite
	private function DUMAS()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['ZDSDUR'];
		$websiteId = $Details['QRC2DS'];
		$userToken = $Details['F7ZWI7'];
		$adId = $Details['AR2WGQ'];
		$deviceName = $Details['2DBW65'];
		$winningPoints = $Details['K8YSTS'];

		if (strlen($userToken) > 0) {
			if (strlen($userId) > 0 && (int)$userId > 0) {
				$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
				$totalTodayTask = mysqli_num_rows($sql1);

				if ($totalTodayTask > 0) {

					$isWatchedToday = mysqli_query($this->db, "SELECT * FROM tbl_watch_website_points_history WHERE websiteId = '" . $websiteId . "' AND userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'");
					if (mysqli_num_rows($isWatchedToday) == 0) {
						$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
						if ($sqlRederID->num_rows > 0) {
							$rowewf = $sqlRederID->fetch_assoc();
							$earning_point = $rowewf['earningPoint'];
							$adId2 = $rowewf['adId'];
							$userToken2 = $rowewf['userToken'];

							if ($userToken == $userToken2) {
								$watchPoints = 0;
								$watchWebsiteData = mysqli_query($this->db, "SELECT * FROM tbl_watch_website WHERE id = '" . $websiteId . "' AND isActive ='1'");
								if (mysqli_num_rows($watchWebsiteData) > 0) {
									$rowewf = $watchWebsiteData->fetch_assoc();
									$watchPoints = $rowewf['points'];
									if ((int)$winningPoints == (int)$watchPoints) {
										$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_watch_website_points_history(websiteId,userId, points, adId, deviceName, ipAddress) VALUES ('" . $websiteId . "','" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
										if ($sqinsert === TRUE) {
											$finalearning_point = (int)$earning_point + (int)$winningPoints;
											$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '27', '1','" . $finalearning_point . "','Watch Website')");

											$tid = $this->gen_uuid();
											$result['userDetails']['userToken'] = $tid;
											$result['userToken'] = $tid;

											$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint= '" . $finalearning_point . "' ,userToken = '" . $tid . "'  WHERE userId = '" . $userId . "'");
											if ($sqlwalletupdate === TRUE) {
												$lastDayquerry = mysqli_query($this->db, "SELECT * FROM tbl_watch_website_points_history WHERE userId = '" . $userId . "' AND websiteId = '" . $websiteId . "' ORDER BY id DESC limit 1");
												$day = mysqli_fetch_array($lastDayquerry, MYSQLI_ASSOC);
												$entrydate1 = $day['entryDate'];
												$result['lastWebsiteWatchedDate'] = $entrydate1;
												$result['winningPoints'] = $winningPoints;
												$result['earningPoint'] = $finalearning_point;
												$result['message'] = "Data Found Sucessfully.";
												$result['status'] = "1";
											} else {
												$result['message'] = "Something went wrong1.";
												$result['status'] = "0";
											}
										} else {
											$result['message'] = "Something went wrong2.";
											$result['status'] = "0";
										}
									} else {
										$result['message'] = "Something went wrong3.";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong4";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "Something went wrong. Login Again";
								$result['status'] = "5";
							}
						} else {
							$result['message'] = "Something went wrong, please try again later.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "Something went wrong, please try again later.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "You have not completed today's Task & Game";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}
		// $result['helpVideoUrl'] = $Youtube_url;
		$result['todayDate'] = date("Y-m-d H:i:s");
		$this->response($this->json($result), 200);
	}
	//getNumberPuzzleData
	private function RANGILU()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d H:i:s");
		$userId = $Details['JGXD94'];
		$dailyLimitCount = 5;
		$timer = 4;
		$points = 40;

		$sqlstring = "SELECT id FROM tbl_number_puzzle_points_history WHERE userId = '" . $userId . "' AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'";

		$completedGameCount = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($completedGameCount) < $dailyLimitCount) {
			$result['dailyLimitCount'] = $dailyLimitCount;
			$result['timer'] = $timer; // in minutes
			$result['points'] = $points;

			$result['message'] = "Data Found";
			$result['status'] = "1";
		} else {
			$result['message'] = "You have exhausted daily limit of " . $dailyLimitCount . " Number Puzzle games, play again tomorrow.";
			$result['status'] = "0";
		}

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Game.";
				$result['taskButton'] = "Complete Easy Task Now";
				//$result['taskId'] = "1";
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}

		// $result['isTodayTaskCompleted'] = "1";

		$this->response($this->json($result), 200);
	}
	//saveNumberPuzzle
	private function JAGRAN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['L4F5UI'];
		$userToken = $Details['069DQQ'];
		$adId = $Details['YTHUDI'];
		$deviceName = $Details['GK259Z'];
		$winningPoints = $Details['GBEY8Q'];
		$dailyLimitCount = 5;
		$points = 40;



		$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayTask = mysqli_num_rows($sql1);


		if (strlen($userToken) > 0 && $totalTodayTask > 0) {
			if (strlen($userId) > 0 && (int)$userId > 0) {
				$todayPlayedCount = mysqli_query($this->db, "SELECT * FROM tbl_number_puzzle_points_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'");
				if (mysqli_num_rows($todayPlayedCount) < $dailyLimitCount) {
					if ((int)$winningPoints == $points) {
						$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,adId,isActive,userToken,deviceName FROM user_master WHERE userId = '" . $userId . "' ");
						if ($sqlRederID->num_rows > 0) {
							$rowewf = $sqlRederID->fetch_assoc();
							$earning_point = $rowewf['earningPoint'];
							$adId2 = $rowewf['adId'];
							$deviceName2 = $rowewf['deviceName'];
							$userToken2 = $rowewf['userToken'];

							if ($userToken == $userToken2 && $deviceName == $deviceName2) {
								$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_number_puzzle_points_history(userId, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
								if ($sqinsert === TRUE) {
									$finalearning_point = (int)$earning_point + (int)$winningPoints;
									$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '28', '1','" . $finalearning_point . "','Number Puzzle')");


									$tid = $this->gen_uuid();
									$result['userDetails']['userToken'] = $tid;
									$result['userToken'] = $tid;

									$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' ,userToken = '" . $tid . "' WHERE userId = '" . $userId . "'");
									if ($sqlwalletupdate === TRUE) {
										$result['winningPoints'] = $winningPoints;
										$result['earningPoint'] = $finalearning_point;
										$dataCount = mysqli_query($this->db, "SELECT * FROM tbl_number_puzzle_points_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'");
										$result['gameCompleteCount'] = mysqli_num_rows($dataCount);
										$result['dailyLimitCount'] = $dailyLimitCount;
										$result['message'] = "Data Found Sucessfully.";
										$result['status'] = "1";
									} else {
										$result['message'] = "Something went wrong1.";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong2.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "Something went wrong. Login Again";
								$result['status'] = "5";
							}
						} else {
							$result['message'] = "Something went wrong, please try again later.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "Something went wrong, please try again later.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "You have exhausted daily limit of " . $dailyLimitCount . " Number Puzzle games, play again tomorrow.";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}
		// $result['helpVideoUrl'] = $Youtube_url;
		$this->response($this->json($result), 200);
	}
	//getFlipCardCalculateNumbersData
	private function SHOPPING()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['C63LWH'];

		$selectionCount = "3";

		$data = array(
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(-3, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(-2, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(0, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(-3, 8)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(1, 18)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(1, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(-5, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(5, 25)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(4, 8)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(1, 5)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(5, 11)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(1, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(2, 5)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(3, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(-2, 15)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(-1, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(1, 14)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(1, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(1, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(2, 17)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(0, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(0, 10)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(6, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(1, 5)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(1, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(1, 10)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(1, 5)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "1", 'points' => rand(2, 22)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "2", 'points' => rand(1, 20)),
			array('icon' => "https://cdn-icons-png.flaticon.com/128/6453/6453565.png", 'adType' => "0", 'points' => rand(4, 10))
		);

		shuffle($data);
		$result['data'] = $data;
		$totalCount = count($data);
		$result['totalCount'] = $totalCount;
		$result['selectionCount'] = $selectionCount;

		if (strlen($userId) > 0) {
			$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM tbl_flip_card_calculate_numbers_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
			if ($totalTodayCount == 0) {
				$result['status'] = "1";
				$result['message'] = "Data found successfully";
			} else {
				$result['message'] = "You have already played flip card game today.";
				$result['status'] = "2";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}


		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock Flip Cards Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "31";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Flip Cards Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		// $result['helpVideoUrl'] = $Youtube_url;

		$this->response($this->json($result), 200);
	}
	//saveFlipCardCalculateNumbers
	private function KALUPUR()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['GYUIS8'];
		$userToken = $Details['9GY6LC'];
		$adId = $Details['NPFM7T'];
		$deviceName = $Details['40ZGS4'];
		$winningPoints = $Details['XS2UZX'];

		$agent = $_SERVER['HTTP_USER_AGENT'];

		$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayTask = mysqli_num_rows($sql1);

		if (strlen($userToken) > 0 &&  (int)$totalTodayTask  > 0 && $agent == "okhttp/5.0.0-alpha.2" && (int)$winningPoints < 100) {
			if (strlen($userId) > 0 && (int)$userId > 0) {
				$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM tbl_flip_card_calculate_numbers_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
				$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
				if ($totalTodayCount == 0) {
					$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
					if ($sqlRederID->num_rows > 0) {
						$rowewf = $sqlRederID->fetch_assoc();
						$earning_point = $rowewf['earningPoint'];
						$token = $rowewf['token'];
						$adId2 = $rowewf['adId'];
						$userToken2 = $rowewf['userToken'];

						if ($userToken == $userToken2) {
							$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_flip_card_calculate_numbers_history(userId, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
							if ($sqinsert === TRUE) {
								if ((int)$winningPoints > 0) {
									$finalearning_point = (int)$earning_point + (int)$winningPoints;

									$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '29', '1','" . $finalearning_point . "','Flip Cards')");


									$tid = $this->gen_uuid();
									$result['userDetails']['userToken'] = $tid;
									$result['userToken'] = $tid;

									$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' ,userToken = '" . $tid . "'   WHERE userId = '" . $userId . "'");
									if ($sqlwalletupdate === TRUE) {
										$result['winningPoints'] = $winningPoints;
										$result['earningPoint'] = $finalearning_point;
										$result['message'] = "Data Found Sucessfully.";
										$result['status'] = "1";
									} else {
										$result['message'] = "Something went wrong.";
										$result['status'] = "0";
									}
								} else {
									$result['winningPoints'] = $winningPoints;
									$result['earningPoint'] = $earning_point;
									$result['message'] = "Data Found Sucessfully.";
									$result['status'] = "1";
								}
							} else {
								$result['message'] = "Something went wrong.";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "Something went wrong. Login Again";
							$result['status'] = "5";
						}
					} else {
						$result['message'] = "Something went wrong, please try again later.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "You have already played flip card game today.";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		}

		// $result['helpVideoUrl'] = $Youtube_url;
		$this->response($this->json($result), 200);
	}

	private function generateRandomString($length)
	{
		$characters = '0123456789/*-+;:()!@#$%^<>?/.,\=_()[]{}&|abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[random_int(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	//getTextTypingData
	private function WANISH()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$userId = $Details['HSHCWU'];
		$userToken = $Details['7GHPF3'];
		$adId = $Details['BIKKW9'];
		$deviceName = $Details['V94W2G'];
		$totalCount = "5";

		///////////////////// USE RANDOM DATA ////////////////////////
		$text = $this->generateRandomString(30);
		$points = "10";
		$timer = "60"; // seconds
		//////////////////////////////////////////////////////////

		if (strlen($userId) > 0) {
			$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM tbl_text_typing_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' AND isAttempted = '1'");
			$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
			if ($totalTodayCount < $totalCount) {
				$sqlLastData = mysqli_query($this->db, "SELECT * FROM tbl_text_typing_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ORDER BY id DESC LIMIT 1");
				$lastData = mysqli_num_rows($sqlLastData);
				$rowewf = $sqlLastData->fetch_assoc();
				if ($lastData == 0 || $rowewf['isAttempted'] == '1') {
					// insert
					$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_text_typing_history(userId, text, timer, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $text . "','" . $timer . "','" . $points . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
				} else {
					// update
					$sqlupdate = mysqli_query($this->db, "UPDATE tbl_text_typing_history SET text='" . $text . "', timer='" . $timer . "', points='" . $points . "' WHERE id = '" . $rowewf['id'] . "'");
				}

				$result['status'] = "1";
				$result['message'] = "Data found successfully";
			} else {
				$result['message'] = "You have exhausted today's text typing game limit, please try again tomorrow.";
				$result['status'] = "2";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}

		$sqlLastData = mysqli_query($this->db, "SELECT * FROM tbl_text_typing_history WHERE userId = '" . $userId . "' ORDER BY id DESC LIMIT 1");
		$result['data'] = $sqlLastData->fetch_assoc();
		$result['remainCount'] = $totalCount - $totalTodayCount;
		$result['totalCount'] = $totalCount;

		$result['mainTimer'] = '1'; // timer in minutes
		$result['lifeline'] = '2'; // lifeline for typing attempts, on 3rd attempt, api will get called

		$lastDate = mysqli_query($this->db, "SELECT updateDate FROM tbl_text_typing_history WHERE userId = '" . $userId . "' AND isAttempted='1' ORDER BY id DESC limit 1");
		$lastDateNum = mysqli_num_rows($lastDate);
		if ($lastDateNum > 0) {
			$resapi = $lastDate->fetch_assoc();
			$result['lastDate'] = $resapi['updateDate'];
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		$result['todayDate'] = date('Y-m-d H:i:s');

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock Text Typing Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "31";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Text Typing Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		// $result['helpVideoUrl'] = $Youtube_url;

		$this->response($this->json($result), 200);
	}
	//saveTextTyping
	private function SUPER()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['E3DOON'];
		$userToken = $Details['3DWZ8H'];
		$adId = $Details['1WQTIO'];
		$deviceName = $Details['WAC2F9'];
		$textTypingId = $Details['WS0WHW'];
		$totalCount = "5";
		$winningPoints = $Details['RE8VP7'];
		$winningPoints = "10";
		$text = $Details['V2WT9O'];
		$agent = $_SERVER['HTTP_USER_AGENT'];

		$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayTask = mysqli_num_rows($sql1);
		// if (strlen($userToken) > 0 && $totalTodayTask > 0 && $agent == "okhttp/5.0.0-alpha.2") {
		if (strlen($userToken) > 0 && $totalTodayTask > 0 && $agent == "okhttp/5.0.0-alpha.2") {
			if (strlen($userId) > 0 && (int)$userId > 0) {
				$datetime = date("Y-m-d H:i:s");
				$timestamp = strtotime($datetime);
				$time = $timestamp - (75);
				$datetime1 = date("Y-m-d H:i:s", $time);

				$scratchCardList1 = mysqli_query($this->db, "SELECT id FROM tbl_text_typing_history WHERE userId = '" . $userId . "' AND entryDate > '" . $datetime1 . "'  ");

				if (mysqli_num_rows($scratchCardList1) > 0) {
					$result['message'] = "Something Went Wrong, Try Again After Sometime";
					$result['status'] = "0";
				} else {

					$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM tbl_text_typing_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
					$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
					if ($totalTodayCount < $totalCount) {
						$sqlData = mysqli_query($this->db, "SELECT * FROM tbl_text_typing_history WHERE id = '" . $textTypingId . "' ORDER BY id DESC LIMIT 1");
						$row = $sqlData->fetch_assoc();
						if ($row['text'] === $text) {
						} else {
							$winningPoints = "0";
						}
						if ($row['points'] == $winningPoints || $winningPoints == "0") {
							$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
							if ($sqlRederID->num_rows > 0) {
								$rowewf = $sqlRederID->fetch_assoc();
								$earning_point = $rowewf['earningPoint'];
								$token = $rowewf['token'];
								$adId2 = $rowewf['adId'];
								$userToken2 = $rowewf['userToken'];

								if ($userToken == $userToken2) {
									$sqlupdate = mysqli_query($this->db, "UPDATE tbl_text_typing_history SET isAttempted='1', winningPoints='" . $winningPoints . "' WHERE id = '" . $textTypingId . "'");
									if ($sqlupdate === TRUE) {
										if ((int)$winningPoints > 0) {
											$finalearning_point = (int)$earning_point + (int)$winningPoints;

											$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '30', '1','" . $finalearning_point . "','Text Typing')");
											$tid = $this->gen_uuid();
											$result['userDetails']['userToken'] = $tid;
											$result['userToken'] = $tid;

											$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken = '" . $tid . "'  WHERE userId = '" . $userId . "'");
											if ($sqlwalletupdate === TRUE) {
												$result['winningPoints'] = $winningPoints;
												$result['earningPoint'] = $finalearning_point;
												$result['message'] = "Data Found Sucessfully.";
												$result['status'] = "1";
											} else {
												$result['message'] = "Something went wrong.";
												$result['status'] = "0";
											}
										} else {
											$result['winningPoints'] = $winningPoints;
											$result['earningPoint'] = $earning_point;
											$result['message'] = "Data Found Sucessfully.";
											$result['status'] = "1";
										}
									} else {
										$result['message'] = "Something went wrong.";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong. Login Again";
									$result['status'] = "5";
								}
							} else {
								$result['message'] = "Something went wrong, please try again later.";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "Something went wrong, please try again later.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "You have exhausted today's text typing game limit, please try again tomorrow.";
						$result['status'] = "2";
					}
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later.";
			$result['status'] = "0";
		}
		$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM tbl_text_typing_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' AND isAttempted = '1'");
		$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
		$result['remainCount'] = $totalCount - $totalTodayCount;
		$result['totalCount'] = $totalCount;
		if ($result['status'] == '1') {
			///////////////////// USE RANDOM DATA ////////////////////////
			$text = $this->generateRandomString(30);
			$points = "20";
			$timer = "60"; // seconds
			//////////////////////////////////////////////////////////
			$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_text_typing_history(userId, text, timer, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $text . "','" . $timer . "','" . $points . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");

			$sqlLastData = mysqli_query($this->db, "SELECT * FROM tbl_text_typing_history WHERE userId = '" . $userId . "' ORDER BY id DESC LIMIT 1");
			$result['data'] = $sqlLastData->fetch_assoc();
		}

		$lastDate = mysqli_query($this->db, "SELECT updateDate FROM tbl_text_typing_history WHERE userId = '" . $userId . "' AND isAttempted='1' ORDER BY id DESC limit 1");
		$lastDateNum = mysqli_num_rows($lastDate);
		if ($lastDateNum > 0) {
			$resapi = $lastDate->fetch_assoc();
			$result['lastDate'] = $resapi['updateDate'];
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		$result['todayDate'] = date('Y-m-d H:i:s');

		// $result['helpVideoUrl'] = $Youtube_url;
		$this->response($this->json($result), 200);
	}


	//getMilestonesData
	private function DOOPER()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d H:i:s");
		$userId = $Details['JGUD6H'];

		$imploded = "0";
		$sqlCampId = mysqli_query($this->db, "SELECT milestoneId FROM tbl_milestone_history WHERE userId = '" . $userId . "' GROUP BY milestoneId");
		// $result['QRY1'] = "SELECT milestoneId FROM tbl_milestone_history WHERE userId = '" . $userId . "' GROUP BY milestoneId";
		$NumRowsId = mysqli_num_rows($sqlCampId);
		if ($NumRowsId > 0) {
			while ($row =  mysqli_fetch_array($sqlCampId, MYSQLI_ASSOC)) {
				$rows[] = $row['milestoneId'];
			}
			$imploded = implode(',', $rows);
		}

		$sqlstring = "SELECT * FROM tbl_milestones WHERE id NOT IN  (" . $imploded . ")  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ORDER BY id DESC";
		// $result['QRY'] = $sqlstring;

		$milestonesData = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($milestonesData) > 0) {
			while ($rlt = mysqli_fetch_array($milestonesData, MYSQLI_ASSOC)) {
				$type = $rlt['type'];
				$earningType = $rlt['earningType'];
				$completionPercent = 0;
				if ($earningType == '11') // 11 = tasks
				{
					$taskQry = "SELECT count(id),sum(points) FROM cpalead WHERE userId = '" . $userId . "'  AND  entryDate > '" . $rlt['startDate'] . "' AND entryDate < '" . $rlt['endDate'] . "'";
					$taskData = mysqli_query($this->db, $taskQry);
				} elseif ($earningType == '13') // 13 = refer users
				{
					$taskQry = "SELECT count(id),sum(points) FROM earning_point_master WHERE userId = '" . $userId . "' AND earning_type = '13'  AND  entryDate > '" . $rlt['startDate'] . "' AND entryDate < '" . $rlt['endDate'] . "'";
					$taskData = mysqli_query($this->db, $taskQry);
				} elseif ($earningType == '24') // 24 = playtime adjoe (ONLY POINTS)
				{
					$taskQry = "SELECT count(id),sum(coin_amount) FROM adjoe_history WHERE userId = '" . $userId . "'  AND  entryDate > '" . $rlt['startDate'] . "' AND entryDate < '" . $rlt['endDate'] . "'";
					$taskData = mysqli_query($this->db, $taskQry);
				}
				// $rlt['QUERY'] = $taskQry;
				$taskCusor = mysqli_fetch_array($taskData, MYSQLI_NUM);
				$noOfData = $taskCusor[0];
				$earnedPoints = $taskCusor[1];
				if ($noOfData > 0) {
					if ($type == '0') // 0 = number target
					{
						$completionPercent = ($noOfData * 100) / $rlt['targetNumber'];
					} else { //1 = points target
						$completionPercent = ($earnedPoints * 100) / $rlt['targetPoints'];
					}
				}
				if ($completionPercent > 100) {
					$completionPercent = 100;
				}
				if (strlen($userId) == 0 || (int)$userId == 0) {
					$noOfData = "0";
					$earnedPoints = "0";
					$completionPercent = "0";
				}
				$rlt['NoOfCompleted'] = $noOfData;
				if ($earnedPoints == NULL) {
					$rlt['earnedPoints'] = "0";
				} else {
					$rlt['earnedPoints'] = $earnedPoints;
				}

				$rlt['completionPercent'] = $completionPercent;
				$rlt['todayDate'] = date("Y-m-d H:i:s");
				$result['milestoneData'][] = $rlt;
			}
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
		} else {
			$result['message'] = "This milestone is expired or it is inactive";
			$result['status'] = "2";
		}

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}

	//getSingleMilestoneData
	private function FLOP()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d H:i:s");
		$userId = $Details['2QNOJX'];
		$milestoneId = $Details['W3RNW9'];

		$sqlstring = "SELECT * FROM tbl_milestones WHERE id = '" . $milestoneId . "'  AND  startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1' ORDER BY id DESC";
		// $result['QRY'] = $sqlstring;

		$milestonesData = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($milestonesData) > 0) {
			while ($rlt = mysqli_fetch_array($milestonesData, MYSQLI_ASSOC)) {
				$type = $rlt['type'];
				$earningType = $rlt['earningType'];
				$completionPercent = 0;
				if ($earningType == '11') // 11 = tasks
				{
					$taskQry = "SELECT count(id),sum(points) FROM cpalead WHERE userId = '" . $userId . "'  AND  entryDate > '" . $rlt['startDate'] . "' AND entryDate < '" . $rlt['endDate'] . "'";
					$taskData = mysqli_query($this->db, $taskQry);
				} elseif ($earningType == '13') // 13 = refer users
				{
					$taskQry = "SELECT count(id),sum(points) FROM earning_point_master WHERE userId = '" . $userId . "' AND earning_type = '13'  AND  entryDate > '" . $rlt['startDate'] . "' AND entryDate < '" . $rlt['endDate'] . "'";
					$taskData = mysqli_query($this->db, $taskQry);
				} elseif ($earningType == '24') // 24 = playtime adjoe (ONLY POINTS)
				{
					$taskQry = "SELECT count(id),sum(coin_amount) FROM adjoe_history WHERE userId = '" . $userId . "'  AND  entryDate > '" . $rlt['startDate'] . "' AND entryDate < '" . $rlt['endDate'] . "'";
					$taskData = mysqli_query($this->db, $taskQry);
				}
				$taskCusor = mysqli_fetch_array($taskData, MYSQLI_NUM);
				$noOfData = $taskCusor[0];
				$earnedPoints = $taskCusor[1];
				if ($noOfData > 0) {
					if ($type == '0') // 0 = number target
					{
						$completionPercent = ($noOfData * 100) / $rlt['targetNumber'];
					} else { //1 = points target
						$completionPercent = ($earnedPoints * 100) / $rlt['targetPoints'];
					}
				}
				if ($completionPercent > 100) {
					$completionPercent = 100;
				}
				if (strlen($userId) == 0 || (int)$userId == 0) {
					$noOfData = "0";
					$earnedPoints = "0";
					$completionPercent = "0";
				}
				$rlt['NoOfCompleted'] = $noOfData;
				if ($earnedPoints == NULL) {
					$rlt['earnedPoints'] = "0";
				} else {
					$rlt['earnedPoints'] = $earnedPoints;
				}

				$rlt['completionPercent'] = $completionPercent;
				$rlt['todayDate'] = date("Y-m-d H:i:s");
				$result['singleMilestoneData'] = $rlt;
			}
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
		} else {
			$result['message'] = "This milestone is expired or it is inactive";
			$result['status'] = "2";
		}

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";
		$result['isShowInterstitial'] = "1"; // 1 = interstitial, 2 = rewarded

		$this->response($this->json($result), 200);
	}
	//saveMilestone
	private function GINGER()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['HW93NL'];
		$milestoneId = $Details['WM8DGX'];
		$adId = $Details['07WN85'];
		$deviceId = $Details['WVG120'];
		$deviceName = $Details['QXWC0H'];
		$winningPoints = $Details['EDWYXL'];

		// $sql1= mysqli_query($this->db,"SELECT id FROM earning_point_master WHERE userId = '".$userId."'  AND earning_type IN('2','17','23')");
		//    if ($sql1->num_rows > 0) 
		//     {
		if (strlen($userId) > 0 && (int)$userId > 0) {
			$isClaimed = mysqli_query($this->db, "SELECT * FROM tbl_milestone_history WHERE milestoneId = '" . $milestoneId . "' AND userId = '" . $userId . "'");
			if (mysqli_num_rows($isClaimed) == 0) {
				$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,adId,isActive FROM user_master WHERE userId = '" . $userId . "' ");
				if ($sqlRederID->num_rows > 0) {
					$rowewf = $sqlRederID->fetch_assoc();
					$earning_point = $rowewf['earningPoint'];
					$adId2 = $rowewf['adId'];

					$milestonePoints = 0;
					$milestoneData = mysqli_query($this->db, "SELECT * FROM tbl_milestones WHERE id = '" . $milestoneId . "' AND startDate < '" . $date . "' AND endDate > '" . $date . "' AND isActive = '1'");
					if (mysqli_num_rows($milestoneData) > 0) {
						$rlt = $milestoneData->fetch_assoc();
						$milestonePoints = $rlt['points'];
						if ((int)$winningPoints == (int)$milestonePoints) {

							$type = $rlt['type'];
							$earningType = $rlt['earningType'];
							$completionPercent = 0;
							if ($earningType == '11') // 11 = tasks
							{
								$taskQry = "SELECT count(id),sum(points) FROM cpalead WHERE userId = '" . $userId . "'  AND  entryDate > '" . $rlt['startDate'] . "' AND entryDate < '" . $rlt['endDate'] . "'";
								$taskData = mysqli_query($this->db, $taskQry);
							} elseif ($earningType == '13') // 13 = refer users
							{
								$taskQry = "SELECT count(id),sum(points) FROM earning_point_master WHERE userId = '" . $userId . "' AND earning_type = '13'  AND  entryDate > '" . $rlt['startDate'] . "' AND entryDate < '" . $rlt['endDate'] . "'";
								$taskData = mysqli_query($this->db, $taskQry);
							} elseif ($earningType == '24') // 24 = playtime adjoe (ONLY POINTS)
							{
								$taskQry = "SELECT count(id),sum(coin_amount) FROM adjoe_history WHERE userId = '" . $userId . "'  AND  entryDate > '" . $rlt['startDate'] . "' AND entryDate < '" . $rlt['endDate'] . "'";
								$taskData = mysqli_query($this->db, $taskQry);
							}
							$taskCusor = mysqli_fetch_array($taskData, MYSQLI_NUM);
							$noOfData = $taskCusor[0];
							$earnedPoints = $taskCusor[1];
							if ($noOfData > 0) {
								if ($type == '0') // 0 = number target
								{
									$completionPercent = ($noOfData * 100) / $rlt['targetNumber'];
								} else { //1 = points target
									$completionPercent = ($earnedPoints * 100) / $rlt['targetPoints'];
								}
							}
							if ($completionPercent >= 100) {
								$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_milestone_history(milestoneId,userId, points, adId, deviceName, ipAddress, deviceId) VALUES ('" . $milestoneId . "','" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' , '" . $deviceId . "')");
								if ($sqinsert === TRUE) {
									$finalearning_point = (int)$earning_point + (int)$winningPoints;

									$tid = $this->gen_uuid();
									$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '31', '1','" . $finalearning_point . "','Milestones')");

									$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");

									if ($sqlwalletupdate === TRUE) {
										$result['winningPoints'] = $winningPoints;
										$result['earningPoint'] = $finalearning_point;
										$result['message'] = "Data Found Sucessfully.";
										$result['status'] = "1";
										$result['userToken'] = $tid;
									} else {
										$result['message'] = "Something went wrong1.";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong2.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "Something went wrong3.";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "Something went wrong3.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "This milestone is expired or it is inactive. Please try to complete other milestones.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Something went wrong, please try again later.";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have already claimed reward for this milestone.";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}
		//  } else {
		//     $result['message'] = "Complete task, or scratch card or refer any user to complete milestone";
		//     $result['status'] = "0";
		// }         
		// $result['helpVideoUrl'] = $Youtube_url;

		$this->response($this->json($result), 200);
	}


	//getLevelEarningData
	private function MEGHANI()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d H:i:s");
		$userId = $Details['PERKS'];


		$lastClaimDate = date("2023-10-30 00:00:00");
		$lastEarningId = 0;
		$sqlClaimDate = mysqli_query($this->db, "SELECT entryDate,levelEarningId FROM tbl_level_earning_history WHERE userId = '" . $userId . "' ORDER BY id DESC LIMIT 1");
		if (mysqli_num_rows($sqlClaimDate) > 0) {
			while ($row =  mysqli_fetch_array($sqlClaimDate, MYSQLI_ASSOC)) {
				$lastClaimDate = $row['entryDate'];
				$lastDate = $row['entryDate'];
				$lastEarningId = $row['levelEarningId'];
			}
		}


		$sqlstring = "SELECT * FROM tbl_level_earning WHERE isActive = '1' ORDER BY id";

		$levelEarningData = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($levelEarningData) > 0) {
			while ($rlt = mysqli_fetch_array($levelEarningData, MYSQLI_ASSOC)) {
				$isLevelAchievedData = mysqli_query($this->db, "SELECT id FROM tbl_level_earning_history WHERE levelEarningId = '" . $rlt['id'] . "' AND userId = '" . $userId . "'");
				if (mysqli_num_rows($isLevelAchievedData) > 0) { // Claimed
					$rlt['isLevelPointsClaimed'] = "1";
					$lastClaimDate = date("2023-10-30 00:00:00");
				} else if ($rlt['id'] == ($lastEarningId + 1)) { // Active
					$rlt['isLevelPointsClaimed'] = "0";
					$lastClaimDate = $lastDate;
				} else { // Locked
					$rlt['isLevelPointsClaimed'] = "0";
					$lastClaimDate =  date("Y-m-d H:i:s");
				}
				//////////TASK///////////////
				$completionPercent = 0;
				$totalItems = 0;

				if ($rlt['taskCount'] != 0 && strlen($userId) > 0 && (int)$userId > 0) // 11 = tasks
				{
					$totalItems = $totalItems + 100;
					$taskQry = "SELECT count(id),sum(points) FROM cpalead WHERE userId = '" . $userId . "'  AND  entryDate > '" . $lastClaimDate . "'";
					// $rlt['QRY'] = $taskQry;
					$taskData = mysqli_query($this->db, $taskQry);
					$taskCusor = mysqli_fetch_array($taskData, MYSQLI_NUM);
					$noOfData = $taskCusor[0];
					if ($noOfData > 0) {
						if ($noOfData > $rlt['taskCount']) {
							$noOfData = $rlt['taskCount'];
						}
						$completionPercent = ($noOfData * 100) / $rlt['taskCount'];
					}
					if ($completionPercent > 100) {
						$completionPercent = 100;
					}
					$rlt['taskCompleted'] = $noOfData;
					$rlt['taskCompletionPercent'] = $completionPercent;
				} else {
					$rlt['taskCompleted'] = "0";
					$rlt['taskCompletionPercent'] = "0";
				}

				//////////REFER///////////////
				$completionPercent = 0;
				if ($rlt['referCount'] != 0 && strlen($userId) > 0 && (int)$userId > 0) // 13 = refer users
				{
					$totalItems = $totalItems + 100;

					$referQry = "SELECT count(userId) FROM user_master WHERE referralUserId  = '" . $userId . "' AND  entryDate > '" . $lastClaimDate . "'";
					$referData = mysqli_query($this->db, $referQry);
					$noOfData = 0;
					$referCusor = mysqli_fetch_array($referData, MYSQLI_NUM);
					$noOfData = $referCusor[0];
					if ($noOfData > 0) {
						if ($noOfData > $rlt['referCount']) {
							$noOfData = $rlt['referCount'];
						}
						$completionPercent = ($noOfData * 100) / $rlt['referCount'];
					}
					if ($completionPercent > 100) {
						$completionPercent = 100;
					}
					$rlt['referCompleted'] = $noOfData;
					$rlt['referCompletionPercent'] = $completionPercent;
				} else {
					$rlt['referCompleted'] = "0";
					$rlt['referCompletionPercent'] = "0";
				}

				//////////PUBSCALE OFFER///////////////
				$completionPercent = 0;
				if ($rlt['pubscaleCount'] != 0 && strlen($userId) > 0 && (int)$userId > 0) // 40 =pubscale
				{
					$totalItems = $totalItems + 100;
					$pubscaleQry = "SELECT count(id),sum(coin_amount) FROM pubscale_history WHERE userId = '" . $userId . "' AND  entryDate > '" . $lastClaimDate . "'";
					$pubscaleData = mysqli_query($this->db, $pubscaleQry);
					$noOfData = 0;
					$pubscaleCusor = mysqli_fetch_array($pubscaleData, MYSQLI_NUM);
					$noOfData = $pubscaleCusor[0];
					if ($noOfData > 0) {
						if ($noOfData > $rlt['pubscaleCount']) {
							$noOfData = $rlt['pubscaleCount'];
						}
						$completionPercent = ($noOfData * 100) / $rlt['pubscaleCount'];
					}
					if ($completionPercent > 100) {
						$completionPercent = 100;
					}
					$rlt['pubscaleCompleted'] = $noOfData;
					$rlt['pubscaleCompletionPercent'] = $completionPercent;
				} else {
					$rlt['pubscaleCompleted'] = "0";
					$rlt['pubscaleCompletionPercent'] = "0";
				}

				//////////////////ADJOE///////////////////
				$completionPercent = 0;
				if ($rlt['adjoePoints'] != 0 && strlen($userId) > 0 && (int)$userId > 0) // 24 = playtime adjoe (ONLY POINTS)
				{
					$totalItems = $totalItems + 100;
					$adjoeQry = "SELECT count(id),sum(coin_amount) FROM adjoe_history WHERE userId = '" . $userId . "'  AND  entryDate > '" . $lastClaimDate . "'";
					$adjoeData = mysqli_query($this->db, $adjoeQry);
					$adjoeCusor = mysqli_fetch_array($adjoeData, MYSQLI_NUM);
					$earnedPoints = $adjoeCusor[1];
					if ($earnedPoints > 0) {
						if ($earnedPoints > $rlt['adjoePoints']) {
							$earnedPoints = $rlt['adjoePoints'];
						}
						$completionPercent = ($earnedPoints * 100) / $rlt['adjoePoints'];
					}
					if ($completionPercent > 100) {
						$completionPercent = 100;
					}

					if ($earnedPoints == NULL) {
						$rlt['adjoeEarnedPoints'] = "0";
					} else {
						$rlt['adjoeEarnedPoints'] = $earnedPoints;
					}
					$rlt['adjoeCompletionPercent'] = $completionPercent;
				} else {
					$rlt['adjoeEarnedPoints'] = "0";
					$rlt['adjoeCompletionPercent'] = "0";
				}
				if ($totalItems > 0) {
					$levelCompletionPercent = (($rlt['taskCompletionPercent'] + $rlt['referCompletionPercent'] + $rlt['pubscaleCompletionPercent'] + $rlt['adjoeCompletionPercent']) * 100) / $totalItems;
				} else {
					$levelCompletionPercent = 0;
				}

				$rlt['levelCompletionPercent'] = $levelCompletionPercent;

				$rlt['todayDate'] = date("Y-m-d H:i:s");
				$result['levelEarningData'][] = $rlt;
			}
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
		} else {
			$result['message'] = "No level earning data available";
			$result['status'] = "2";
		}

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}

	//getSingleLevelEarningData
	private function SABHAYA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d H:i:s");
		$userId = $Details['NA926Q'];
		$currentLevelId = $Details['T5X9Q0'];



		$sqlstring = "SELECT id FROM tbl_level_earning WHERE isActive = '1' ORDER BY id DESC LIMIT 1";
		$milestonesData = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($milestonesData) > 0) {
			$maxLevelId = mysqli_fetch_array($milestonesData, MYSQLI_NUM)[0];
		}

		$sqlCampId = mysqli_query($this->db, "SELECT levelEarningId,entryDate FROM tbl_level_earning_history WHERE userId = '" . $userId . "' ORDER BY id DESC LIMIT 1");
		$lastClaimDate = "2023-10-30 00:00:00";

		$lastClaimedLevelEarningId = 0;
		if (mysqli_num_rows($sqlCampId) > 0) {
			$claimedData = mysqli_fetch_array($sqlCampId, MYSQLI_NUM);
			$lastClaimedLevelEarningId = $claimedData[0];
			$lastClaimDate = $claimedData[1];
		}

		if ($lastClaimedLevelEarningId < $maxLevelId) {
			$sqlstring = "SELECT * FROM tbl_level_earning WHERE id >= $lastClaimedLevelEarningId AND  isActive = '1' ORDER BY id LIMIT 2";
			$milestonesData = mysqli_query($this->db, $sqlstring);
			if (mysqli_num_rows($milestonesData) > 0 && strlen($userId) > 0 && (int) $userId > 0) {
				while ($rlContest = mysqli_fetch_array($milestonesData, MYSQLI_ASSOC)) {
					$levelEarningCursor[] = $rlContest;
				}
				if ($lastClaimedLevelEarningId == 0) {
					$currentLevelId = $levelEarningCursor[0]['id'];
					$data1 = "Level 0";
					$data2 = "Level 1";
				} else {
					$currentLevelId = $levelEarningCursor[1]['id'];
					$data1 = $levelEarningCursor[0]['title'];
					$data2 = $levelEarningCursor[1]['title'];
				}
			} else {
				$lastClaimedLevelEarningId = 0;
				$data1 = "Level 0";
				$data2 = "Level 1";
			}
		}

		$sqlstring = "SELECT * FROM tbl_level_earning WHERE id = '" . $currentLevelId . "'";
		$completionPercent = 0;
		$milestonesData = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($milestonesData) > 0) {
			$rlt = mysqli_fetch_array($milestonesData, MYSQLI_ASSOC);
			$levelEarningPoints = $rlt['points'];
			//////////TASK///////////////		
			$totalItems = 0;
			$taskCompletionPercent = 0;
			if ($rlt['taskCount'] != 0) // 11 = tasks
			{
				$totalItems = $totalItems + 100;
				$taskQry = "SELECT count(id),sum(points) FROM cpalead WHERE userId = '" . $userId . "'  AND  entryDate > '" . $lastClaimDate . "'";
				$taskData = mysqli_query($this->db, $taskQry);

				$taskCusor = mysqli_fetch_array($taskData, MYSQLI_NUM);
				$noOfData = $taskCusor[0];
				if ($noOfData > 0) {
					$taskCompletionPercent = ($noOfData * 100) / $rlt['taskCount'];
				}
				if ($taskCompletionPercent > 100) {
					$taskCompletionPercent = 100;
				}
			}

			//////////REFER///////////////
			$referCompletionPercent = 0;
			if ($rlt['referCount'] != 0) // 13 = refer users
			{
				$totalItems = $totalItems + 100;
				$referQry = "SELECT count(userId) FROM user_master WHERE referralUserId  = '" . $userId . "' AND  entryDate > '" . $lastClaimDate . "'";
				// $result['qry4'] = $referQry;
				$referData = mysqli_query($this->db, $referQry);

				$taskCusor = mysqli_fetch_array($referData, MYSQLI_NUM);
				$noOfData = $taskCusor[0];
				if ($noOfData > 0) {
					$referCompletionPercent = ($noOfData * 100) / $rlt['referCount'];
				}
				if ($referCompletionPercent > 100) {
					$referCompletionPercent = 100;
				}
			}

			//////////PUBSCALE OFFER///////////////
			$pubscaleCompletionPercent = 0;
			if ($rlt['pubscaleCount'] != 0) // 40 =pubscale
			{
				$totalItems = $totalItems + 100;
				$pubscaleQry = "SELECT count(id),sum(coin_amount) FROM pubscale_history WHERE userId = '" . $userId . "' AND  entryDate > '" . $lastClaimDate . "'";
				$pubscaleData = mysqli_query($this->db, $pubscaleQry);

				$taskCusor = mysqli_fetch_array($pubscaleData, MYSQLI_NUM);
				$noOfData = $taskCusor[0];
				if ($noOfData > 0) {
					$pubscaleCompletionPercent = ($noOfData * 100) / $rlt['pubscaleCount'];
				}
				if ($pubscaleCompletionPercent > 100) {
					$pubscaleCompletionPercent = 100;
				}
			}

			//////////////////ADJOE///////////////////
			$adjoeCompletionPercent = 0;
			if ($rlt['adjoePoints'] != 0) // 24 = playtime adjoe (ONLY POINTS)
			{
				$totalItems = $totalItems + 100;
				$adjoeQry = "SELECT count(id),sum(coin_amount) FROM adjoe_history WHERE userId = '" . $userId . "'  AND  entryDate > '" . $lastClaimDate . "'";
				$adjoeData = mysqli_query($this->db, $adjoeQry);

				$taskCusor = mysqli_fetch_array($adjoeData, MYSQLI_NUM);
				$earnedPoints = $taskCusor[1];
				if ($earnedPoints > 0) {
					$adjoeCompletionPercent = ($earnedPoints * 100) / $rlt['adjoePoints'];
				}
				if ($adjoeCompletionPercent > 100) {
					$adjoeCompletionPercent = 100;
				}
			}
			if ($totalItems > 0) {
				$completionPercent = (($taskCompletionPercent + $referCompletionPercent + $pubscaleCompletionPercent + $adjoeCompletionPercent) * 100) / $totalItems;
			} else {
				$completionPercent = 0;
			}


			$result['fromEarningLevel'] = $data1;
			$result['toEarningLevel'] = $data2;
			$result['levelEarningPercentage'] = $completionPercent;
			$result['levelEarningPoints'] = $levelEarningPoints;

			$result['status'] = "1";
			$result['message'] = "Data found successfully";
		} else {
			$result['message'] = "No level earning data available";
			$result['status'] = "2";
		}

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}

	//saveLevelUp
	private function SARVAIYA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['XCH359'];
		$levelupId = $Details['IHTW1A'];
		$adId = $Details['WVFMWY'];
		$deviceId = $Details['SSL40S'];
		$deviceName = $Details['GE15VW'];
		$winningPoints = $Details['O0JYUS'];
		$userToken = $Details['LNWTTW'];

		if (strlen($userId) > 0 && (int)$userId > 0) {

			$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
			$totalTodayTask = mysqli_num_rows($sql1);

			if ($totalTodayTask > 0) {

				$isClaimed = mysqli_query($this->db, "SELECT * FROM tbl_level_earning_history WHERE levelEarningId = '" . $levelupId . "' AND userId = '" . $userId . "'");
				if (mysqli_num_rows($isClaimed) == 0) {
					$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
					if ($sqlRederID->num_rows > 0) {
						$rowewf = $sqlRederID->fetch_assoc();
						$earning_point = $rowewf['earningPoint'];
						$userToken2 = $rowewf['userToken'];

						if ($userToken == $userToken2) {

							$milestonePoints = 0;
							$milestoneData = mysqli_query($this->db, "SELECT * FROM tbl_level_earning WHERE id = '" . $levelupId . "' AND isActive = '1'");
							if (mysqli_num_rows($milestoneData) > 0) {
								$rlt = $milestoneData->fetch_assoc();
								$milestonePoints = $rlt['points'];

								$lastClaimDate = date("2023-10-30 00:00:00");
								$sqlClaimDate = mysqli_query($this->db, "SELECT entryDate FROM tbl_level_earning_history WHERE userId = '" . $userId . "' ORDER BY id DESC LIMIT 1");
								if (mysqli_num_rows($sqlClaimDate) > 0) {
									while ($row =  mysqli_fetch_array($sqlClaimDate, MYSQLI_ASSOC)) {
										$lastClaimDate = $row['entryDate'];
									}
								}

								if ((int)$winningPoints == (int)$milestonePoints) {
									//////////TASK///////////////		
									$totalItems = 0;
									$taskCompletionPercent = 0;
									if ($rlt['taskCount'] != 0) // 11 = tasks
									{
										$totalItems = $totalItems + 100;
										$taskQry = "SELECT count(id),sum(points) FROM cpalead WHERE userId = '" . $userId . "'  AND  entryDate > '" . $lastClaimDate . "'";
										$taskData = mysqli_query($this->db, $taskQry);

										$taskCusor = mysqli_fetch_array($taskData, MYSQLI_NUM);
										$noOfData = $taskCusor[0];
										if ($noOfData > 0) {

											$taskCompletionPercent = ($noOfData * 100) / $rlt['taskCount'];
										}
										if ($taskCompletionPercent > 100) {
											$taskCompletionPercent = 100;
										}
									}

									//////////REFER///////////////
									$referCompletionPercent = 0;
									if ($rlt['referCount'] != 0) // 13 = refer users
									{
										$totalItems = $totalItems + 100;
										$referQry = "SELECT count(userId) FROM user_master WHERE referralUserId  = '" . $userId . "' AND  entryDate > '" . $lastClaimDate . "'";
										$referData = mysqli_query($this->db, $referQry);

										$taskCusor = mysqli_fetch_array($referData, MYSQLI_NUM);
										$noOfData = $taskCusor[0];
										if ($noOfData > 0) {

											$referCompletionPercent = ($noOfData * 100) / $rlt['referCount'];
										}
										if ($referCompletionPercent > 100) {
											$referCompletionPercent = 100;
										}
									}

									//////////PUBSCALE OFFER///////////////
									$pubscaleCompletionPercent = 0;
									if ($rlt['pubscaleCount'] != 0) // 40 =pubscale
									{
										$totalItems = $totalItems + 100;
										$pubscaleQry = "SELECT count(id),sum(coin_amount) FROM pubscale_history WHERE userId = '" . $userId . "' AND  entryDate > '" . $lastClaimDate . "'";
										$pubscaleData = mysqli_query($this->db, $pubscaleQry);

										$taskCusor = mysqli_fetch_array($pubscaleData, MYSQLI_NUM);
										$noOfData = $taskCusor[0];
										if ($noOfData > 0) {

											$pubscaleCompletionPercent = ($noOfData * 100) / $rlt['pubscaleCount'];
										}
										if ($pubscaleCompletionPercent > 100) {
											$pubscaleCompletionPercent = 100;
										}
									}

									//////////////////ADJOE///////////////////
									$adjoeCompletionPercent = 0;
									if ($rlt['adjoePoints'] != 0) // 24 = playtime adjoe (ONLY POINTS)
									{
										$totalItems = $totalItems + 100;
										$adjoeQry = "SELECT count(id),sum(coin_amount) FROM adjoe_history WHERE userId = '" . $userId . "'  AND  entryDate > '" . $lastClaimDate . "'";
										$adjoeData = mysqli_query($this->db, $adjoeQry);

										$taskCusor = mysqli_fetch_array($adjoeData, MYSQLI_NUM);
										$earnedPoints = $taskCusor[1];
										if ($earnedPoints > 0) {
											$adjoeCompletionPercent = ($earnedPoints * 100) / $rlt['adjoePoints'];
										}
										if ($adjoeCompletionPercent > 100) {
											$adjoeCompletionPercent = 100;
										}
									}


									$completionPercent = (($taskCompletionPercent + $referCompletionPercent + $pubscaleCompletionPercent + $adjoeCompletionPercent) * 100) / $totalItems;

									if ($completionPercent >= 100) {
										$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_level_earning_history(levelEarningId,userId, points, adId, deviceName, ipAddress, deviceId) VALUES ('" . $levelupId . "','" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' , '" . $deviceId . "')");
										if ($sqinsert === TRUE) {
											$finalearning_point = (int)$earning_point + (int)$winningPoints;

											$tid = $this->gen_uuid();
											$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '44', '1','" . $finalearning_point . "','Level Earning')");

											$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");

											if ($sqlwalletupdate === TRUE) {
												$result['winningPoints'] = $winningPoints;
												$result['earningPoint'] = $finalearning_point;
												$result['message'] = "Data Found Sucessfully.";
												$result['status'] = "1";
												$result['userToken'] = $tid;
											} else {
												$result['message'] = "Something went wrong1.";
												$result['status'] = "0";
											}
										} else {
											$result['message'] = "Something went wrong2.";
											$result['status'] = "0";
										}
									} else {
										$result['message'] = "Something went wrong3.";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong3.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "This level is is inactive.";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "Something went wrong. user.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "Something went wrong, please try again later.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "You have already claimed reward for this level.";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not completed today's Task & Game";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}
		// $result['helpVideoUrl'] = $Youtube_url;

		$this->response($this->json($result), 200);
	}

	// GetLuckyDraw
	private function SHARMA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d");
		$userId = $Details['C50G9G'];

		$result['todayDate'] = date("Y-m-d H:i:s");
		$DateToday = date("Y-m-d");
		$result['endDate'] = $DateToday . ' 23:59:59';

		$sqlstring = "SELECT * FROM tbl_lucky_draw WHERE isActive = '1'";
		// $result['QRY'] = $sqlstring;

		$drawData = mysqli_query($this->db, $sqlstring);
		if (mysqli_num_rows($drawData) > 0) {
			while ($rlt = mysqli_fetch_array($drawData, MYSQLI_ASSOC)) {
				$already_querry = "SELECT id FROM tbl_lucky_draw_history WHERE userId = '" . $userId . "'  AND  luckyDrawId = '" . $rlt['id'] . "' AND participationDate = '" . $date . "'";
				// $rlt['QUERY'] = $already_querry;
				if (mysqli_num_rows(mysqli_query($this->db, $already_querry)) > 0) {
					$rlt['isParticipated'] = "1";
				} else {
					$rlt['isParticipated'] = "0";
				}
				$total_participants = "SELECT id FROM tbl_lucky_draw_history WHERE luckyDrawId = '" . $rlt['id'] . "' AND participationDate = '" . $date . "'";
				$rlt['qry'] = $total_participants;
				$rlt['totalParticipated'] = mysqli_num_rows(mysqli_query($this->db, $total_participants));
				$result['data'][] = $rlt;
			}
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
		} else {
			$result['message'] = "This milestone is expired or it is inactive";
			$result['status'] = "2";
		}

		$result['helpInfo'] = "-> To Win lucky draw contest, You need to first participate in the contest with mentioned participation points.\n\n-> Points will be deducted from your wallet when you participate.\n\n-> Lucky Draw will take place once a day at 12am.\n\n->One random participant will be choosen as a winner among all participants in each contest.\n\n-> Winning points will be credited in winner's wallet.\n\n-> Result will be declared everyday, you can check result in history.";

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}

	//Participate in lucky draw
	private function  AHUJA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d");
		$result = array();
		$encrypt = $this->_request['details'];
		$name = 'participate in lucky luckyDrawData';
		$isencrypted = '0';
		//$log['log'] = $this->log($encrypt, $name, $isencrypted);
		$userId = $Details['0J282X'];
		$userToken = $Details['88JTDD'];
		$adId = $Details['B7IH86'];
		$deviceName = $Details['RMW84Q'];
		$deviceId = $Details['QI58TJ'];
		$participationPoints = $Details['GRC45J'];
		$luckyDrawId = $Details['HADQEG'];

		if (strlen($userToken) > 0 && strlen($userId) > 0 && (int)$userId > 0) {

			$alreadyParticipated = mysqli_query($this->db, "SELECT * FROM tbl_lucky_draw_history WHERE userId = '" . $userId . "'  AND entryDate = '" . $date . "' AND luckyDrawId = '" . $luckyDrawId . "' ");
			if (mysqli_num_rows($alreadyParticipated) == 0) {
				$contestDetails = mysqli_query($this->db, "SELECT * FROM tbl_lucky_draw WHERE id = '" . $luckyDrawId . "'");
				if (mysqli_num_rows($contestDetails) > 0) {
					$rowContestDetails = $contestDetails->fetch_assoc();
					if ($rowContestDetails['isActive'] == '1') {
						$total_participants = "SELECT id FROM tbl_lucky_draw_history WHERE luckyDrawId = '" . $luckyDrawId . "' AND participationDate = '" . $date . "'";
						$totalParticipated = mysqli_num_rows(mysqli_query($this->db, $total_participants));
						$result['totalParticipated'] = $totalParticipated;
						if ($rowContestDetails['totalParticipants'] > $totalParticipated) {
							if ($rowContestDetails['participationPoints'] == $participationPoints) {
								$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
								if ($sqlRederID->num_rows > 0) {
									$rowewf = $sqlRederID->fetch_assoc();
									$earning_point = $rowewf['earningPoint'];
									$token = $rowewf['token'];
									$adId2 = $rowewf['adId'];
									$userToken2 = $rowewf['userToken'];
									if ((int)$earning_point - (int)$participationPoints > 0) {
										if ($userToken == $userToken2) {
											$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_lucky_draw_history(userId, luckyDrawId, participationPoints, participationDate, adId, deviceId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $luckyDrawId . "', '" . $participationPoints . "','" . $date . "', '" . $adId . "', '" . $deviceId . "', '" . $deviceName . "','" . $ipaddress . "' )");
											if ($sqinsert === TRUE) {
												$finalearning_point = (int)$earning_point - (int)$participationPoints;
												$tid = $this->gen_uuid();

												$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $participationPoints . "', '47', '2','" . $finalearning_point . "','Participation in Lucky Draw')");

												$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "', userToken='" . $tid . "' WHERE userId = '" . $userId . "'");


												if ($sqlwalletupdate === TRUE) {
													$result['earningPoint'] = $finalearning_point;
													$result['message'] = "You have successfully participated in Lucky Draw contest. Please wait for the result.";
													$result['status'] = "1";
													$result['userToken'] = $tid;
													$result['totalParticipated'] = $totalParticipated + 1;
												} else {
													$result['message'] = "Something went wrong.1";
													$result['status'] = "0";
												}
											} else {
												$result['message'] = "Something went wrong.2";
												$result['status'] = "0";
											}
										} else {
											$result['message'] = "Something went wrong. Login Again";
											$result['status'] = "5";
										}
									} else {
										$result['message'] = "You don't enough points to participate in contest!";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong, please try again later.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "Something went wrong, please try again later. points";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "Participants are full. Please join another contest.";
							$result['status'] = "2";
						}
					} else {
						$result['message'] = "This contest is inactive, please try again later.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Something went wrong, please try again later. Contest.";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have already participated in this contest.";
				$result['status'] = "1";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}

		$this->response($this->json($result), 200);
	}

	//getLuckyDrawHistory
	private function MIXVEGPAKODA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name;
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$result = array();
		$perpage = 20;
		$PAGE_NO = $Details['PRA2OO'];
		$deviseId = $Details['E8COYH'];
		$adId = $Details['8HD1EJ'];
		$deviceName = $Details['WWX54U'];
		$appVersion = $Details['CJCMO4'];
		$todayOpen = $Details['4TDU3G'];
		$totalOpen = $Details['FREFYH'];

		$calc = $perpage * $PAGE_NO;
		$start = $calc - $perpage;

		$query = "SELECT id,luckyDrawId,userId, participationDate as declarationDate FROM tbl_lucky_draw_history WHERE winningPoints > '0' GROUP BY participationDate ORDER BY participationDate DESC LIMIT " . $start . "," . $perpage . "";
		$dateData = mysqli_query($this->db, $query);
		$total = mysqli_num_rows($dateData);
		if ($total > 0) {
			$totalPages = ceil($total / $perpage);
			$result['totalPage'] = $totalPages;
			$result['totalIteam'] = $total;
			$result['currentPage'] = $PAGE_NO;
			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";
			while ($rlContest = mysqli_fetch_array($dateData, MYSQLI_ASSOC)) {
				$query = "SELECT t2.title,t2.bgColor,t2.buttonBgColor,t2.buttonTextColor,t1.winningPoints as points,t1.participationDate,t1.userId FROM tbl_lucky_draw_history as t1 left join tbl_lucky_draw as t2 on t2.id = t1.luckyDrawId WHERE t1.participationDate = '" . $rlContest['declarationDate'] . "' AND t1.winningPoints > '0' ORDER BY t1.luckyDrawId";
				$winnerData = mysqli_query($this->db, $query);
				if (mysqli_num_rows($winnerData) > 0) {
					while ($rlWinner = mysqli_fetch_array($winnerData, MYSQLI_ASSOC)) {
						$query = "SELECT userId,firstName,lastName,profileImage FROM user_master WHERE userId = '" . $rlWinner['userId'] . "'";
						// $rlWinner['QRY'] = $query;
						$sqlRederID = mysqli_query($this->db, $query);
						if ($sqlRederID->num_rows > 0) {
							$raw = $sqlRederID->fetch_assoc();
							$rlWinner['firstName'] = $raw['firstName'];
							$rlWinner['lastName'] = $raw['lastName'];
							$rlWinner['profileImage'] = $raw['profileImage'];
						}
						$rlContest['data'][] = $rlWinner;
					}
				}
				$result['historyData'][] = $rlContest;
			}
		} else {
			$result['status'] = "2";
			$result['message'] = "No data available";
		}


		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['type'] = "0";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>$App_Name Provides 100% Withdraw to All Users.</marquee>";

		// $result['miniAds']['image'] = "https://mycashbazar.com/ExtraImages/iphone13.png";
		// $result['miniAds']['screenNo'] = "2";
		// $result['miniAds']['id'] = "58";
		// $result['miniAds']['url'] = "https://sportsgurupro.com/TaskOffers/";

		$result['adFailUrl'] = "https://sportsgurupro.com";


		$this->response($this->json($result), 200);
	}


	// validateUPI 
	private function HAWN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d");
		$userId = $Details['5HFF1U'];
		$upiString = $Details['OEMRDG'];		// upi://pay?pa=paytmqr2810050501011u8tarftype0@paytm&pn=Paytm%20Merchant&mc=5499&mode=02&orgid=000000&paytmqr=2810050501011U8TARFTYPE0&sign=MEQCIGoGW4NrLvd9OyAPlZniGMnldSQZ6yAK+m8GpUCzPr/1AiB4ABR43GshGUq5hc5zwSeToXAhAIAKwiox9jgV9194XQ==

		$upiString = urldecode($upiString);
		$pieces = explode("&", $upiString);
		$pieces = str_replace("upi://pay?", "", $pieces);
		// echo "<br/>".$pieces[0];
		// echo "<br/>".$pieces[1];
		// echo "<br/>".$pieces[2];
		// echo "<br/>".$pieces[3];
		// echo "<br/>".$pieces[4];
		// echo "<br/>".$pieces[5];
		// echo "<br/>".$pieces[6];
		// echo "<br/>=====================================================";

		$amount = 0;

		foreach ($pieces as $value) {
			$value1 = explode("=", $value);
			if ($value1[0] == 'pa') {
				$upi = $value1[1];
			}
			if ($value1[0] == 'pn') {
				$name = $value1[1];
			}
			if ($value1[0] == 'am') {
				$amount = $value1[1];
			}
		}

		if (strlen($upi) > 0 && strlen($name) > 0) {
			$result['upiId'] = $upi;
			$result['recipientName'] = $name;
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
		} else {
			$result['status'] = "0";
			$result['message'] = "Upi id is not verified.";
		}

		// $result['status'] = "0";
		// $result['message'] = "Scan & Pay is undemaintence; try after 2-4 hours.";	

		$result['extraCharge'] = "120";
		$result['minPayAmountForCharges'] = "10";
		$result['minPayAmount'] = "5";
		$result['paymentAmount'] = $amount;
		$result['upiImage'] = "https://play-lh.googleusercontent.com/B5cNBA15IxjCT-8UTXEWgiPcGkJ1C07iHKwm2Hbs8xR3PnJvZ0swTag3abdC_Fj5OfnP";

		// $result['homeNote'] = "<marquee >Now ₹3,₹10 Minimum Withdraw. <strong> More task = More Money Loot Now.</strong> Sports Guru Provide 100% Withdraw to All Users.</marquee>";

		// $result['topAds']['image'] = "https://mycashbazar.com/ExtraImages/yt.json";
		// $result['topAds']['screenNo'] = "2";
		// $result['topAds']['type'] = "1";
		// $result['topAds']['url'] = $Youtube_url;

		$result['adFailUrl'] = "https://sportsgurupro.com";


		$this->response($this->json($result), 200);
	}

	//getPaymentStatus
	private function QUIN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d");
		$userId = $Details['NLETIK'];
		$txnID = $Details['YHMOZT'];
		// $result['details'] = $Details;

		$response = file_get_contents("http://taskpaydeal.com/UPITransfer/GetreachargeStatus.php?txnID=" . $txnID);
		// $result['response'] = $response;
		$apiresponse = json_decode($response, true);
		if ($apiresponse['status'] == "Sucess") {
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
			$sqlwalletupdate = mysqli_query($this->db, "UPDATE withdraw_coupone  SET isDeliverd='1'   WHERE txnID = '" . $txnID . "' ");
		} else {
			$result['status'] = "0";
			$result['message'] = "Pending";
		}
		$result['adFailUrl'] = "https://sportsgurupro.com";


		$this->response($this->json($result), 200);
	}

	// scanAndPay 
	private function KING()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name, $prifix;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$date = date("Y-m-d");

		$upiId = $Details['GLWR83'];
		$amount = $Details['B04AWP'];
		$totalDeductionPoints = $Details['GDHLQW'];
		$name = $Details['OMJERQ'];
		$notes = $Details['1H28WQ'];
		$charges = $Details['WDDS1W'];
		$userId = $Details['GEC8BJ'];
		$userToken = $Details['WBWMFO'];
		$adId = $Details['AZRQOC'];
		$deviceName = $Details['H0WYYG'];
		$deviceId = $Details['2IA2OO'];
		$date = date('Y-m-d H:i:s');
		global $minAmontCharger;
		global $charges;
		if ($amount < $minAmontCharger) {
			$mincharge = $charges;
			$charges = 120;
		} else {
			$mincharge = 0;
			$charges = 0;
		}
		sleep(3);
		$agent = $_SERVER['HTTP_USER_AGENT'];
		if (strlen($userId) > 0 && $agent == "okhttp/5.0.0-alpha.2") {
			$datetime = date("Y-m-d H:i:s");
			$timestamp = strtotime($datetime);
			$time = $timestamp - (5 * 60);
			$datetime1 = date("Y-m-d H:i:s", $time);
			$scratchCardList1 = mysqli_query($this->db, "SELECT id FROM withdraw_coupone WHERE userId = '" . $userId . "' AND entryDate > '" . $datetime1 . "'  ");
			if (mysqli_num_rows($scratchCardList1) > 0) {
				$result['message'] = "Next Withdarw Enable after 5 minutes.";
				$result['status'] = "0";
			} else {
				$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
				if ($sqlRederID->num_rows > 0) {
					$rowewf = $sqlRederID->fetch_assoc();
					$earning_point = $rowewf['earningPoint'];
					$token2 = $rowewf['token'];
					$isActive = $rowewf['isActive'];
				}

				$pointsMain = (int)$amount * 100;

				$totalDeductionPoints = $pointsMain + $charges;

				if ($isActive == "1" && (int)$earning_point >= (int)$totalDeductionPoints) {

					$finalearning_point = (int)$earning_point - (int) $totalDeductionPoints;
					$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "'   WHERE userId = '" . $userId . "' ");

					if (mysqli_affected_rows($this->db)) {
						$txnid =  "$prifix" . $userId . "QR" . rand(100, 1000000);
						$mobileNumber = $upiId;
						$withdrawType = "10";
						$txtTypeID2 = "49";
						$withdrawId = "33";
						$title = $name . " Qr Payment Send";
						$response = file_get_contents("http://taskpaydeal.com/UPITransfer/ReachargeQr.php?UPIID=" . $mobileNumber . "&amount=" . $amount . "&appName=$App_NamePayment&userId=" . $userId . "&txnID=" . $txnid);
						$apiresponse = json_decode($response, true);
						if ($apiresponse['status_code'] == "200") {
							$txnid = $apiresponse['txnID'];

							mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $totalDeductionPoints . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "', '" . $title . "')");

							$queryAuto = mysqli_query($this->db, "INSERT INTO withdraw_coupone (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $totalDeductionPoints . "','" . $charges . "','" . $name . "','" . $mobileNumber . "','0' ,'" . $withdrawId . "','" . $ipaddress . "', '' ,'" . $txnid . "','' , '" . $date . "' ,'" . $deviceName . "' ) ");
							if ($queryAuto === true) {
								// $this->senWithdrawNoChanneSucesslNotiQR($token2, "");
								$result['earningPoint'] = $finalearning_point;
								$result['message'] = "We have successfully transferred money to your Qr Code Partner.\n \nAmount will be credited in 0-1 minutes.\n";
								$result['status'] = "1";
								$result['paymentPartner'] = "EasyEarn";
								$result['entryDate'] = $date;
								$result['shareText'] = "Payment is done from $App_Name app. Download Now: https://bit.ly/$App_Name_Earn_Money";
								$result['txnStatus'] = "0";
								$result['txnID'] = $txnid;
								$result['deliveryDate'] = $date;
							}
						} else {
							$finalearning_point2 = (int)$earning_point;
							$sqlwalletupdate2 = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point2 . "'   WHERE userId = '" . $userId . "' ");
							$result['message'] = "There is a technical issue at your bank please try after some time.\n";
							$result['status'] = "0";
						}
					}
				} else {
					$result['message'] = "Insufficent Wallet Balance.";
					$result['status'] = "0";
				}
			}
		} else {

			$result['message'] = "Something Went wrong. Please Login Again.";
			$result['status'] = "0";
		}


		// $result['status'] = "1";
		// $result['message'] = "Payment has been done successfully!";
		// $result['earningPoint'] = $finalearning_point;
		// $result['txnStatus'] = "5";


		$result['adFailUrl'] = "https://sportsgurupro.com";


		$this->response($this->json($result), 200);
	}


	// paymentDetails 
	private function CINDRELLA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name;
		$Details = json_decode($this->_request['details'], true);
		// $decrypted = MCrypt::decrypt($this->_request['details']);
		// $Details = json_decode($decrypted, true);
		// $ipaddress = $this->getIp();

		$userId = $Details['NWI6Z7'];
		$withdrawId = $Details['AMGGOG'];

		$queryAuto = mysqli_query($this->db, "SELECT * FROM withdraw_coupone WHERE id = '" . $withdrawId . "'  ");
		if ($queryAuto->num_rows > 0) {
			$rowewf = $queryAuto->fetch_assoc();
			$result['payment'] = $rowewf;
			$charges = $rowewf['pointValue'];
			$points = $rowewf['points'];
			$result['payment']['amount'] = ((int) $points - (int) $charges) / 100;
			$result['payment']['paymentFrom'] = "EasyEarn";
			$result['status'] = "1";
		} else {
			$result['message'] = "data not found";
			$result['status'] = "2";
		}
		$result['shareText'] = "Payment is done from $App_Name app. Download Now: https://bit.ly/$App_Name_Earn_Money";

		$result['upiImage'] = "https://play-lh.googleusercontent.com/B5cNBA15IxjCT-8UTXEWgiPcGkJ1C07iHKwm2Hbs8xR3PnJvZ0swTag3abdC_Fj5OfnP";

		$this->response($this->json($result), 200);
	}


	//getcountUp
	private function KANDY()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$userId = $Details['MGD5F1'];
		$ipaddress = $this->getIp();
		$result = array();
		$totalGameCount = "3";
		$remainGameCount = "5";
		$gamekeyword = array("Tap the Numbers From Lowest to Highest", "Tap the Numbers From Highest to Lowest");

		$arr1 = array(rand(-50, -45), rand(-44, -35), rand(-34, -25), rand(-24, -15), rand(-14, -5), rand(-4, 5), rand(6, 16), rand(17, 26), rand(27, 36), rand(37, 50));


		$data = array(
			array("id" => "1", "value" => strval($arr1[0])),
			array("id" => "2", "value" => strval($arr1[1])),
			array("id" => "3", "value" => strval($arr1[2])),
			array("id" => "4", "value" => strval($arr1[3])),
			array("id" => "5", "value" => strval($arr1[4])),
			array("id" => "6", "value" => strval($arr1[5])),
			array("id" => "7", "value" => strval($arr1[6])),
			array("id" => "8", "value" => strval($arr1[7])),
			array("id" => "9 ", "value" => strval($arr1[8])),
			array("id" => "10", "value" => strval($arr1[9])),
			array("id" => "11", "value" => ""),
			array("id" => "12", "value" => ""),
			array("id" => "13", "value" => ""),
			array("id" => "14", "value" => ""),
			array("id" => "15", "value" => ""),
			array("id" => "16", "value" => ""),
			array("id" => "17", "value" => ""),
			array("id" => "18", "value" => ""),
			array("id" => "19", "value" => ""),
			array("id" => "20", "value" => "")
		);
		shuffle($data);
		$sortingOrder = rand(0, 1);
		$result['gameText'] = $gamekeyword[$sortingOrder];
		$result['gameType'] = $sortingOrder;
		$result['data'] = $data;

		$points = "10";
		$result['totalGameCount'] = $totalGameCount;
		$result['points'] = $points;
		$result['gameTime'] = "30"; //second
		$result['nextGameTime'] =  "2"; //minutes

		if (strlen($userId) > 0) {
			$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM countup_game_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			if ($totalTodayPlayCount->num_rows > 0) {
				$rowewf1 = $totalTodayPlayCount->fetch_assoc();
				$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
				if ($totalTodayCount < $totalGameCount) {

					$result['status'] = "1";
					$result['message'] = "Data found successfully";
				} else {

					$result['message'] = "You have exhausted today's Number Sorting Game limit, please try again tomorrow.";
					$result['status'] = "2";
				}
			} else {
				$result['status'] = "1";
				$result['message'] = "First time Data found successfully";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "1";
		}


		$result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);

		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock Number Sorting Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "31";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Number Sorting Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM countup_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		$result['todayDate'] = date("Y-m-d H:i:s");
		$this->response($this->json($result), 200);
	}


	//savecountUp
	private function  SLAP()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$encrypt = $this->_request['details'];
		$name = 'savecountup';
		$isencrypted = '0';
		//$log['log'] = $this->log($encrypt, $name, $isencrypted);
		$userId = $Details['HGEBPU'];
		$userToken = $Details['KVA3JO'];
		$adId = $Details['EYT6SC'];
		$deviceName = $Details['5DAGQ0'];
		$winningPoints = $Details['WCKM8G'];

		$totalGameCount = "3";
		$remainGameCount = "5";

		$points = "10";
		$result['points'] = $points;


		$result['totalGameCount'] = $totalGameCount;

		$gamekeyword = array("Tap the Numbers From Lowest to Highest", "Tap the Numbers From Highest to Lowest");

		$arr1 = array(rand(-50, -45), rand(-44, -35), rand(-34, -25), rand(-24, -15), rand(-14, -5), rand(-4, 5), rand(6, 16), rand(17, 26), rand(27, 36), rand(37, 50));


		$data = array(
			array("id" => "1", "value" => strval($arr1[0])),
			array("id" => "2", "value" => strval($arr1[1])),
			array("id" => "3", "value" => strval($arr1[2])),
			array("id" => "4", "value" => strval($arr1[3])),
			array("id" => "5", "value" => strval($arr1[4])),
			array("id" => "6", "value" => strval($arr1[5])),
			array("id" => "7", "value" => strval($arr1[6])),
			array("id" => "8", "value" => strval($arr1[7])),
			array("id" => "9 ", "value" => strval($arr1[8])),
			array("id" => "10", "value" => strval($arr1[9])),
			array("id" => "11", "value" => ""),
			array("id" => "12", "value" => ""),
			array("id" => "13", "value" => ""),
			array("id" => "14", "value" => ""),
			array("id" => "15", "value" => ""),
			array("id" => "16", "value" => ""),
			array("id" => "17", "value" => ""),
			array("id" => "18", "value" => ""),
			array("id" => "19", "value" => ""),
			array("id" => "20", "value" => "")
		);
		shuffle($data);
		$sortingOrder = rand(0, 1);
		$result['gameText'] = $gamekeyword[$sortingOrder];
		$result['gameType'] = $sortingOrder;
		$result['data'] = $data;
		if (strlen($userToken) > 0) {
			if (strlen($userId) > 0 && (int)$userId > 0) {

				$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
				$totalTodayTask = mysqli_num_rows($sql1);

				if ($totalTodayTask > 0) {
					$datetime = date("Y-m-d H:i:s");
					$timestamp = strtotime($datetime);
					$time = $timestamp - (75);
					$datetime1 = date("Y-m-d H:i:s", $time);

					$scratchCardList1 = mysqli_query($this->db, "SELECT id FROM countup_game_history WHERE userId = '" . $userId . "' AND entryDate > '" . $datetime1 . "'  ");

					if (mysqli_num_rows($scratchCardList1) > 0) {
						$result['message'] = "Something Went Wrong, Try Again After Sometime";
						$result['status'] = "0";
					} else {
						if ($winningPoints == '0' || $winningPoints == $points) {
							$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM countup_game_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
							$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
							if ($totalTodayCount < $totalGameCount) {
								$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
								if ($sqlRederID->num_rows > 0) {
									$rowewf = $sqlRederID->fetch_assoc();
									$earning_point = $rowewf['earningPoint'];
									$token = $rowewf['token'];
									$adId2 = $rowewf['adId'];
									$userToken2 = $rowewf['userToken'];

									if ($userToken == $userToken2) {
										$sqinsert = mysqli_query($this->db, "INSERT INTO countup_game_history(userId, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
										if ($sqinsert === TRUE) {
											if ((int)$winningPoints > 0) {
												$finalearning_point = (int)$earning_point + (int)$winningPoints;
												$tid = $this->gen_uuid();

												$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '32', '1','" . $finalearning_point . "','Number Sorting Game')");

												$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "', userToken='" . $tid . "' WHERE userId = '" . $userId . "'");


												if ($sqlwalletupdate === TRUE) {
													$result['winningPoints'] = $winningPoints;
													$result['earningPoint'] = $finalearning_point;
													$result['message'] = "Data Found Sucessfully.";
													$result['status'] = "1";
													$result['userToken'] = $tid;
												} else {
													$result['message'] = "Something went wrong.1";
													$result['status'] = "0";
												}
											} else {
												$result['winningPoints'] = $winningPoints;
												$result['earningPoint'] = $earning_point;
												$result['message'] = "Data Found Sucessfully.";
												$result['status'] = "1";
											}
										} else {
											$result['message'] = "Something went wrong.2";
											$result['status'] = "0";
										}
									} else {
										$result['message'] = "Something went wrong. Login Again";
										$result['status'] = "5";
									}
								} else {
									$result['message'] = "Something went wrong, please try again later.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "You have exhausted today's Number Sorting Game limit, please try again tomorrow.";
								$result['status'] = "2";
							}
						} else {
							$result['message'] = "Something went wrong, please try again later.11";
							$result['status'] = "0";
						}
					}
				} else {
					$result['message'] = "You have not completed today's Task & Game";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later.111";
			$result['status'] = "0";
		}
		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM countup_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		}
		$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM countup_game_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
		$result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);
		$result['gameTime'] = "30"; //second
		$result['nextGameTime'] =  "2"; //minutes
		$result['todayDate'] = date("Y-m-d H:i:s");
		// $result['helpVideoUrl'] = $Youtube_url;
		$this->response($this->json($result), 200);
	}
	//getWordSorting
	private function USMAN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$userId = $Details['1QQEKK'];
		$ipaddress = $this->getIp();
		$result = array();
		$totalGameCount = "3";
		$remainGameCount = "10";

		$arr1 = array(
			array("aqu", "are", "aur", "hus", "hat", "has", "dye", "dee", "tha"),
			array("bla", "bar", "blo", "dea", "dye", "dee", "eas", "edg", "els"),
			array("dea", "dye", "dee", "tha", "tit", "tac", "sea", "see", "say"),
			array("eas", "edg", "els", "bar", "blo", "dea", "dye", "dee", "eas"),
			array("hus", "hat", "has", "seas", "sees", "says", "eas", "edg", "els"),
			array("pee", "pro", "pul", "aur", "hus", "hat", "has", "dye", "dee"),
			array("sea", "see", "say", "hat", "has", "seas", "sees", "says", "eas"),
			array("tha", "tin", "tac", "blo", "dea", "dye", "dee", "eas", "edg"),
		);
		$data = $arr1[rand(0, 7)];
		shuffle($data);
		$result['data'] = $data;
		$points = "10";

		$result['totalGameCount'] = $totalGameCount;
		$result['points'] = $points;
		$result['gameTime'] = "30"; //second
		$result['nextGameTime'] =  "2"; // minute

		if (strlen($userId) > 0) {
			$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM word_sorting_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			if ($totalTodayPlayCount->num_rows > 0) {
				$rowewf1 = $totalTodayPlayCount->fetch_assoc();
				$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
				if ($totalTodayCount < $totalGameCount) {
					$result['status'] = "1";
					$result['message'] = "Data found successfully";
				} else {
					$result['message'] = "You have exhausted today's Word Sorting Game limit, please try again tomorrow.";
					$result['status'] = "2";
				}
			} else {
				$result['status'] = "1";
				$result['message'] = "First time Data found successfully";
			}
		} else {
			//$result['makeTotal']=rand(3,18);
			$result['message'] = "You have not logged in. Please login1";
			$result['status'] = "1";
		}


		$result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);


		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock Word Sorting Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "31";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Word Sorting Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable this, just comment this line

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM word_sorting_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
		if ($sqlRederID->num_rows > 0) {
			$rowewf = $sqlRederID->fetch_assoc();
			$userToken2 = $rowewf['userToken'];
			$result['userToken'] = $userToken2;
		}
		//$result['lastDate'] = "2019-10-17 07:27:37";
		$result['todayDate'] = date("Y-m-d H:i:s");
		$this->response($this->json($result), 200);
	}
	//saveWordSorting
	private function YAMOONA()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$encrypt = $this->_request['details'];
		$name = 'savecountup';
		$isencrypted = '0';
		// $log['log'] = $this->log($encrypt, $name, $isencrypted);
		$userId = $Details['PQZSDD'];
		$userToken = $Details['HR9ZJ6'];
		$adId = $Details['HWSDX2'];
		$deviceName = $Details['AWQEDQ'];
		$winningPoints = $Details['STWTKT'];

		$totalGameCount = "3";
		$remainGameCount = "10";
		$points = "10";
		$result['points'] = $points;
		$result['totalGameCount'] = $totalGameCount;

		$arr1 = array(
			array("aqu", "are", "aur", "hus", "hat", "has", "dye", "dee", "tha"),
			array("bla", "bar", "blo", "dea", "dye", "dee", "eas", "edg", "els"),
			array("dea", "dye", "dee", "tha", "tit", "tac", "sea", "see", "say"),
			array("eas", "edg", "els", "bar", "blo", "dea", "dye", "dee", "eas"),
			array("hus", "hat", "has", "seas", "sees", "says", "eas", "edg", "els"),
			array("pee", "pro", "pul", "aur", "hus", "hat", "has", "dye", "dee"),
			array("sea", "see", "say", "hat", "has", "seas", "sees", "says", "eas"),
			array("tha", "tin", "tac", "blo", "dea", "dye", "dee", "eas", "edg"),
		);
		$data = $arr1[rand(0, 7)];
		shuffle($data);
		$result['data'] = $data;

		if (strlen($userToken) > 0) {
			if (strlen($userId) > 0 && (int)$userId > 0) {
				if ($winningPoints == '0' || $winningPoints == $points) {

					$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
					$totalTodayTask = mysqli_num_rows($sql1);

					if ($totalTodayTask > 0) {
						$datetime = date("Y-m-d H:i:s");
						$timestamp = strtotime($datetime);
						$time = $timestamp - (60);
						$datetime1 = date("Y-m-d H:i:s", $time);
						$scratchCardList1 = mysqli_query($this->db, "SELECT id FROM word_sorting_history WHERE userId = '" . $userId . "' AND entryDate > '" . $datetime1 . "'  ");
						if (mysqli_num_rows($scratchCardList1) > 0) {
							$result['message'] = "Something Went Wrong, Try Again After Sometime";
							$result['status'] = "0";
						} else {
							$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM word_sorting_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
							$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
							if ($totalTodayCount < $totalGameCount) {
								$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
								if ($sqlRederID->num_rows > 0) {
									$rowewf = $sqlRederID->fetch_assoc();
									$earning_point = $rowewf['earningPoint'];
									$token = $rowewf['token'];
									$adId2 = $rowewf['adId'];
									$userToken2 = $rowewf['userToken'];

									if ($userToken == $userToken2) {
										$sqinsert = mysqli_query($this->db, "INSERT INTO word_sorting_history(userId, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");

										if ($sqinsert === TRUE) {
											if ((int)$winningPoints > 0) {
												$finalearning_point = (int)$earning_point + (int)$winningPoints;
												$tid = $this->gen_uuid();

												$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '33', '1','" . $finalearning_point . "','Word Sorting Game')");

												$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");


												if ($sqlwalletupdate === TRUE) {
													$result['winningPoints'] = $winningPoints;
													$result['earningPoint'] = $finalearning_point;
													$result['message'] = "Data Found Sucessfully.";
													$result['status'] = "1";
													$result['userToken'] = $tid;
												} else {
													$result['message'] = "Something went wrong.1";
													$result['status'] = "0";
												}
											} else {
												$result['winningPoints'] = $winningPoints;
												$result['earningPoint'] = $earning_point;
												$result['message'] = "Data Found Sucessfully.";
												$result['status'] = "1";
											}
										} else {
											$result['message'] = "Something went wrong.2";
											$result['status'] = "0";
										}
									} else {
										$result['message'] = "Something went wrong. Login Again";
										$result['status'] = "5";
									}
								} else {
									$result['message'] = "Something went wrong, please try again later.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "You have exhausted today's Word Sorting Game limit, please try again tomorrow.";
								$result['status'] = "2";
							}
						}
					} else {
						$result['message'] = "You have not completed today's Task & Game";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Something went wrong, please try again later.11";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "1";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later.111";
			$result['status'] = "0";
		}
		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM word_sorting_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		}
		$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM word_sorting_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
		$result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);
		$result['gameTime'] = "30"; // seconds
		$result['nextGameTime'] =  "2"; //minute
		// $result['helpVideoUrl'] = "";
		$result['todayDate'] = date("Y-m-d H:i:s");
		$this->response($this->json($result), 200);
	}
	//getAdjoeLeaderboardData
	private function RAM()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name;
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$result = array();
		$result['todayDate'] = date("Y-m-d H:i:s");
		$DateToday = date("Y-m-d");
		$result['endDate'] = $DateToday . ' 23:59:59';

		$adjoeData = mysqli_query($this->db, "SELECT userId, sum(coin_amount) as points FROM adjoe_history WHERE entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' GROUP BY userId ORDER BY sum(coin_amount) DESC LIMIT 0,50");
		//$result['QRY']= "SELECT userId, sum(coin_amount) FROM adjoe_history WHERE entryDate > '" . date("Y-m-d", time()) . ' 00:00:00'. "' GROUP BY userId ORDER BY sum(coin_amount) DESC LIMIT 0,50";
		if ($adjoeData->num_rows > 0) {
			$imploded = "0";
			while ($rlContest = mysqli_fetch_array($adjoeData, MYSQLI_ASSOC)) {
				$result['data'][] = $rlContest;
				$rows[] = $rlContest['userId'];
			}
			$imploded = implode(',', $rows);

			$userData = mysqli_query($this->db, "SELECT firstName,lastName,profileImage FROM user_master WHERE userId IN (" . $imploded . ")");
			$index = -1;
			while ($row = mysqli_fetch_array($userData, MYSQLI_ASSOC)) {
				$index = $index + 1;
				$result['data'][$index]['firstName'] = $row['firstName'];
				$result['data'][$index]['lastName'] = $row['lastName'];
				$result['data'][$index]['profileImage'] = $row['profileImage'];
			}
			$result['status'] = "1";
			$result['message'] = "Data found successfully";
		} else {
			$result['status'] = "2";
			$result['message'] = "No data available";
		}

		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['type'] = "0";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>$App_Name Provides 100% Withdraw to All Users.</marquee>";

		// $result['miniAds']['image'] = "https://mycashbazar.com/ExtraImages/iphone13.png";
		// $result['miniAds']['screenNo'] = "2";
		// $result['miniAds']['id'] = "58";
		// $result['miniAds']['url'] = "https://sportsgurupro.com/TaskOffers/";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['btnColor'] = "#4530b3";
		$result['btnTextColor'] = "#FFFFFF";
		$result['btnName'] = "Play Game & Earn More";

		$result['winPoint1'] = "500";
		$result['winPoint2'] = "300";
		$result['winPoint3'] = "100";

		$this->response($this->json($result), 200);
	}
	//getAdjoeLeaderboardHistory
	private function RIVER()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name;
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$result = array();
		$perpage = 20;
		$PAGE_NO = $Details['WSODYJ'];
		$deviseId = $Details['SUBW5V'];
		$adId = $Details['T0TQQ4'];
		$deviceName = $Details['G6H7BT'];
		$appVersion = $Details['A25CIW'];
		$todayOpen = $Details['6GJG3X'];
		$totalOpen = $Details['DRSKLK'];

		$calc = $perpage * $PAGE_NO;
		$start = $calc - $perpage;

		$sql1 = mysqli_query($this->db, "SELECT id FROM tbl_adjoe_leaderboard_history");
		$total = mysqli_num_rows($sql1);
		if ($total > 0) {
			$adjoeData = mysqli_query($this->db, "SELECT * FROM tbl_adjoe_leaderboard_history ORDER BY id DESC LIMIT " . $start . "," . $perpage . " ");
			//$result['QRY'] =  "SELECT * FROM tbl_adjoe_leaderboard_history ORDER BY id DESC LIMIT " . $start . "," . $perpage . " ";
			$NumRows = mysqli_num_rows($adjoeData);
			if ($NumRows > 0) {
				$totalPages = ceil($total / $perpage);
				$result['totalPage'] = $totalPages;
				$result['totalIteam'] = $total;
				$result['currentPage'] = $PAGE_NO;
				$result['message'] = "Data Found Sucessfully.";
				$result['status'] = "1";

				while ($rlContest = mysqli_fetch_array($adjoeData, MYSQLI_ASSOC)) {
					$rlContest['data'] = json_decode($rlContest['data']);
					$result['historyData'][] = $rlContest;
				}
			} else {
				$result['status'] = "2";
				$result['message'] = "No data available";
			}
		} else {
			$result['status'] = "2";
			$result['message'] = "No data available";
		}


		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['type'] = "0";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>$App_Name Provides 100% Withdraw to All Users.</marquee>";

		// $result['miniAds']['image'] = "https://mycashbazar.com/ExtraImages/iphone13.png";
		// $result['miniAds']['screenNo'] = "2";
		// $result['miniAds']['id'] = "58";
		// $result['miniAds']['url'] = "https://sportsgurupro.com/TaskOffers/";

		$result['adFailUrl'] = "https://sportsgurupro.com";


		$this->response($this->json($result), 200);
	}


	//getMinesweeper
	private function MIRJAPUR()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$userId = $Details['KQIDOJ'];
		$ipaddress = $this->getIp();
		$result = array();
		$totalGameCount = "3";
		$remainGameCount = "10";
		$points = "0";

		$result['totalGameCount'] = $totalGameCount;
		$result['points'] = $points;
		$result['gameTime'] = "60";
		$result['nextGameTimer'] = "1";
		$result['mainNote'] = "Grab points without touching any mines!";
		$result['helpVideoUrl'] = "";
		$mine = array(
			array("id" => "1", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "2", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "3", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "4", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "5", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "6", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "7", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "8", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "33", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "34", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),


			array("id" => "9", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "10", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "11", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "12", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "13", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "14", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "35", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "36", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),



			array("id" => "15", "icon" => "https://cashbackzone.app/App/AppImage/moduals/2.png", "count" => "2"),
			array("id" => "16", "icon" => "https://cashbackzone.app/App/AppImage/moduals/2.png", "count" => "2"),
			array("id" => "17", "icon" => "https://cashbackzone.app/App/AppImage/moduals/2.png", "count" => "2"),
			array("id" => "18", "icon" => "https://cashbackzone.app/App/AppImage/moduals/2.png", "count" => "2"),

			array("id" => "19", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),
			array("id" => "20", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),
			array("id" => "21", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),
			array("id" => "22", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),
			array("id" => "23", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),

			array("id" => "24", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),
			array("id" => "25", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),
			array("id" => "26", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),
			array("id" => "27", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),
			array("id" => "28", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),

			array("id" => "29", "icon" => "https://cashbackzone.app/App/AppImage/moduals/0.png", "count" => "0"),
			array("id" => "30", "icon" => "https://cashbackzone.app/App/AppImage/moduals/0.png", "count" => "0"),
			array("id" => "31", "icon" => "https://cashbackzone.app/App/AppImage/moduals/0.png", "count" => "0"),
			array("id" => "32", "icon" => "https://cashbackzone.app/App/AppImage/moduals/0.png", "count" => "0"),





		);

		shuffle($mine);
		$result["data"] = $mine;
		if (strlen($userId) > 0) {
			$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM minesweeper_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");

			$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
			if ($totalTodayCount < $totalGameCount) {
				$result['status'] = "1";
				$result['message'] = "Data found successfully";
			} else {
				$result['message'] = "You have exhausted today's MineSweeper Game limit, please try again tomorrow.";
				$result['status'] = "2";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}


		$result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);


		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Minesweeper Game.";
				$result['taskButton'] = "Complete Easy Task Now";
				//$result['taskId'] = "1";
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}
		// $result['isTodayTaskCompleted'] = "1";

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM minesweeper_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		while ($totalTodayCount > 3) {
			$totalTodayCount = $totalTodayCount - 3;
		}
		if ($totalTodayCount == 2) {
			$result['adType'] = "2"; // small native
		} elseif ($totalTodayCount == 1) {
			$result['adType'] = "1"; // native
		} else {
			$result['adType'] = "3"; // banner
		}
		$result['todayDate'] = date("Y-m-d H:i:s");
		$this->response($this->json($result), 200);
	}

	// saveMinesweeper
	private function DIAMON()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		//$Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['ZW9I58'];
		$userToken = $Details['V3OO74'];
		$adId = $Details['8Y7FYE'];
		$deviceName = $Details['O6BRA8'];
		$totalGameCount = "3";
		$remainGameCount = "10";
		$points = "0";
		$winningPoints = $Details['QX8Y6W'];
		$result['totalGameCount'] = $totalGameCount;
		$result['points'] = $points;
		$mine = array(
			array("id" => "1", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "2", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "3", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "4", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "5", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "6", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "7", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "8", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "33", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),
			array("id" => "34", "icon" => "https://cashbackzone.app/App/AppImage/moduals/bomb.json", "count" => "b"),

			array("id" => "9", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "10", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "11", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "12", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "13", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "14", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "35", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),
			array("id" => "36", "icon" => "https://cashbackzone.app/App/AppImage/moduals/1.png", "count" => "1"),

			array("id" => "15", "icon" => "https://cashbackzone.app/App/AppImage/moduals/2.png", "count" => "2"),
			array("id" => "16", "icon" => "https://cashbackzone.app/App/AppImage/moduals/2.png", "count" => "2"),
			array("id" => "17", "icon" => "https://cashbackzone.app/App/AppImage/moduals/2.png", "count" => "2"),
			array("id" => "18", "icon" => "https://cashbackzone.app/App/AppImage/moduals/2.png", "count" => "2"),

			array("id" => "19", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),
			array("id" => "20", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),
			array("id" => "21", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),
			array("id" => "22", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),
			array("id" => "23", "icon" => "https://cashbackzone.app/App/AppImage/moduals/3.png", "count" => "3"),

			array("id" => "24", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),
			array("id" => "25", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),
			array("id" => "26", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),
			array("id" => "27", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),
			array("id" => "28", "icon" => "https://cashbackzone.app/App/AppImage/moduals/4.png", "count" => "4"),

			array("id" => "29", "icon" => "https://cashbackzone.app/App/AppImage/moduals/0.png", "count" => "0"),
			array("id" => "30", "icon" => "https://cashbackzone.app/App/AppImage/moduals/0.png", "count" => "0"),
			array("id" => "31", "icon" => "https://cashbackzone.app/App/AppImage/moduals/0.png", "count" => "0"),
			array("id" => "32", "icon" => "https://cashbackzone.app/App/AppImage/moduals/0.png", "count" => "0"),
		);

		$agent = $_SERVER['HTTP_USER_AGENT'];

		shuffle($mine);
		$result["data"] = $mine;
		$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayTask = mysqli_num_rows($sql1);
		// $totalTodayTask = 1;

		if (strlen($userToken) > 0 && $agent == "okhttp/5.0.0-alpha.2" && $totalTodayTask > 0 && (int)$winningPoints < 22) {
			if (strlen($userId) > 0 && (int)$userId > 0) {
				$datetime = date("Y-m-d H:i:s");
				$timestamp = strtotime($datetime);
				$time = $timestamp - (75);
				$datetime1 = date("Y-m-d H:i:s", $time);

				$scratchCardList1 = mysqli_query($this->db, "SELECT id FROM minesweeper_history WHERE userId = '" . $userId . "' AND entryDate > '" . $datetime1 . "'  ");

				if (mysqli_num_rows($scratchCardList1) > 0) {
					$result['message'] = "Something Went Wrong, Try Again After Sometime";
					$result['status'] = "0";
				} else {
					$lastDate = "2019-10-17 07:27:37";
					$sqlLastDate = mysqli_query($this->db, "SELECT entryDate FROM minesweeper_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1 ");
					if ($sqlLastDate->num_rows > 0) {
						$rowewf1 = $sqlLastDate->fetch_assoc();
						$lastDate = $rowewf1['entryDate'];
					}
					$currenttime1 = date('Y-m-d H:i:s');
					$start_datetime = new DateTime($lastDate);
					$diff = $start_datetime->diff(new DateTime($currenttime1));
					$minutes = $diff->i;

					if ($winningPoints != '' && (int)$winningPoints < 40 && (int)$minutes >= 1) {
						$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM minesweeper_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
						$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);

						if ($totalTodayCount < $totalGameCount) {
							$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");

							if ($sqlRederID->num_rows > 0) {
								$rowewf = $sqlRederID->fetch_assoc();
								$earning_point = $rowewf['earningPoint'];
								$token = $rowewf['token'];
								$adId2 = $rowewf['adId'];
								$userToken2 = $rowewf['userToken'];

								if ($userToken == $userToken2) {
									$sqinsert = mysqli_query($this->db, "INSERT INTO minesweeper_history(userId, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
									if ($sqinsert === TRUE) {
										if ((int)$winningPoints > 0) {
											$finalearning_point = (int)$earning_point + (int)$winningPoints;
											$tid = $this->gen_uuid();
											$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '38', '1','" . $finalearning_point . "','Minesweeper Game')");

											$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");
											if ($sqlwalletupdate === TRUE) {
												$result['winningPoints'] = $winningPoints;
												$result['earningPoint'] = $finalearning_point;
												$result['message'] = "Data Found Sucessfully.";
												$result['status'] = "1";
												$result['userToken'] = $tid;
											} else {
												$result['message'] = "Something went wrong.";
												$result['status'] = "0";
											}
										} else {
											$result['winningPoints'] = $winningPoints;
											$result['earningPoint'] = $earning_point;
											$result['message'] = "Data Found Sucessfully.";
											$result['status'] = "1";
										}
									} else {
										$result['message'] = "Something went wrong.";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong. Login Again";
									$result['status'] = "5";
								}
							} else {
								$result['message'] = "Something went wrong, please try again later.";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "You have exhausted today's MineSweeper Game limit, please try again tomorrow.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "Something went wrong, please try again later.1";
						$result['status'] = "0";
					}
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later";
			$result['status'] = "0";
		}

		$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM minesweeper_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
		$result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);
		$result['nextGameTimer'] =  "1"; //seconds

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM minesweeper_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		//$result['adType'] =  Rand(1,3);
		while ($totalTodayCount > 3) {
			$totalTodayCount = $totalTodayCount - 3;
		}
		if ($totalTodayCount == 2) {
			$result['adType'] = "2"; // small native
		} elseif ($totalTodayCount == 1) {
			$result['adType'] = "1"; // native
		} else {
			$result['adType'] = "3"; // banner
		}
		// $result['helpVideoUrl'] = $Youtube_url;
		$result['todayDate'] = date("Y-m-d H:i:s");
		$this->response($this->json($result), 200);
	}


	//getAtoZType()	
	private function TRAIN()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		//$Details = json_decode($this->_request['details'], true);
		// $decrypted = PHP_AES_Cipher::decrypt(self::Mkey, $this->_request['details']);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$userId = $Details['RYYVLW'];
		$ipaddress = $this->getIp();
		$result = array();
		$totalGameCount = "3";
		//$totalCount = "3";
		$remainGameCount = "5";



		$points = "10";
		$result['todayDate'] = date("Y-m-d H:i:s");
		$result['totalGameCount'] = $totalGameCount;
		$result['points'] = $points;
		$result['gameTime'] = "30"; //second
		$result['nextGameTime'] =  "1";

		$data = array(
			array("id" => "1", "value" => "A"),
			array("id" => "2", "value" => "B"),
			array("id" => "3", "value" => "C"),
			array("id" => "4", "value" => "D"),
			array("id" => "5", "value" => "E"),
			array("id" => "6", "value" => "F"),
			array("id" => "7", "value" => "G"),
			array("id" => "8", "value" => "H"),
			array("id" => "9 ", "value" => "I"),
			array("id" => "10", "value" => "J"),
			array("id" => "11", "value" => "K"),
			array("id" => "12", "value" => "L"),
			array("id" => "13", "value" => "M"),
			array("id" => "14", "value" => "N"),
			array("id" => "15", "value" => "O"),
			array("id" => "16", "value" => "P"),
			array("id" => "17", "value" => "Q"),
			array("id" => "18", "value" => "R"),
			array("id" => "19", "value" => "S"),
			array("id" => "20", "value" => "T"),
			array("id" => "21", "value" => "U"),
			array("id" => "22", "value" => "V"),
			array("id" => "23", "value" => "W"),
			array("id" => "24", "value" => "X"),
			array("id" => "25", "value" => "Y"),
			array("id" => "26", "value" => "Z")

		);
		shuffle($data);
		$result['data'] = $data;

		if (strlen($userId) > 0) {
			$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM a_z_type WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			if ($totalTodayPlayCount->num_rows > 0) {
				$rowewf1 = $totalTodayPlayCount->fetch_assoc();
				$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
				if ($totalTodayCount < $totalGameCount) {

					$result['status'] = "1";
					$result['message'] = "Data found successfully";
				} else {

					$result['message'] = "You have exhausted today's A To Z Type game limit, please try again tomorrow.";
					$result['status'] = "2";
				}
			} else {

				$result['status'] = "1";
				$result['message'] = "First time Data found successfully";
			}
			$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
			if ($sqlRederID->num_rows > 0) {
				$rowewf = $sqlRederID->fetch_assoc();
				$userToken2 = $rowewf['userToken'];
				$result['userToken'] = $userToken2;
			}
		} else {
			//$result['makeTotal']=rand(3,18);
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock A To Z Type Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "31";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock A To Z Type Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}


		$result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);


		$result['adFailUrl'] = "https://sportsgurupro.com";




		// $result['isTodayTaskCompleted'] = "1"; // by default keep this OFF, When want to enable

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM a_z_type WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		//$result['lastDate'] = "2019-10-17 07:27:37";
		$this->response($this->json($result), 200);
	}


	//saveAtoZType
	private function BUS()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		//  $Details = json_decode($this->_request['details'], true);
		// $decrypted = PHP_AES_Cipher::decrypt(self::Mkey, $this->_request['details']);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		// $encrypt = $this->_request['details'];
		// $isencrypted = '1';
		// $name="saveAtoZType";
		// $log['log'] = $this->log($encrypt, $name, $isencrypted);
		$userId = $Details['58X4JQ'];
		$userToken = $Details['72WDVY'];
		$adId = $Details['E8BHSH'];
		$deviceName = $Details['8T0WGJ'];
		$winningPoints = $Details['C7WUNH'];
		$totalGameCount = "3";
		$remainGameCount = "5";
		$points = "10";

		$result['details'] = $Details;
		$result['totalGameCount'] = $totalGameCount;
		$result['points'] = "10";
		$result['todayDate'] = date("Y-m-d H:i:s");


		$RANDOM = $Details['9JXWQI'];
		$headers = apache_request_headers();
		if ($headers['Token'] != $userToken || $headers['Secret'] != $RANDOM) {
			die();
		}


		$data = array(
			array("id" => "1", "value" => "A"),
			array("id" => "2", "value" => "B"),
			array("id" => "3", "value" => "C"),
			array("id" => "4", "value" => "D"),
			array("id" => "5", "value" => "E"),
			array("id" => "6", "value" => "F"),
			array("id" => "7", "value" => "G"),
			array("id" => "8", "value" => "H"),
			array("id" => "9 ", "value" => "I"),
			array("id" => "10", "value" => "J"),
			array("id" => "11", "value" => "K"),
			array("id" => "12", "value" => "L"),
			array("id" => "13", "value" => "M"),
			array("id" => "14", "value" => "N"),
			array("id" => "15", "value" => "O"),
			array("id" => "16", "value" => "P"),
			array("id" => "17", "value" => "Q"),
			array("id" => "18", "value" => "R"),
			array("id" => "19", "value" => "S"),
			array("id" => "20", "value" => "T"),
			array("id" => "21", "value" => "U"),
			array("id" => "22", "value" => "V"),
			array("id" => "23", "value" => "W"),
			array("id" => "24", "value" => "X"),
			array("id" => "25", "value" => "Y"),
			array("id" => "26", "value" => "Z")

		);
		shuffle($data);
		$result['data'] = $data;


		if (strlen($userToken) > 0) {
			if (strlen($userId) > 0 && (int)$userId > 0) {

				$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
				$totalTodayTask = mysqli_num_rows($sql1);

				if ($totalTodayTask > 0) {

					$datetime = date("Y-m-d H:i:s");
					$timestamp = strtotime($datetime);
					$time = $timestamp - (60);
					$datetime1 = date("Y-m-d H:i:s", $time);

					$scratchCardList1 = mysqli_query($this->db, "SELECT id FROM a_z_type WHERE userId = '" . $userId . "' AND entryDate > '" . $datetime1 . "'  ");

					if (mysqli_num_rows($scratchCardList1) > 0) {
						$result['message'] = "Something Went Wrong, Try Again After Sometime";
						$result['status'] = "0";
					} else {
						if ($winningPoints == '0' || $winningPoints == $points) {
							$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM a_z_type WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
							$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
							if ($totalTodayCount < $totalGameCount) {
								$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken,deviceName FROM user_master WHERE userId = '" . $userId . "' ");
								if ($sqlRederID->num_rows > 0) {
									$rowewf = $sqlRederID->fetch_assoc();
									$earning_point = $rowewf['earningPoint'];
									$token = $rowewf['token'];
									$adId2 = $rowewf['adId'];
									$userToken2 = $rowewf['userToken'];
									$deviceName1 = $rowewf['deviceName'];

									if ($userToken == $userToken2 && $deviceName == $deviceName1) {
										$sqinsert = mysqli_query($this->db, "INSERT INTO a_z_type(userId, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
										$result['sqinsert'] = "INSERT INTO a_z_type(userId, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )";

										if ($sqinsert === TRUE) {
											if ((int)$winningPoints > 0) {
												$finalearning_point = (int)$earning_point + (int)$winningPoints;
												$tid = $this->gen_uuid();
												$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '39', '1','" . $finalearning_point . "','Alphabet Game')");

												$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "', userToken='" . $tid . "' WHERE userId = '" . $userId . "'");


												if ($sqlwalletupdate === TRUE) {
													$result['winningPoints'] = $winningPoints;
													$result['earningPoint'] = $finalearning_point;
													$result['message'] = "Data Found Sucessfully.";
													$result['status'] = "1";
													$result['userToken'] = $tid;
												} else {
													$result['message'] = "Something went wrong.1";
													$result['status'] = "0";
												}
											} else {
												$result['winningPoints'] = $winningPoints;
												$result['earningPoint'] = $earning_point;
												$result['message'] = "Data Found Sucessfully.";
												$result['status'] = "1";
											}
										} else {
											$result['message'] = "Something went wrong.2";
											$result['status'] = "0";
										}
									} else {
										$result['message'] = "Something went wrong. Login Again11";
										$result['status'] = "5";
									}
								} else {
									$result['message'] = "Something went wrong, please try again later.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "You have exhausted today's A To Z Type Game limit, please try again tomorrow.";
								$result['status'] = "2";
							}
						} else {
							$result['message'] = "Something went wrong, please try again later.11";
							$result['status'] = "0";
						}
					}
				} else {
					$result['message'] = "You have not completed today's Task & Game";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later.111";
			$result['status'] = "0";
		}

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM a_z_type WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		}


		$totalTodayPlayCount = mysqli_query($this->db, "SELECT * FROM a_z_type  WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
		$totalTodayCount = mysqli_num_rows($totalTodayPlayCount);
		$result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);
		$result['gameTime'] = "30";
		$result['nextGameTime'] =  "1"; //seconds
		// $result['helpVideoUrl'] = "https://www.youtube.com/@PocketReward";
		$this->response($this->json($result), 200);
	}

	//savequicktask 
	private function LION()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		// $Details = json_decode($this->_request['details'], true);

		$userId = $Details['EG0FIH'];
		$ids = $Details['CIR5EK'];
		$points = $Details['W13OXJ'];
		$points = 10;
		if ($ids == '1') {
			$EarningType = '41';
		} elseif ($ids == '2') {
			$EarningType = '42';
		}

		if ($ids == "1" || $ids == "2") {
			if (strlen($userId) > 0  && $points > 0) {
				$already_querry = mysqli_query($this->db, "SELECT * FROM quicktask_history WHERE ids = '" . $ids . "' AND userId = '" . $userId . "'  ");
				// $already_querry2 = mysqli_query($this->db, "SELECT * FROM quicktask_history WHERE ids = '2'  ");
				if ($already_querry->num_rows > 0) {
					$result['message'] = "You Have Already Claimed This Reward";
					$result['status'] = "0";
				} else {
					$ep1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "'  ");
					$ep = $ep1->fetch_assoc();
					$earning_point = $ep['earningPoint'];
					$finalearning_point = (int)$earning_point + (int)$points;

					$sqinsert = mysqli_query($this->db, "INSERT INTO quicktask_history (userId,ids,points) VALUES ('" . $userId . "', '" . $ids . "', '" . $points . "') ");

					$earning_point_master_querry = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $points . "', '" . $EarningType . "','1','" . $finalearning_point . "','Quick Task')");

					if ($sqinsert && $earning_point_master_querry) {
						$tid = $this->gen_uuid();
						$result['userToken'] = $tid;
						$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , userToken = '" . $tid . "' WHERE userId = '" . $userId . "'  ");
						if ($sqlwalletupdate) {
							$result['message'] = "Data Found Sucessfully";
							$result['earningPoint'] = $finalearning_point;
							$result['status'] = "1";
						} else {
							$result['message'] = "Something went wrong.Q.wallet";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "Something went wrong.Q.Hist";
						$result['status'] = "0";
					}
				}
			} else {
				$result['message'] = "Something went wrong .user";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong1.";
			$result['status'] = "0";
		}
		$this->response($this->json($result), 200);
	}

	//getWalletBalance
	private function TIGER()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['THQCZQ'];


		if (strlen($userId) > 0 && (int)$userId > 0) {
			$sqlRederID = mysqli_query($this->db, "SELECT isActive FROM user_master WHERE userId = '" . $userId . "' ");
			if ($sqlRederID->num_rows > 0) {
				$rowewf = $sqlRederID->fetch_assoc();
				$status = $rowewf['isActive'];
				if ($status == '3') {
					$result['message'] = "Error";
					$result['status'] = "5";
				} else {
					$sqlRederID1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "' ");
					if ($sqlRederID1->num_rows > 0) {
						$rowewf1 = $sqlRederID1->fetch_assoc();
						$result['earningPoint'] = $rowewf1['earningPoint'];
						$result['message'] = "Sucess";
						$result['status'] = "1";
					} else {
						$result['message'] = "Error";
						$result['status'] = "0";
					}
				}
			} else {
				$result['message'] = "Data not Found";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}
		$this->response($this->json($result), 200);
	}


	// SaveDailyTarget
	private function KIMCHI()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $Youtube_url;
		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d");
		$result = array();
		$userId = $Details['BQGBWJ'];
		$milestoneId = $Details['L46V8I'];
		$adId = $Details['QSEBPG'];
		$deviceId = $Details['3K9QBS'];
		$deviceName = $Details['MLYDSI'];
		$winningPoints = $Details['QNYR1O'];
		$userToken = $Details['OJWLR2'];

		// $sql1= mysqli_query($this->db,"SELECT id FROM earning_point_master WHERE userId = '".$userId."'  AND earning_type IN('2','17','23')");
		//    if ($sql1->num_rows > 0) 
		//     {
		if (strlen($userId) > 0 && (int)$userId > 0) {
			$isClaimed = mysqli_query($this->db, "SELECT * FROM tbl_daily_target_history WHERE milestoneId = '" . $milestoneId . "' AND userId = '" . $userId . "' AND entryDate LIKE '%" . $date . "%'");
			if (mysqli_num_rows($isClaimed) == 0) {
				$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,adId,isActive FROM user_master WHERE userId = '" . $userId . "' ");
				if ($sqlRederID->num_rows > 0) {
					$rowewf = $sqlRederID->fetch_assoc();
					$earning_point = $rowewf['earningPoint'];
					$adId2 = $rowewf['adId'];

					$milestonePoints = 0;
					$milestoneData = mysqli_query($this->db, "SELECT * FROM tbl_daily_target WHERE id = '" . $milestoneId . "' AND isActive = '1'");
					if (mysqli_num_rows($milestoneData) > 0) {
						$rlt = $milestoneData->fetch_assoc();
						$milestonePoints = $rlt['points'];
						if ((int)$winningPoints == (int)$milestonePoints) {

							$type = $rlt['type'];
							$earningType = $rlt['earningType'];
							$completionPercent = 0;
							$comments = "Daily Target";
							if ($earningType == '11') // 11 = tasks
							{
								$comments = "Daily Target - Task";
								$taskQry = "SELECT count(id),sum(points) FROM cpalead WHERE userId = '" . $userId . "'  AND  entryDate LIKE '%" . $date . "%'";
								$taskData = mysqli_query($this->db, $taskQry);
							} elseif ($earningType == '40') // 40 = Pubscale Offers
							{
								$comments = "Daily Target - Offers";
								$taskQry = "SELECT count(id),sum(coin_amount) FROM pubscale_history WHERE userId = '" . $userId . "' AND  entryDate LIKE '%" . $date . "%'";
								$taskData = mysqli_query($this->db, $taskQry);
							} elseif ($earningType == '24') // 24 = playtime adjoe (ONLY POINTS)
							{
								$comments = "Daily Target - Games";
								$taskQry = "SELECT count(id),sum(coin_amount) FROM adjoe_history WHERE userId = '" . $userId . "' AND  entryDate LIKE '%" . $date . "%'";
								$taskData = mysqli_query($this->db, $taskQry);
							}
							$taskCusor = mysqli_fetch_array($taskData, MYSQLI_NUM);
							$noOfData = $taskCusor[0];
							$earnedPoints = $taskCusor[1];
							if ($noOfData > 0) {
								if ($type == '0') // 0 = number target
								{
									$completionPercent = ($noOfData * 100) / $rlt['targetNumber'];
								} else { //1 = points target
									$completionPercent = ($earnedPoints * 100) / $rlt['targetPoints'];
								}
							}
							if ($completionPercent >= 100) {
								$sqinsert = mysqli_query($this->db, "INSERT INTO tbl_daily_target_history(milestoneId,userId, points, adId, deviceName, ipAddress, deviceId) VALUES ('" . $milestoneId . "','" . $userId . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' , '" . $deviceId . "')");
								if ($sqinsert === TRUE) {
									$finalearning_point = (int)$earning_point + (int)$winningPoints;

									$tid = $this->gen_uuid();
									$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "',  '" . $winningPoints . "', '43', '1','" . $finalearning_point . "','" . $comments . "')");

									$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");

									if ($sqlwalletupdate === TRUE) {
										$result['winningPoints'] = $winningPoints;
										$result['earningPoint'] = $finalearning_point;
										$result['message'] = "Data Found Sucessfully.";
										$result['status'] = "1";
										$result['userToken'] = $tid;
									} else {
										$result['message'] = "Something went wrong1.";
										$result['status'] = "0";
									}
								} else {
									$result['message'] = "Something went wrong2.";
									$result['status'] = "0";
								}
							} else {
								$result['message'] = "Something went wrong3.";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "Something went wrong4.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "This daily target is expired or it is inactive. Please try to complete other daily target.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Something went wrong, please try again later.";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have already claimed reward for this daily target.";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "0";
		}
		//  } else {
		//     $result['message'] = "Complete task, or scratch card or refer any user to complete daily target";
		//     $result['status'] = "0";
		// }         
		// $result['helpVideoUrl'] = $Youtube_url;

		$this->response($this->json($result), 200);
	}

	//deleteAccount
	private function FRONT()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		$token = $Details['ZVWDGL'];
		$userId = $Details['JYG3QS'];
		$appVersion = $Details['KIU3T7'];
		$deviceName = $Details['O7EXPN'];
		$deviseId = $Details['57HIGT'];
		$adId = $Details['O9EINO'];
		$todayOpen = $Details['UQ3LXW'];
		$totalOpen = $Details['6QNQDW'];
		$dayy = $Details['4SA4LI'];
		$ipaddress = $this->getIp();
		$date = date('Y-m-d');
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$result = array();
		$TodayOnlydate = date('Y-m-d');

		if ($userId > 0) {
			$sql = "UPDATE user_master SET isActive = '2' WHERE userId ='" . $userId . "' ";
			$sqinsert = mysqli_query($this->db, $sql);
			if ($sqinsert === TRUE) {
				$result['message'] = "Your account data is deleted.";
				$result['status'] = "1";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later.";
			$result['status'] = "0";
		}

		$this->response($this->json($result), 200);
	}

	private function CheckMobileNo()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$Details = json_decode($this->_request['details'], true);
		$DeviceId = $Details['device_id'];
		$mobileNumber = $Details['mobileNumber'];
		$result = array();

		$setting = mysqli_query($this->db, "SELECT userId FROM user_master WHERE  mobileNumber = '" . $mobileNumber . "' ");
		if ($setting->num_rows > 0) {
			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";
		} else {
			$result['message'] = "Please Login/Signup With emailId.";
			$result['status'] = "0";
		}
		$this->response($this->json($result), 200);
	}

	private function shorten_URL($longUrl)
	{
		global $App_Name, $app_logo, $PackageName;

		$key = 'AIzaSyD_QK-ka7sWe2cc48Us8aTKXsc44CmHjyE';
		$url = 'https://firebasedynamiclinks.googleapis.com/v1/shortLinks?key=' . $key;
		$data = array(
			"dynamicLinkInfo" => array(
				"dynamicLinkDomain" => "$App_Name.page.link",
				"link" => $longUrl,
				"androidInfo" =>  array("androidPackageName" => $PackageName),
				"socialMetaTagInfo" => array(
					"socialTitle" => "$App_Name : Your Earning Partner",
					"socialDescription" => "$App_Name is one of the BEST money earning and most trusted App in India.",
					"socialImageLink" => $app_logo
				)
			),
			"suffix" => array(
				"option" => "UNGUESSABLE"
			)
		);

		$headers = array('Content-Type: application/json');

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

		$data = curl_exec($ch);
		curl_close($ch);

		$short_url = json_decode($data);
		if (isset($short_url->error)) {
			return "";
		} else {
			return $short_url->shortLink;
		}
	}


	function dateDiffInDays($date1, $date2)
	{

		$diff = strtotime($date2) - strtotime($date1);
		return abs(round($diff / 86400));
	}


	function getLocationInfoByIp()
	{
		$client  = @$_SERVER['HTTP_CLIENT_IP'];
		$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote  = @$_SERVER['REMOTE_ADDR'];
		$result  = array('country' => '', 'city' => '');
		if (filter_var($client, FILTER_VALIDATE_IP)) {
			$ip = $client;
		} elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
			$ip = $forward;
		} else {
			$ip = $remote;
		}

		$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
		//$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=138.197.222.35"));    
		if ($ip_data && $ip_data->geoplugin_countryName != null) {
			$result['country'] = $ip_data->geoplugin_countryCode;
			$result['city'] = $ip_data->geoplugin_city;
		}

		return $result;
	}


	private function senWithdrawNoChanneSucesslNotiCoupone($token, $point)
	{
		global $Server_key;
		$url = "https://fcm.googleapis.com/fcm/send";
		$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
		$data = array(
			'to' => $token,
			"content_available" => true,
			"mutable_content" => true,
			'priority' => 'high',
			'data' => array(
				"Notification_Id" => rand(10, 100),
				"title" => "Your Withdraw Request Sucessfully Credit in your redeem history.",
				"description" => "Please Check your redeem history for redeem coupon code.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "coin",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default',
				"is_background" => false,
				"payload" => array(
					"my-data-item" => "my-data-value"
				),
				"timestamp" => date('Y-m-d G:i:s')
			)
		);

		$content = json_encode($data);

		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array(
			"Content-type: application/json",
			"Authorization: key=" . $Server_key . ""
		));
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		curl_exec($curl);
		curl_close($curl);
	}



	private function senWithdrawNoChanneSucesslNoti($token, $point)
	{
		global $Server_key;
		$url = "https://fcm.googleapis.com/fcm/send";
		$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
		$data = array(
			'to' => $token,
			"content_available" => true,
			"mutable_content" => true,
			'priority' => 'high',
			'data' => array(
				"Notification_Id" => rand(10, 100),
				"title" => "We have transferred money to your Paytm wallet successfully.",
				"description" => "Please check your paytm wallet. Give 5 Star tatings & review on playstore.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "paytm",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default',
				"is_background" => false,
				"payload" => array(
					"my-data-item" => "my-data-value"
				),
				"timestamp" => date('Y-m-d G:i:s')
			)
		);

		$content = json_encode($data);

		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array(
			"Content-type: application/json",
			"Authorization: key=" . $Server_key . ""
		));
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		curl_exec($curl);
		curl_close($curl);
	}


	private function senWithdrawNoChanneSucesslNotiQR($token, $point)
	{
		global $Server_key;
		$url = "https://fcm.googleapis.com/fcm/send";
		$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
		$data = array(
			'to' => $token,
			"content_available" => true,
			"mutable_content" => true,
			'priority' => 'high',
			'data' => array(
				"Notification_Id" => rand(10, 100),
				"title" => "We have transferred money to your merchant bank successfully.",
				"description" => "",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "success",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default',
				"is_background" => false,
				"payload" => array(
					"my-data-item" => "my-data-value"
				),
				"timestamp" => date('Y-m-d G:i:s')
			)
		);

		$content = json_encode($data);

		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array(
			"Content-type: application/json",
			"Authorization: key=" . $Server_key . ""
		));
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		curl_exec($curl);
		curl_close($curl);
	}


	private function refreFrendNoti($token, $point)
	{
		global $Server_key;
		$url = "https://fcm.googleapis.com/fcm/send";
		$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
		$data = array(
			'to' => $token,
			"content_available" => true,
			"mutable_content" => true,
			'priority' => 'high',
			'data' => array(
				"Notification_Id" => rand(10, 100),
				"title" => $point . " Free Points received!",
				"description" => "Your friend has signed up with your referral code.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "coin",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default',
				"is_background" => false,
				"payload" => array("my-data-item" => "my-data-value"),
				"timestamp" => date('Y-m-d G:i:s')
			)
		);

		$content = json_encode($data);

		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-type: application/json",
				"Authorization: key=" . $Server_key . ""
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		curl_exec($curl);
		curl_close($curl);
	}



	private function sendDailyLoginNoti($token, $point)
	{
		global $Server_key;
		$image = "";

		$flip1 = rand(0, 10);

		if ($flip1 == '1') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/259_newvideo.jpg";
		} else if ($flip1 == '2') {
			$image = "https://mycashbazar.com/admin/images/homeslider/85_taskkarorearnkaro.png";
		} else if ($flip1 == '3') {
			$image = "https://mycashbazar.com/admin/images/homeslider/20_smallads.png";
		} else if ($flip1 == '4') {
			$image = "https://mycashbazar.com/admin/images/homeslider/81_2INR.png";
		} else if ($flip1 == '5') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/728_refervideo.png";
		} else if ($flip1 == '6') {
			$image = "https://mycashbazar.com/admin/images/homeslider/81_2INR.png";
		} else if ($flip1 == '7') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/476_Minmimamwithdrawnew.jpg";
		} else if ($flip1 == '8') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/427_sdsdsd.png";
		} else if ($flip1 == '9') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/672_ewwewewe.jpg";
		}

		$url = "https://fcm.googleapis.com/fcm/send";
		$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
		$data = array(
			'to' => $token,
			"content_available" => true,
			"mutable_content" => true,
			'priority' => 'high',
			'data' => array(
				"Notification_Id" => rand(10, 100),
				"title" => "Congratulations!",
				"description" => $point . " Points has been credited in your wallet.",
				"notificationDate" => date('Y-m-d'),
				"image" => $image,
				"screenNo" => "0",
				"icon" => "coin",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"type" => "1",
				"badge" => '1',
				"sound" => 'default',
				"is_background" => false,
				"payload" => array("my-data-item" => "my-data-value"),
				"timestamp" => date('Y-m-d G:i:s')
			)
		);

		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-type: application/json",
				"Authorization: key=" . $Server_key . ""


			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		curl_exec($curl);
		curl_close($curl);
	}

	private function Hello()
	{
		if ($this->get_request_method() != "GET") {
			$this->response('', 406);
		}
		$result[] = array('Hello' => "Milan Pambhar");
		$this->response($this->json($result), 200);
	}

	private function json($data)
	{
		// $encrypt = MCrypt::encrypt(json_encode($data));
		$mcrypt = new MCrypt();
		$encrypted = $mcrypt->encrypt(json_encode($data));
		// $data= array();
		$data['encrypt'] = $encrypted;
		if (is_array($data)) {
			return json_encode($data);
		}
	}



	function getIp()
	{
		$ip = $_SERVER['REMOTE_ADDR'];
		if ($ip) {
			if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
				$ip = $_SERVER['HTTP_CLIENT_IP'];
			} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
				$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
			}
			return $ip;
		}
		return false;
	}


	function startsWith($haystack, $needle)
	{
		$length = strlen($needle);
		return (substr($haystack, 0, $length) === $needle);
	}
}
$api = new API;
$api->processApi();


class MCrypt
{


	public $iv = 'saybsr237lf25387'; #Same as in JAVA
	public $key = 'bsrbsr237lf25vsr'; #Same as in JAVA
	function __construct()
	{
	}



	function encrypt($str)
	{

		global $encryptionMethod, $secretHash, $iv;

		$td = mcrypt_module_open($encryptionMethod, '', 'cbc', $iv);

		mcrypt_generic_init($td, $secretHash, $iv);
		$encrypted = mcrypt_generic($td, $str);

		mcrypt_generic_deinit($td);
		mcrypt_module_close($td);

		return bin2hex($encrypted);
	}

	static function decrypt($code)
	{
		global $encryptionMethod, $secretHash, $iv;

		$code = hex2bin($code);

		$td = mcrypt_module_open($encryptionMethod, '', 'cbc', $iv);

		mcrypt_generic_init($td, $secretHash, $iv);
		$decrypted = mdecrypt_generic($td, $code);

		mcrypt_generic_deinit($td);
		mcrypt_module_close($td);

		return utf8_encode(trim($decrypted));
	}


	function hex2bin($hexdata)
	{
		$bindata = '';
		for ($i = 0; $i < strlen($hexdata); $i += 2) {
			$bindata .= chr(hexdec(substr($hexdata, $i, 2)));
		}
		return $bindata;
	}
}
