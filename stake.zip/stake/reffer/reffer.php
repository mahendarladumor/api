<?php


if(isset($_GET['code'])){
$code = $_GET['code'];
// $link = "https://rewardwalletapp.page.link/".$code;RewardWalletApps.page.link
$encode=urlencode("utm_source=app_referral&utm_content=".$code);

$link =  "https://play.google.com/store/apps/details?id=game.doublecoin.playgames.payout&referrer=".$encode;

// die();
header("Location: $link");
}
?>