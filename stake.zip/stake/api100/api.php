<?php

require_once("Rest.inc.php");


header("Access-Control-Allow-Methods: POST");
header("Acess-Control-Allow-Origin: *");
error_reporting(E_ERROR | E_PARSE);


date_default_timezone_set("Asia/Calcutta");

global $encryptionMethod, $iv, $secretHash, $WelcomeBonusPoint, $charges, $minAmontCharger, $pointvalue,$app_logo;
$app_logo="https://judoapps.com/Stake/Api/images/lucylogo.png";
$pointvalue="10";
$encryptionMethod = "rijndael-128";
$secretHash = "okm8uhbvgy789ijn";
$iv = 'maj9ki765g7hjm8j';
$WelcomeBonusPoint = "200";
$minAmontCharger = 10;

$charges = 120;



// ini_set('display_errors', 1);	
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

class API extends REST
{
	public $data = "";	
	const DB_SERVER = "localhost";
	const DB_USER = "Stake_db";
	const DB_PASSWORD = "SGxajGEGPR5nrJd6";
	const DB = "stake_db";
	private $db = NULL;
	
	const Miv =  'maj9ki765g7hjm8j'; #Same as in JAVA
	const Mkey = 'okm8uhbvgy789ijn'; #Same as in JAVA
	const isCompleteAdjoeGame = '0'; // This will check adjoe first then will check for task completion

	public function __construct()
	{
		parent::__construct();
		$this->dbConnect();
	}

	private function dbConnect()
	{
		$this->db = mysqli_connect(self::DB_SERVER, self::DB_USER, self::DB_PASSWORD, self::DB);
		$this->db->set_charset('utf8mb4');
	}

	public function processApi()
	{
		if (isset($_REQUEST['rquest']) && $_REQUEST['rquest'] != null) {
			$func = strtolower(trim(str_replace("/", "", $_REQUEST['rquest'])));

			if ((int) method_exists($this, $func) > 0)
				$this->$func();
			else
				$result = array(
					'status' => "0",
					'message' => "Something Wrong"
				);
			$this->response($this->json($result), 404);
		} else {
			$result = array(
				'status' => "0",
				'message' => "Something Wrong"
			);
			$this->response($this->json($result), 404);
		}
	}

	//Login
	private function DSFSFDSC()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $email, $pointvalue;
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		// $Details = json_decode($this->_request['details'],true);
		$result = array();

		$ipaddress = $this->getIp();
		$appVersion = $Details['7654RFD'];
		$deviceName = $Details['45F6GH'];
		$deviseId = $Details['78U6Y5TR'];
		$adId = $Details['JHGT4EF'];
		$todayOpen = $Details['6GT5RFED'];
		$totalOpen = $Details['76HY5GTRF'];
		$deviceVersion = $Details['H6G5RF4'];
		$deviceType = $Details['76Y5T4RE'];
		$emailId = $Details['DSRE4543'];
		$firstName = $Details['K7J6YH5TGRF'];
		$profileImage = $Details['435EWR'];
		$countryCode = "91";
		// $countryCode = $Details['countryCode'];
		$lastName = $Details['GFD34D'];
		$loginType = "";
		$mobileNumber = "0000000000";
		$referralCode = $Details['RERTERTE'];
		$deplinkdata = $Details['RET4TRTH'];

		$token = $Details['65TRED'];

		$referral_user_id = "";
		$referral_user_data = array();
		$cashPoint = '0';
		$agent = $_SERVER['HTTP_USER_AGENT'];


		$refeSecurity = "1";

		if ($refeSecurity == '1') {


			if (strlen($referralCode) > 0) {

				if ($referralCode == "D1SJ99" || $referralCode == "8ZV5OP" || $referralCode == "WL9QW2"  || $referralCode == "XQU0US" || $referralCode == "8TBWY5"  || $referralCode == "NMWVU1" || $referralCode == "NFGM9W"  || $referralCode == "CPLSQ8"  || $referralCode == "09QYKW") {
					$flip1 = rand(0, 10);
					if ($flip1 == '3' || $flip1 == '8' || $flip1 == '5' || $flip1 == '6') {

						$referralCode = "";
						$referral_user_id = "";
						$referral_user_data = array();
					}
				}

				//
				if ($referralCode == "SWSENG" || $referralCode == "MODWW5" || $referralCode == "WL9QW2"  || $referralCode == "XQU0US"  || $referralCode == "8TBWY5" || $referralCode == "NFGM9W"  || $referralCode == "09QYKW"    || $referralCode == "D1SJ99") {
					$flip2 = rand(0, 10);
					if ($flip2 == '3' || $flip2 == '5' || $flip2 == '8' || $flip2 == '9') {
						$referralCode = "";
						$referral_user_id = "";
						$referral_user_data = array();
					}
				}
			}

			if ($referralCode == "09QYKW" || $referralCode == "8TBWY5" || $referralCode == "WL9QW2") {
				$flip2 = rand(0, 10);
				if ($flip2 == '3' || $flip2 == '5' || $flip2 == '9') {
					$referralCode = "";
					$referral_user_id = "";
					$referral_user_data = array();
				}
			}



			if (strlen($referralCode) > 0) {

				$sqlRederID = mysqli_query($this->db, "SELECT * FROM user_master WHERE referralCode = '" . $referralCode . "' ");

				if ($sqlRederID->num_rows > 0) {

					$rowewf = $sqlRederID->fetch_assoc();

					$referral_user_id = $rowewf['userId'];


					$sqlRefrealCount = mysqli_query($this->db, "SELECT COUNT(*) FROM user_master WHERE referralUserId = '" . $referral_user_id . "'  ");
					$row = $sqlRefrealCount->fetch_row();
					if ((int)$row[0] > 200) {

						$flip1 = rand(0, 10);
						if ($flip1 == '3' || $flip1 == '8' || $flip1 == '5' || $flip1 == '4') {
							$referralCode = "";
							$referral_user_id = "";
							$referral_user_data = array();
						} else {
							$referral_user_data = $rowewf;
							$token1 = $rowewf['token'];
							$earningPoint = $rowewf['earningPoint'];
							$referralLink = $rowewf['referralLink'];
						}
					} else {
						$referral_user_data = $rowewf;
						$token1 = $rowewf['token'];
						$earningPoint = $rowewf['earningPoint'];
						$referralLink = $rowewf['referralLink'];
					}

					if ($referralLink == "0") {

						$referral_user_id == "0";

						$referral_user_id = "";

						$referralCode = "";
					}
				}
			}

			if (strlen($emailId) > 0) {

				$sqlEmailId = mysqli_query($this->db, "SELECT * FROM user_master WHERE emailId = '" . $emailId . "' ");
				if ($sqlEmailId->num_rows > 0) {
					$result['userDetails'] = $sqlEmailId->fetch_assoc();
					$result['userDetails']['pointValue'] = $pointvalue;
					$result['userDetails']['adId'] = "";

					if ($result['userDetails']['isActive'] == '1') {
						$result['message'] = "Sucessfully Login.";
						$result['status'] = "1";

						$tid = $this->gen_uuid();
						$result['userDetails']['userToken'] = $tid;
						$result['userToken'] = $tid;
						$result['userDetails']['withdrawMobileNo'] = "";
						mysqli_query($this->db, "UPDATE user_master SET token = '" . $token . "' , userToken = '" . $tid . "', adId = '" . $adId . "', deviceName = '" . $deviceName . "', appVersion = '" . $appVersion . "' WHERE userId = '" . $result['userDetails']['userId'] . "' ");
					} elseif ($result['userDetails']['isActive'] == '2') {
						$result['message'] = "Your account is blocked. Please contact us on $email email address to get solution.";
						$result['status'] = "0";
					} elseif ($result['userDetails']['isActive'] == '3') {
						$result['message'] = "Your account is deleted. Please contact us on $email email address to get solution.";
						$result['status'] = "0";
					} else {
						$result['message'] = "Your account is blocked for some reason. Please contact us on $email email address to get solution.";
						$result['status'] = "0";
					}
				} else {
					$sqlEma = mysqli_query($this->db, "SELECT userId,emailId FROM user_master WHERE  profileImage =  '" . $profileImage . "' ");
					if ($sqlEma->num_rows > 0) {
						$roweE = $sqlEma->fetch_assoc();
						$result['status'] = "0";
						$result['message'] = "This device is alredy registered with " . $roweE['emailId'] . " Email Id. Please login with old account.";
					} else {
						if (strlen($referral_user_id) > 0) {
							$ip1arr = explode(".", $ipaddress);
							$ip2arr = explode(".", $referral_user_data['ipaddress']);
							if (strcasecmp($referral_user_data['deviceName'], $deviceName) == 0  && $ip1arr[0] == $ip2arr[0]) {
								$result['status'] = "0";
								$result['message'] = "Only single account is eligible from single device.";
							} else {
								if ($referral_user_data['deviceName'] == $deviceName) {
									$sqlTotalUser = mysqli_query($this->db, "SELECT deviceName,ipaddress FROM user_master WHERE referralUserId = '" . $referral_user_id . "' ORDER BY userId DESC limit 1");
									if ($sqlTotalUser->num_rows > 0) {
										$RowRefUser = $sqlTotalUser->fetch_assoc();
										if ($RowRefUser['deviceName'] == $deviceName || $RowRefUser['ipaddress'] == $ipaddress) {
											$result['status'] = "0";
											$result['message'] = "Only single account is eligible from single device.";
										} else {
											$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
										}
									} else {

										$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
									}
								} else {

									$sqlTotalUser = mysqli_query($this->db, "SELECT deviceName,ipaddress FROM user_master WHERE referralUserId = '" . $referral_user_id . "' ORDER BY userId DESC limit 1");

									if ($sqlTotalUser->num_rows > 0) {

										$RowRefUser = $sqlTotalUser->fetch_assoc();

										if ($RowRefUser['deviceName'] == $deviceName || $RowRefUser['ipaddress'] == $ipaddress) {

											$result['status'] = "0";

											$result['message'] = "Only single account is eligible from single device.";
										} else {

											$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
										}
									} else {
										$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
									}
								}
							}
						} else {
							$result = $this->RegistorUser($Details, $referral_user_data, $referral_user_id);
						}
					}
				}
			} else {
				$result['status'] = "0";
				$result['mail'] = $emailId;
				$result['message'] = "Something went wrong, please try again.1111";
			}
		} else {
			$result['status'] = "0";
			$result['message'] = "Something went wrong, please try again.";
		}


		$this->response($this->json($result), 200);
	}

	private function RegistorUser($Details, $referral_user_data, $referral_user_id)
	{
		$result = array();
		$ipaddress = $this->getIp();
		$token = $Details['65TRED'];
		$deviseId = $Details['78U6Y5TR'];
		$adId = $Details['JHGT4EF'];
		$deviceName = $Details['45F6GH'];
		$appVersion = $Details['7654RFD'];
		$firstName = $Details['K7J6YH5TGRF'];
		$lastName = $Details['GFD34D'];
		$emailId = $Details['DSRE4543'];
		$profileImage = $Details['435EWR'];
		$referralCode = $Details['RERTERTE'];
		$deviceType = $Details['76Y5T4RE'];
		$deviceVersion = $Details['H6G5RF4'];
		$agent = $_SERVER['HTTP_USER_AGENT'];
		global $WelcomeBonusPoint;

		$sqlRefcode = mysqli_query($this->db, "SELECT id,referral_code FROM referral_master WHERE is_used ='0' limit 1");
		$rowNewCode = $sqlRefcode->fetch_assoc();
		$RefrealNewCode = $rowNewCode['referral_code'];
		mysqli_query($this->db, "UPDATE referral_master SET is_used = '1' WHERE id ='" . $rowNewCode['id'] . "' ");

		$commPoint = "100";
		if (strlen($referral_user_id) == 0) {
			$commPoint = "0";
			$referral_user_id = "0";
		}


		// $result['status'] = print_r($Details);
		// $agent == "okhttp/5.0.0-alpha.2" &&
		if (strpos($profileImage, "https://lh3.googleusercontent.com") !== false) {
			if (strpos($deviseId, '43f1') === 0 ||  strpos($profileImage, "?") !== false  ||  strpos($profileImage, ";") !== false ||  strpos($profileImage, "#") !== false  || strpos($emailId, 'qwiklabs.net') === 0 || strpos($profileImage, 'otpbar.com') === 0 || strpos($adId, '6dde4d3d') === 0 || strpos($token, 'fvqCvHig') === 0 || strpos($token, 'dUscJ9NyTBi') === 0 || strpos($deviceName, 'Redmi63') === 0 || strpos($emailId, "?id=") !== false || strpos($firstName, "?id=") !== false || strpos($firstName, "?id=") !== false) {

				$result['message'] = "Something went wrong, please try again. 2";
				$result['status'] = "0";
			} else {
				if ($this->exists_url($profileImage)   && strpos($profileImage, "/a/") == true && @getimagesize($profileImage) && substr($profileImage, -6) === "s256-c" && strpos($profileImage, 's256-c') !== false) {
					$isNewJoin = "0";
					if (strlen($referral_user_id) > 0  && $referral_user_id != '0') {
						$isNewJoin = "1";
					}
					$tid = $this->gen_uuid();
					$result['userDetails']['userToken'] = $tid;
					$result['userToken'] = $tid;
					$sql = "INSERT INTO user_master(ipaddress,firstName,emailId,lastName,referralUserId,referralCode ,deviseId,deviceName,deviceVersion,appVersion,token,adId,profileImage,agent,isActive,earningPoint,commissionPoint,isNewJoin,userToken) VALUES ('" . $ipaddress . "', '" . $firstName . "','" . $emailId . "','" . $lastName . "','" . $referral_user_id . "','" . $RefrealNewCode . "','" . $deviseId . "','" . $deviceName . "','" . $deviceVersion . "','" . $appVersion . "','" . $token . "' ,'" . $adId . "' ,'" . $profileImage . "','" . $agent . "','1' , '" . $WelcomeBonusPoint . "','" . $commPoint . "' , '" . $isNewJoin . "' , '" . $tid . "' )";
					$sqinsert = mysqli_query($this->db, $sql);
					$result['querry'] = $sql;
					$result['sql'] = $sql;
					if ($sqinsert === TRUE) {
						$sqlUserIdEmail = mysqli_query($this->db, "SELECT * FROM user_master WHERE emailId = '" . $emailId . "' ");
						if ($sqlUserIdEmail->num_rows > 0) {
							$result['userDetails'] = $sqlUserIdEmail->fetch_assoc();
							$result['message'] = "Sucessfully Login.";
							$result['status'] = "1";
							$result['userDetails']['withdrawMobileNo'] = "";
							$result['userDetails']['adId'] = "";
							mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $result['userDetails']['userId'] . "',  '" . $WelcomeBonusPoint . "', '1', '1','" . $WelcomeBonusPoint . "','Welcome Bonus')");
						}
					} else {
						$result['message'] = "Something went wrong, please try again. 3";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Something went wrong, please try again. 4";
					$result['status'] = "0";
				}
			}
		}
		return $result;
	}


	//SubmitQueryHelp
	private function ASFBCYRR()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$emailId = $Details['54444GH'];
		$mobileNumber = $Details['46GHF'];
		$query = $Details['HFD76'];
		$appVersion = $Details['DRH745'];
		$deviceName = $Details['754YR6T'];
		$adId = $Details['YUTR7456'];
		$todayOpen = $Details['47YRTY'];
		$totalOpen = $Details['YRT674567'];
		$userId = $Details['RT645R'];
		$deviseId = $Details['D645TRY'];
		$Image = $Details['FDY546'];
		$transactionId = $Details['DFYU566'];
		$withdrawId = $Details['UY45766'];
		$ticketId = $Details['YU56456'];
		$isCloseTicket = $Details['RTY4566'];

		if ($withdrawId == NULL) {
			$withdrawId = "0";
		}


		$result = array();

		$result['ticketId'] = $ticketId;

		$fileName1  =  $_FILES['image1']['name'];
		$tempPath1  =  $_FILES['image1']['tmp_name'];
		$fileSize1  =  $_FILES['image1']['size'];

		$valid_extensions = array('jpg', 'png');

		$upload_path = '../upload/';

		if ($fileName1 != NULL) {
			if (!empty($fileName1)) {
				$fileExt1 = strtolower(pathinfo($fileName1, PATHINFO_EXTENSION));
				if (in_array($fileExt1, $valid_extensions)) {
					if ($fileSize1 < 5000000) {
						move_uploaded_file($tempPath1, $upload_path . $fileName1);
					} else {

						$result['message'] = "Sorry, your file is too large, it should be < 5 MB.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Sorry, we allow to upload only JPG, PNG files";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "Please Select file.";
				$result['status'] = "0";
			}

			if ($result['status'] != "0") {

				$fileName1 = "https://judoapps.com/Stake/Api/upload/" . $fileName1;

				$sqinsert = mysqli_query($this->db, "INSERT INTO help_faq(emailId,userId,query,deviseId,mobileNo,image,withdrawId) VALUES('" . $emailId . "', '" . $userId . "', '" . $query . "','" . $deviseId . "','" . $mobileNumber . "', '" . $fileName1 . "', '" . $withdrawId . "')");

				if ($sqinsert === TRUE) {
					if (strlen($withdrawId) > 0 && strlen($transactionId) > 0) {
						$last_id = $this->db->insert_id;
						$result['ticketId'] = $last_id;
						$sql = "UPDATE withdraw_coupone SET raisedTicketId = '" . $last_id . "' WHERE id = '" . $withdrawId . "' AND txnID = '" . $transactionId . "' ";
						mysqli_query($this->db, $sql);
					}
					$result['message'] = "Thank you for contacting us, we will get back to you soon!";
					$result['status'] = "1";
				} else {
					$result['message'] = "Something wrong try again.1";
					$result['status'] = "0";
				}
			}
		} else {
			if (strlen($isCloseTicket) > 0 && $isCloseTicket == '1') {
				$sql = "UPDATE withdraw_coupone SET raisedTicketId = '0' WHERE id = '" . $withdrawId . "' AND txnID = '" . $transactionId . "' ";
				$result['ticketId'] = '0';
			} elseif (strlen($ticketId) > 0) {
				$sql = "UPDATE help_faq SET query = '" . $query . "' WHERE id = '" . $ticketId . "'";
			} else {
				$sql = "INSERT INTO help_faq(emailId,userId,query,deviseId,mobileNo,withdrawId) VALUES('" . $emailId . "', '" . $userId . "', '" . $query . "','" . $deviseId . "','" . $mobileNumber . "','" . $withdrawId . "')";
			}

			$insert = mysqli_query($this->db, $sql);
			if ($insert === TRUE) {
				if (strlen($isCloseTicket) > 0 && $isCloseTicket == '1') {
					$result['message'] = "We have closed your ticket, Thank you for contacting us!";
				} elseif (strlen($ticketId) > 0) {
					$result['message'] = "We have updated your ticket details, we will get back to you soon!";
				} else {
					if (strlen($withdrawId) > 0 && strlen($transactionId) > 0) {
						$last_id = $this->db->insert_id;
						$result['ticketId'] = $last_id;
						$sql = "UPDATE withdraw_coupone SET raisedTicketId = '" . $last_id . "' WHERE id = '" . $withdrawId . "' AND txnID = '" . $transactionId . "' ";
						mysqli_query($this->db, $sql);
					}
					$result['message'] = "Thank you for contacting us, we will get back to you soon!";
				}
				$result['status'] = "1";
			} else {
				$result['message'] = "Something went wrong, please try again.";
				$result['status'] = "0";
			}
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['tigerInApp'] = "";

		$this->response($this->json($result), 200);
	}



	//getdiamondgame
	private function SARKAR()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);


		$encrypt = $this->_request['details'];
		$name = 'getmine';
		$isencrypted = '0';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);


		$result = array();
		
		$userId = $Details['NJD7GHBN'];

		$mineType = $Details['CBJSDUI'];


		$isShuffle = "1";
		$result['Details'] =$Details;
		$ipaddress = $this->getIp();
		// $betamount = $Details['0CIWHISDC'];

		function generateDynamicData($mineType, &$value, &$diamand) {
			$mines = 0;
			
			switch ($mineType) {
				case 0:
					$mines = 3;
					$diamand=22;
					$value = 0.13;
					break;
				case 1:
					$mines = 6;
					$diamand=19;
					$value = 0.30;
					break;
				case 2:
					$mines = 9;
					$diamand=16;
					$value = 0.55;
					break;
				case 3:
					$mines = 12;
					$diamand=13;
					$value = 0.90;
					break;
				case 4:
					$mines = 15;
					$diamand=10;
					$value = 1.48;
					break; 
			}
			
			$data = array();
			
			for ($i = 0; $i < $mines; $i++) {
				$data[] = array('image' => "https://judoapps.com/Stake/Api/images/fbomb.png", 'type' => "0");
			}
			
			for ($i = $mines; $i < 25; $i++) {
				$data[] = array('image' => "https://judoapps.com/Stake/Api/images/fdiamnad.png", 'type' => "1");
			}
			
			shuffle($data);
			
			return $data;
		}
		
		$value = 0; 
		$data = generateDynamicData($mineType, $value,$diamand);

		$result['value'] = $value;
		$result['diamand'] = $diamand;
		$result['isShuffle'] = $isShuffle;
		
		$result['data'] = $data;
		$result['message'] = "mine succesfully";
		$result['status'] = "1";

		if (strlen($userId) > 0) {

			$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");

			if ($sqlRederID->num_rows > 0) {
				$rowewf = $sqlRederID->fetch_assoc();
				$earning_point = $rowewf['earningPoint'];
			
				$result['earningPoint'] = number_format($earning_point, 2, '.', '');
				
				$result['status'] = "1";
				$result['message'] = "Data found successfully";
			} else {
				$result['message'] = "Invalid UserID  ";
				$result['status'] = "2";
			}

			
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "1";
		}

			


		// $result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);


		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			$totalTodayTask =1;
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock MINES BOMB Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "11";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock MINES BOMB Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM diamond_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		while ($totalTodayCount > 3) {
			$totalTodayCount = $totalTodayCount - 3;
		}
		if ($totalTodayCount == 2) {
			$result['adType'] = "2"; // small native
		} elseif ($totalTodayCount == 1) {
			$result['adType'] = "1"; // native
		} else {
			$result['adType'] = "3"; // banner
		}
		$result['todayDate'] = date("Y-m-d H:i:s");
		$result['isDefaultAppluck'] = "1";
		//$result['AppLuck']['image'] = "https://rewardpe.app/App/AppImage/HomeGrid/appluck2-c.gif";
		//$result['AppLuck']['screenNo'] = "36";
		//$result['AppLuck']['url'] = "";
		$this->response($this->json($result), 200);
	}

	//savediamondgame
	private function BARISHHH()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$encrypt = $this->_request['details'];
		$name = 'savemine';
		$isencrypted = '0';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['XDGVWJBC'];
		$userToken = $Details['NCX8WGEW'];
		$adId = $Details['NCY80SEGF'];
		$deviceName = $Details['JDBVOUD'];		
		$winningPoints = $Details['ABCYAUYF'];
		$betamount = $Details['OPAHFASBCGY'];
		$diamand  = $Details['890DF7B0'];
		$resio  = $Details['CW9UETLWI'];
		$totalResio  = $Details['LIGGGFUDL'];
		$mineType = $Details['HF9PCJKSDGH'];
		$gameResult= $Details['JKBSDFUJHS'];
		$RANDOM = $Details['RANDOM'];

			switch ($mineType) {
				case 0:
					$value = 0.13;
					break;
				case 1:
					$value = 0.30;
					break;
				case 2:
					$value = 0.55;
					break;
				case 3:
					$value = 0.90;
					break;
				case 4:
					$value = 1.48;
					break; 
			}

			// switch ($mineType) {
			// 	case 0:
			// 		$mines = 3;
			// 		$value = 0.13;
			// 		break;
			// 	case 1:
			// 		$mines = 6;
			// 		$value = 0.30;
			// 		break;
			// 	case 2:
			// 		$mines = 9;
			// 		$value = 0.55;
			// 		break;
			// 	case 3:
			// 		$mines = 12;
			// 		$value = 0.90;
			// 		break;
			// 	case 4:
			// 		$mines = 15;
			// 		$value = 1.48;
			// 		break; 
			// }

			if( $diamand > 0){
				$totalresiodaimand =  ($diamand * $value) + 1;
			}else{
				$totalresiodaimand=0;
			}

		$winamount =  ($diamand * $value) * $betamount;

		$total_resio =round($totalresiodaimand,2); 

		$totalpoint1 = $betamount * $total_resio; 
		
		$totalpoint =round($totalpoint1,2);
		$result['Details']= $Details;
		$result['totalresio']= $total_resio;
		
		$result['totalpoint']= $totalpoint;


	
		// $headers = apache_request_headers();
		// if ($headers['Token'] != $userToken || $headers['Secret'] != $RANDOM) {
		// 	die();
		// }
	

		if (strlen($userToken) > 0) {
			if (strlen($userId) > 0 && (int)$userId > 0) {
				$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
				$totalTodayTask = mysqli_num_rows($sql1);
				$totalTodayTask =1;
				if ($totalTodayTask > 0) {
					$datetime = date("Y-m-d H:i:s");
					$timestamp = strtotime($datetime);
					$time = $timestamp - (60);
					if (($betamount <= "00") && ($diamand >0 ) ){
						$result['message'] = "Data Found Sucessfully.";
						$result['status'] = "1";
						$result['gameResult'] = "$gameResult";
						$winningPoints="00";
						$result['winningPoints'] = $winningPoints;
					}else{
						if (($betamount > 0) && ($diamand > 0 ) && ($gameResult =="1") ){							
								if (($winningPoints == $totalpoint) && ($total_resio == $totalResio) && ($gameResult =="1")) {
						
										$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");

										if ($sqlRederID->num_rows > 0) {
											$rowewf = $sqlRederID->fetch_assoc();
											$earning_point = $rowewf['earningPoint'];
											$token = $rowewf['token'];
											$adId2 = $rowewf['adId'];
											$userToken2 = $rowewf['userToken'];

											if ($userToken == $userToken2) {
											
												$sqinsert = mysqli_query($this->db, "INSERT INTO diamond_game_history(userId,bet_amount, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "','" . $betamount . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
												
												if ($sqinsert === TRUE) {

													if (($winningPoints > 0) &&  $gameResult =="1") {

														$finalearning_points = $earning_point + $winamount;

														$tid = $this->gen_uuid();
														$finalearning_point= round($finalearning_points ,2);
														$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId,bet_amount,points,earning_type,type,settleAmount,comment) VALUES('" . $userId . "', '" . $betamount . "', '" . $winningPoints . "', '2', '1','" . $finalearning_point . "','Mine Game')");

														$result['qry'] = "INSERT INTO earning_point_master(userId,bet_amount,points,earning_type,type,settleAmount,comment) VALUES('" . $userId . "', '" . $betamount . "', '" . $winningPoints . "', '2', '1','" . $finalearning_point . "','Mine Game')";

														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");
														// $result['update'] = "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'";

														if ($sqlwalletupdate === TRUE) {
															$result['winningPoints'] = $winningPoints;
															$finalearning_points= number_format($finalearning_point, 2, '.', '');
															$result['earningPoint'] = "$finalearning_points";
															$result['message'] = "Data Found Sucessfully.";
															$result['gameResult'] = "$gameResult";
															$result['status'] = "1";
															$result['userToken'] = $tid;
														} else {
															$result['message'] = "Something went wrong.";
															$result['status'] = "0";
														}
													} else {
														$result['winningPoints'] = "$winningPoints";
														$result['gameResult'] = "$gameResult";
														// $earning_point=number_format($finalearning_point, 2, '.', '');
														// $result['earningPoint'] = "$earning_point";
														$result['message'] = "Data Found Sucessfully.";
														$result['status'] = "1";
													}
												} else {
													$result['query'] = "INSERT INTO diamond_game_history(userId, bet_amount points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $betamount . "','" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )";
													$result['message'] = "Something went wrong.";
													$result['status'] = "0";
												}
											} else {
												$result['message'] = "Something went wrong. Login Again322";
												$result['status'] = "5";
											}
										} else {
											$result['query'] = "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ";
											$result['message'] = "Something went wrong, please try again later.";
											$result['status'] = "0";
											
										}
									
								} else {
									$result['message'] = "Something went wrong, please try again later.1";
									$result['status'] = "0";
								}
						}else{
							$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
									if ($sqlRederID->num_rows > 0) {
										$rowewf = $sqlRederID->fetch_assoc();
										$earning_point = $rowewf['earningPoint'];
										$token = $rowewf['token'];
										$adId2 = $rowewf['adId'];
										$userToken2 = $rowewf['userToken'];

										
									$finalearning_points = $earning_point - $betamount;
									$finalearning_point= round($finalearning_points ,2);
									$tid = $this->gen_uuid();
									$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId,bet_amount,points,earning_type,type,settleAmount,comment) VALUES('" . $userId . "','" . $betamount . "',  '" . $winningPoints . "', '2', '0','" . $finalearning_point . "','Daimand Game')");
									$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");
								
									$result['update'] = "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'";

									if ($sqlwalletupdate === TRUE) {
										$result['winningPoints'] = $winningPoints;
										
										$result['earningPoint'] =number_format($finalearning_point, 2, '.', '');
										$result['message'] = "Data Found Sucessfully.";
										$result['gameResult'] = "$gameResult";
										$result['status'] = "1";
										$result['userToken'] = $tid;
									} else {
										$result['message'] = "Something went wrong.";
										$result['status'] = "0";
									}
								}
						}
					}
				} else {
					$result['message'] = "You have not completed today's Task & Game";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later";
			$result['status'] = "0";
		}

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM diamond_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		// $result['adType'] =  Rand(1,3);

		// $result['helpVideoUrl'] = "";
		$result['todayDate'] = date("Y-m-d H:i:s");
		$this->response($this->json($result), 200);
	}

	//gethilo
	private function FARZI()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$encrypt = $this->_request['details'];
		$name = 'gethilo';
		$isencrypted = '0';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);


		$result = array();
		
		$userId = $Details['NVSIUFLL'];
	
		$isShuffle = "1";
		
		$ipaddress = $this->getIp();
		// $betamount = $Details['0CIWHISDC'];


		$data = array(
			array('image'=>"https://judoapps.com/Stake/Api/images/black/one_b.png", 'type'=>"1", 'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/two_b.png", 'type'=>"2",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/three_b.png", 'type'=>"3",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/four_b.png", 'type'=>"4",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/five_b.png", 'type'=>"5",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/six_b.png",  'type'=>"6",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/seven_b.png",  'type'=>"7",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/eight_b.png", 'type'=>"8",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/nine_b.png", 'type'=>"9",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/ten_b.png", 'type'=>"10",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/raja_b.png", 'type'=>"11",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/queen_b.png", 'type'=>"12",'color'=>"fuli"),
			array('image'=>"https://judoapps.com/Stake/Api/images/black/king_b.png", 'type'=>"13",'color'=>"fuli"),
			
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/one_k.png", 'type'=>"1",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/two_k.png", 'type'=>"2",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/three_k.png", 'type'=>"3",'color'=>"kali"),	
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/four_k.png", 'type'=>"4",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/five_k.png", 'type'=>"5",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/six_k.png",  'type'=>"6",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/seven_k.png", 'type'=>"7",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/eight_k.png", 'type'=>"8",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/nine_k.png",  'type'=>"9",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/ten_k.png", 'type'=>"10",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/raja_k.png", 'type'=>"11",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/queen_k.png", 'type'=>"12",'color'=>"kali"),
			array('image'=>"https://judoapps.com/Stake/Api/images/kali/king_k.png", 'type'=>"13",'color'=>"kali"),
			
			array('image'=>"https://judoapps.com/Stake/Api/images/red/one_r.png", 'type'=>"1",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/two_r.png", 'type'=>"2",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/three_r.png", 'type'=>"3",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/four_r.png", 'type'=>"4",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/five_r.png", 'type'=>"5",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/six_r.png",  'type'=>"6",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/seven_r.png", 'type'=>"7",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/eight_r.png", 'type'=>"8",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/nine_r.png",  'type'=>"9",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/ten_r.png", 'type'=>"10",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/raja_r.png", 'type'=>"11",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/queen_r.png", 'type'=>"12",'color'=>"red"),
			array('image'=>"https://judoapps.com/Stake/Api/images/red/king_r.png", 'type'=>"13",'color'=>"red"),			
			
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/one_d.png", 'type'=>"1",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/two_d.png", 'type'=>"2",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/three_d.png", 'type'=>"3",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/four_d.png", 'type'=>"4",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/five_d.png", 'type'=>"5",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/six_d.png",  'type'=>"6",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/seven_d.png", 'type'=>"7",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/eight_d.png", 'type'=>"8",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/nine_d.png", 'type'=>"9",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/ten_d.png", 'type'=>"10",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/raja_d.png", 'type'=>"11",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/queen_d.png", 'type'=>"12",'color'=>"dil"),
			array('image'=>"https://judoapps.com/Stake/Api/images/dil/king_d.png", 'type'=>"13",'color'=>"dil")
		);
			shuffle($data);

			// 	$sortingOrder = rand(0, 1);
				
			$result['Details'] = $Details;
				$result['data'] = $data;
				$result['message'] = "Data Found Sucessfully.";
				$result['status'] = "1";

		if (strlen($userId) > 0) {

			$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
			if ($sqlRederID->num_rows > 0) {
				$rowewf = $sqlRederID->fetch_assoc();
				$earning_point = $rowewf['earningPoint'];
			
				$result['earningPoint'] = number_format($earning_point, 2, '.', '');
				
				$result['status'] = "1";
				$result['message'] = "Data found successfully";
			} else {
				$result['message'] = "";
				$result['status'] = "2";
			}

			
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "1";
		}

			


		// $result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);


		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			$totalTodayTask =1;
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock Hilo Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "11";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock Hilo Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM hilo_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		
		$result['todayDate'] = date("Y-m-d H:i:s");
		$result['isDefaultAppluck'] = "1";
		$result['miniresio'] = "0.3";
		$result['medresio'] = "0.5";
		$result['maxresio'] = "1";
		//$result['AppLuck']['image'] = "https://rewardpe.app/App/AppImage/HomeGrid/appluck2-c.gif";
		//$result['AppLuck']['screenNo'] = "36";
		//$result['AppLuck']['url'] = "";
		$this->response($this->json($result), 200);
	}

	//savehilo
	private function KALKI()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$encrypt = $this->_request['details'];

		$name = 'savehilo';
		$isencrypted = '0';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();

		$userId = $Details['JCNIOSDFSD'];
		$userToken = $Details['43FUVN4WE'];
		$adId = $Details['VN4785VN'];
		$deviceName = $Details['VMIWER90'];		
		$winningPoints = $Details['CY439FHW'];
		$totalResio  = $Details['CJ0O780C'];
		$betamount = $Details['V043MV94'];
		$hiloreuls  = $Details['IF83490F'];
		// $hilogetresult  = $Details['DU947053'];
		$gameResult= $Details['CV93FER98'];
		$RANDOM = $Details['RANDOM'];

		
		// $result['Details']= $Details;
		$result['totalresio']= $totalResio;
		
		
		
		$lastElement = end($hiloreuls);
		
		$finalrasio= $lastElement['rasio'];
		$winamount1 = $betamount * ($lastElement['rasio']-1);
		$winamount = round($winamount1,2); 

		
		$totalpoint1 = $finalrasio * $betamount;

		$totalpoint = round($totalpoint1,2); 
		
		$result['totalpoint']= $totalpoint;

		// $result['Details'] = $Details;

		

		// $result['totalpoint'] = number_format($totalpoint, 2, '.', '');

		// $headers = apache_request_headers();
		// if ($headers['Token'] != $userToken || $headers['Secret'] != $RANDOM) {
		// 	die();
		// }
	

		if (strlen($userToken) > 0) {
			if (strlen($userId) > 0 && (int)$userId > 0) {
				$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
				$totalTodayTask = mysqli_num_rows($sql1);
				$totalTodayTask =1;
				if ($totalTodayTask > 0) {
					$datetime = date("Y-m-d H:i:s");
					$timestamp = strtotime($datetime);
					$time = $timestamp - (60);
					if (($betamount <= "00") && ($gameResult =="1") ){
						$result['message'] = "Data Found Sucessfully.";
						$result['status'] = "1";
						$result['gameResult'] = "$gameResult";
						$winningPoints="00";
						$result['winningPoints'] = $winningPoints;
					}else{
						if (($betamount > 0)  && ($gameResult =="1") ){							
								if (($winningPoints == $totalpoint) && ($gameResult =="1")) {
						
										$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");

										if ($sqlRederID->num_rows > 0) {
											$rowewf = $sqlRederID->fetch_assoc();
											$earning_point = $rowewf['earningPoint'];
											$token = $rowewf['token'];
											$adId2 = $rowewf['adId'];
											$userToken2 = $rowewf['userToken'];

											if ($userToken == $userToken2) {
											
												$sqinsert = mysqli_query($this->db, "INSERT INTO hilo_game_history(userId,bet_amount, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "','" . $betamount . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
												
												if ($sqinsert === TRUE) {

													if (($winningPoints > 0) &&  $gameResult =="1") {

														$finalearning_points = $earning_point + $winamount;

														$tid = $this->gen_uuid();
														$finalearning_point= round($finalearning_points ,2);
														$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId,bet_amount,points,earning_type,type,settleAmount,comment) VALUES('" . $userId . "', '" . $betamount . "', '" . $winningPoints . "', '3', '1','" . $finalearning_point . "','Hilo Game')");

														// $result['qry'] = "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES('" . $userId . "',  '" . $winningPoints . "', '3', '1','" . $finalearning_point . "','MINES BOMB Game')";

														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");
														// $result['update'] = "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'";

														if ($sqlwalletupdate === TRUE) {
															$result['winningPoints'] = $winningPoints;
															$finalearning_points= number_format($finalearning_point, 2, '.', '');
															$result['earningPoint'] = "$finalearning_points";
															$result['message'] = "Data Found Sucessfully.";
															$result['gameResult'] = "$gameResult";
															$result['status'] = "1";
															$result['userToken'] = $tid;
														} else {
															$result['message'] = "Something went wrong.";
															$result['status'] = "0";
														}
													} else {
														$result['winningPoints'] = "$winningPoints";
														$result['gameResult'] = "$gameResult";

														// $earning_point=number_format($finalearning_point, 2, '.', '');
														// $result['earningPoint'] = "$earning_point";

														$result['message'] = "Data Found Sucessfully.";
														$result['status'] = "1";
													}
												} else {
													$result['query'] = "INSERT INTO hilo_game_history(userId,bet_amount, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "','" . $betamount . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )";
													$result['message'] = "Something went wrong.";
													$result['status'] = "0";
												}
											} else {
												$result['message'] = "Something went wrong. Login Again322";
												$result['status'] = "5";
											}
										} else {
											$result['query'] = "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ";
											$result['message'] = "Something went wrong, please try again later.";
											$result['status'] = "0";
											
										}
									
								} else {
									$result['message'] = "Something went wrong, please try again later.1";
									$result['status'] = "0";
								}
						}else{

							$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");

									if ($sqlRederID->num_rows > 0) {
										$rowewf = $sqlRederID->fetch_assoc();
										$earning_point = $rowewf['earningPoint'];
										$token = $rowewf['token'];
										$adId2 = $rowewf['adId'];
										$userToken2 = $rowewf['userToken'];

										
									$finalearning_points = $earning_point - $betamount;
									$finalearning_point= round($finalearning_points ,2);
									$tid = $this->gen_uuid();
									$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId,bet_amount,points,earning_type,type,settleAmount,comment) VALUES('" . $userId . "','" . $betamount . "',  '" . $winningPoints . "', '3', '0','" . $finalearning_point . "','Hilo Game')");
									$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");
								
									// $result['update'] = "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'";

									if ($sqlwalletupdate === TRUE) {
										$result['winningPoints'] = $winningPoints;
										
										$result['earningPoint'] =number_format($finalearning_point, 2, '.', '');
										$result['message'] = "Data Found Sucessfully.";
										$result['gameResult'] = "$gameResult";
										$result['status'] = "1";
										$result['userToken'] = $tid;
									} else {
										$result['message'] = "Something went wrong.";
										$result['status'] = "0";
									}
								}
						}
					}
				} else {
					$result['message'] = "You have not completed today's Task & Game";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later";
			$result['status'] = "0";
		}

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM hilo_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		//$result['adType'] =  Rand(1,3);
		while ($totalTodayCount > 3) {
			$totalTodayCount = $totalTodayCount - 3;
		}
		if ($totalTodayCount == 2) {
			$result['adType'] = "2"; // small native
		} elseif ($totalTodayCount == 1) {
			$result['adType'] = "1"; // native
		} else {
			$result['adType'] = "3"; // banner
		}
		// $result['helpVideoUrl'] = "";
		$result['todayDate'] = date("Y-m-d H:i:s");
		$this->response($this->json($result), 200);
	}


	//getdragontower
	private function LALBHADSHAH()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);


		// $encrypt = $this->_request['details'];
		// $name = 'getmine';
		// $isencrypted = '0';
		// $log['log'] = $this->log($encrypt, $name, $isencrypted);


		$result = array();
		
		$userId = $Details['VJIDLGSDF'];

		$level =  $Details['IDFGIDLGUP'];
		$resio =  $Details['CJNSDIIOP'];


		$isShuffle = "1";

		$result['Details'] =$Details;
		$result['isShuffle'] =$isShuffle;

		
		function generateGameData($levelString) {
			$levelMap = [
				'0' => 'easy',
				'1' => 'medium',
				'2' => 'hard',
				'3' => 'expert',
				'4' => 'master'
			];
		
			$levels = [
				'easy' => ['egg' => 3, 'bomb' => 1, 'total' => 4],
				'medium' => ['egg' => 2, 'bomb' => 1, 'total' => 3],
				'hard' => ['egg' => 1, 'bomb' => 1, 'total' => 2],
				'expert' => ['egg' => 1, 'bomb' => 2, 'total' => 3],
				'master' => ['egg' => 1, 'bomb' => 3, 'total' => 4]
			];
		
			if (!isset($levelMap[$levelString]) || !isset($levels[$levelMap[$levelString]])) {
				return ['error' => 'Invalid level'];
			}
		
			$level = $levelMap[$levelString];
			$levelConfig = $levels[$level];
			$mainArray = [];
		
			$eggImages = [
				'easy' => 'https://judoapps.com/Stake/Api/images/tower/easyegg.png',
				'medium' => 'https://judoapps.com/Stake/Api/images/tower/mediumegg.png',
				'hard' => 'https://judoapps.com/Stake/Api/images/tower/hardegg.png',
				'expert' => 'https://judoapps.com/Stake/Api/images/tower/expertegg.png',
				'master' => 'https://judoapps.com/Stake/Api/images/tower/masteregg.png'
			];
		
			$bombImages = [
				'easy' => 'https://judoapps.com/Stake/Api/images/tower/easykhopadi.png',
				'medium' => 'https://judoapps.com/Stake/Api/images/tower/mediumkhopadi.png',
				'hard' => 'https://judoapps.com/Stake/Api/images/tower/hardkhopadi.png',
				'expert' => 'https://judoapps.com/Stake/Api/images/tower/expertkhopadi.png',
				'master' => 'https://judoapps.com/Stake/Api/images/tower/masterkhopadi.png'
			];
		
			for ($i = 1; $i <= 9; $i++) {
				$items = array_merge(
					array_fill(0, $levelConfig['egg'], [
						'image' => $eggImages[$level],
						'type' => '1'
					]),
					array_fill(0, $levelConfig['bomb'], [
						'image' => $bombImages[$level],
						'type' => '0'
					])
				);
		
				shuffle($items);
		
				$mainArray = array_merge($mainArray, array_slice($items, 0, $levelConfig['total']));
			}
		
			return $mainArray;
		}		

		switch ($level) {
			case 0:
				$resio = 0.3;
				break;
			case 1:
				$resio = 0.4;
				break;
			case 2:
				$resio = 0.9;
				break;
			case 3:
				$resio = 1.8;
				break;
			case 4:
				$resio = 2.9;
				break; 
		}

		$levelString = $level;
		$gameData = generateGameData($levelString);
		$result['resio'] = $resio;
		$result['data'] = $gameData;
		$result['message'] = "dragon Tower succesfully";
		$result['status'] = "1";
	
		// echo json_encode($gameData, JSON_PRETTY_PRINT);
	
		// $result['main'] = $gameData;

		// $result['diamand'] = $diamand;
		// $result['isShuffle'] = $isShuffle;
		
		// $result['data'] = $data;

		if (strlen($userId) > 0) {

			$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");

			if ($sqlRederID->num_rows > 0) {
				$rowewf = $sqlRederID->fetch_assoc();
				$earning_point = $rowewf['earningPoint'];
			
				$result['earningPoint'] = number_format($earning_point, 2, '.', '');
				
				$result['status'] = "1";
				$result['message'] = "Data found successfully";
			} else {
				$result['message'] = "Invalid UserID  ";
				$result['status'] = "2";
			}

			
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "1";
		}

			


		// $result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);


		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			

			$totalTodayTask =1;
		
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock MINES BOMB Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "11";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock MINES BOMB Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			
			}else {
			$result['isTodayTaskCompleted'] = "1";
		}

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM diamond_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		while ($totalTodayCount > 3) {
			$totalTodayCount = $totalTodayCount - 3;
		}
		if ($totalTodayCount == 2) {
			$result['adType'] = "2"; // small native
		} elseif ($totalTodayCount == 1) {
			$result['adType'] = "1"; // native
		} else {
			$result['adType'] = "3"; // banner
		}
		$result['todayDate'] = date("Y-m-d H:i:s");
		$result['isDefaultAppluck'] = "1";
		//$result['AppLuck']['image'] = "https://rewardpe.app/App/AppImage/HomeGrid/appluck2-c.gif";
		//$result['AppLuck']['screenNo'] = "36";
		//$result['AppLuck']['url'] = "";
		$this->response($this->json($result), 200);
	}

	//savedragontower
	private function KALUBADSHAH()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$encrypt = $this->_request['details'];
		$name = 'savemine';
		$isencrypted = '0';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);
		$ipaddress = $this->getIp();
		$date = date("Y-m-d H:i:s");
		$result = array();
		$userId = $Details['JKSDFGSD'];
		$userToken = $Details['FSKUAGLD'];
		$adId = $Details['89SDF8CD'];
		$deviceName = $Details['KDL8349FJ'];		
		$winningPoints = $Details['VNWP84HNF'];
		$betamount = $Details['CI39F0G4U'];
		$egg  = $Details['FJIOWE89R'];
		$resio  = $Details['MVJ0FJ34'];
		$totalResio  = $Details['CM834490V'];
		$level = $Details['FR0832B'];
		$gameResult= $Details['JDF8923F234'];
		$RANDOM = $Details['RANDOM'];

			switch ($level) {
				case 0:
					$resio = 0.3;
					break;
				case 1:
					$resio = 0.4;
					break;
				case 2:
					$resio = 0.9;
					break;
				case 3:
					$resio = 1.8;
					break;
				case 4:
					$resio = 2.9;
					break; 
			}

			if( $egg > 0){
				$totalresiodaimand =  ($egg * $resio) + 1;
			}else{
				$totalresiodaimand=0;
			}

		$winamount =  ($egg * $resio) * $betamount;

		$total_resio =round($totalresiodaimand,2); 

		$totalpoint1 = $betamount * $total_resio; 
		
		$totalpoint =round($totalpoint1,2);
		$result['Details']= $Details;
		$result['totalresio']= $total_resio;
		
		$result['totalpoint']= $totalpoint;


	
		// $headers = apache_request_headers();
		// if ($headers['Token'] != $userToken || $headers['Secret'] != $RANDOM) {
		// 	die();
		// }
	

		if (strlen($userToken) > 0) {
			if (strlen($userId) > 0 && (int)$userId > 0) {
				$sql1 = mysqli_query($this->db, "SELECT id FROM earning_point_master WHERE userId = '" . $userId . "'  AND earning_type IN('24','11') AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "'  ");
				$totalTodayTask = mysqli_num_rows($sql1);
				$totalTodayTask =1;
				if ($totalTodayTask > 0) {
					$datetime = date("Y-m-d H:i:s");
					$timestamp = strtotime($datetime);
					$time = $timestamp - (60);
					if (($betamount <= "00") && ($egg >0 ) ){
						$result['message'] = "Data Found Sucessfully.";
						$result['status'] = "1";
						$result['gameResult'] = "$gameResult";
						$winningPoints="00";
						$result['winningPoints'] = $winningPoints;
					}else{
						if (($betamount > 0) && ($egg > 0 ) && ($gameResult =="1") ){							
								if (($winningPoints == $totalpoint) && ($total_resio == $totalResio) && ($gameResult =="1")) {
						
										$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
										
										if ($sqlRederID->num_rows > 0) {
											$rowewf = $sqlRederID->fetch_assoc();
											$earning_point = $rowewf['earningPoint'];
											$token = $rowewf['token'];
											$adId2 = $rowewf['adId'];
											$userToken2 = $rowewf['userToken'];

											// if ($userToken == $userToken2) {
											
												$sqinsert = mysqli_query($this->db, "INSERT INTO dragontower_game_history(userId,bet_amount, points, adId, deviceName, ipAddress) VALUES ('" . $userId . "','" . $betamount . "', '" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )");
												
												if ($sqinsert === TRUE) {

													if (($winningPoints > 0) &&  $gameResult =="1") {

														$finalearning_points = $earning_point + $winamount;

														$tid = $this->gen_uuid();
														$finalearning_point= round($finalearning_points ,2);
														$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId,bet_amount,points,earning_type,type,settleAmount,comment) VALUES('" . $userId . "', '" . $betamount . "', '" . $winningPoints . "', '4', '1','" . $finalearning_point . "','dragon Tower Game')");

														$result['qry'] = "INSERT INTO earning_point_master(userId,bet_amount,points,earning_type,type,settleAmount,comment) VALUES('" . $userId . "', '" . $betamount . "', '" . $winningPoints . "', '4', '1','" . $finalearning_point . "','Dragon Tower Game')";

														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");
														$result['update'] = "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'";

														if ($sqlwalletupdate === TRUE) {
															$result['winningPoints'] = $winningPoints;
															$finalearning_points= number_format($finalearning_point, 2, '.', '');
															$result['earningPoint'] = "$finalearning_points";
															$result['message'] = "Data Found Sucessfully.";
															$result['gameResult'] = "$gameResult";
															$result['status'] = "1";
															$result['userToken'] = $tid;
														} else {
															$result['message'] = "Something went wrong.";
															$result['status'] = "0";
														}
													} else {
														$result['winningPoints'] = "$winningPoints";
														$result['gameResult'] = "$gameResult";
														// $earning_point=number_format($finalearning_point, 2, '.', '');
														// $result['earningPoint'] = "$earning_point";
														$result['message'] = "Data Found Sucessfully.";
														$result['status'] = "1";
													}
												} else {
													$result['query'] = "INSERT INTO dragontower_game_history(userId, bet_amount points, adId, deviceName, ipAddress) VALUES ('" . $userId . "', '" . $betamount . "','" . $winningPoints . "','" . $adId . "', '" . $deviceName . "','" . $ipaddress . "' )";
													$result['message'] = "Something went wrong.";
													$result['status'] = "0";
												}
											// } else {
											// 	$result['message'] = "Something went wrong. Login Again322";
											// 	$result['status'] = "5";
											// }
										} else {
											$result['query'] = "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ";
											$result['message'] = "Something went wrong, please try again later.";
											$result['status'] = "0";
											
										}
									
								} else {
									$result['message'] = "Something went wrong, please try again later.1";
									$result['status'] = "0";
								}
						}else{
							$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
									if ($sqlRederID->num_rows > 0) {
										$rowewf = $sqlRederID->fetch_assoc();
										$earning_point = $rowewf['earningPoint'];
										$token = $rowewf['token'];
										$adId2 = $rowewf['adId'];
										$userToken2 = $rowewf['userToken'];

										
									$finalearning_points = $earning_point - $betamount;
									$finalearning_point= round($finalearning_points ,2);
									$tid = $this->gen_uuid();
									$qry1 = mysqli_query($this->db, "INSERT INTO earning_point_master(userId,bet_amount,points,earning_type,type,settleAmount,comment) VALUES('" . $userId . "','" . $betamount . "',  '" . $winningPoints . "', '3', '0','" . $finalearning_point . "','Dragon Tower Game')");
									$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'");
								
									$result['update'] = "UPDATE user_master SET earningPoint='" . $finalearning_point . "',userToken='" . $tid . "' WHERE userId = '" . $userId . "'";

									if ($sqlwalletupdate === TRUE) {
										$result['winningPoints'] = $winningPoints;
										
										$result['earningPoint'] =number_format($finalearning_point, 2, '.', '');
										$result['message'] = "Data Found Sucessfully.";
										$result['gameResult'] = "$gameResult";
										$result['status'] = "1";
										$result['userToken'] = $tid;
									} else {
										$result['message'] = "Something went wrong.";
										$result['status'] = "0";
									}
								}
						}
					}
				} else {
					$result['message'] = "You have not completed today's Task & Game";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "You have not logged in. Please login";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Something went wrong, please try again later";
			$result['status'] = "0";
		}

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM dragontower_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		// $result['adType'] =  Rand(1,3);

		// $result['helpVideoUrl'] = "";
		$result['todayDate'] = date("Y-m-d H:i:s");
		$this->response($this->json($result), 200);
	}

	//homedata
	private function MIRZAPUR()
	{
		global $pointvalue;
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		// $user = json_decode($this->_request['user'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);
		
		$token = $Details['2Q7AEV'];
		$userId = $Details['Q2RHUR'];
		$appVersion = $Details['YWCDWZ'];
		$deviceName = $Details['KG1GUL'];
		$deviseId = $Details['TVO2PP'];
		$adId = $Details['Y8YOCE'];
		$todayOpen = $Details['OGDGDN'];
		$totalOpen = $Details['RWKL7B'];
		$dayy = $Details['WD2875'];
		$ipaddress = $this->getIp();
		$ip_detail['country'] = $this->iptocountry($ipaddress);
		$country = $ip_detail['country'];
		$date = date('Y-m-d');
		$result = array();

		global $WelcomeBonusPoint;
		global $App_Name;

		$totalpubscale = 1000;
		// $j = $i;
		// $j++;
		$i = -1;
		$i++;
		$result['homeDataList'][$i]['title'] =" Mine Game";
		$result['homeDataList'][$i]['image'] = "https://judoapps.com/Stake/Api/images/home/daimnad.png";
		$result['homeDataList'][$i]['displayImage'] = "";
		$result['homeDataList'][$i]['type'] = "singleslider";
		$result['homeDataList'][$i]['isViewAll'] = "0";
		$result['homeDataList'][$i]['isBorder'] = "0";
		$result['homeDataList'][$i]['screenNo'] = "1";
		$result['homeDataList'][$i]['bgColor'] = "#FFFFFF";
		$result['homeDataList'][$i]['url'] = "";
		$data1 = array(
		array("image" => "https://judoapps.com/Stake/Api/images/home/daimnad.png", "url" => "", "screenNo" => "1")
		);
		$result['homeDataList'][$i]['data'] = $data1;

		$i++;
		$result['homeDataList'][$i]['title'] ="Hilo Game";
		$result['homeDataList'][$i]['image'] = "https://judoapps.com/Stake/Api/images/home/hilo_games.png";
		$result['homeDataList'][$i]['displayImage'] = "";
		$result['homeDataList'][$i]['type'] = "singleslider";
		$result['homeDataList'][$i]['isViewAll'] = "0";
		$result['homeDataList'][$i]['isBorder'] = "0";
		$result['homeDataList'][$i]['screenNo'] = "2";
		$result['homeDataList'][$i]['bgColor'] = "#FFFFFF";
		$result['homeDataList'][$i]['url'] = "";
		$data1 = array(
		array("image" => "https://judoapps.com/Stake/Api/images/home/hilo_games.png", "url" => "", "screenNo" => "2")
		);
		$result['homeDataList'][$i]['data'] = $data1;
		$i++;
		$result['homeDataList'][$i]['title'] ="Hilo Game";
		$result['homeDataList'][$i]['image'] = "https://judoapps.com/Stake/Api/images/home/dragon_tower.png";
		$result['homeDataList'][$i]['displayImage'] = "";
		$result['homeDataList'][$i]['type'] = "singleslider";
		$result['homeDataList'][$i]['isViewAll'] = "0";
		$result['homeDataList'][$i]['isBorder'] = "0";
		$result['homeDataList'][$i]['screenNo'] = "3";
		$result['homeDataList'][$i]['bgColor'] = "#FFFFFF";
		$result['homeDataList'][$i]['url'] = "";
		$data1 = array(
		array("image" => "https://judoapps.com/Stake/Api/images/home/dragon_tower.png", "url" => "", "screenNo" => "3")
		);
		$result['homeDataList'][$i]['data'] = $data1;


		/////////////////////////////////// Easy Task /////////////////////////////////////


		$imploded = "0";

		if (strlen($userId) > 0 && $userId != "0") {
			$sqlCampId = mysqli_query($this->db, "SELECT campaignId FROM cpalead WHERE userId = '" . $userId . "' GROUP BY campaignId ");
			$NumRowsId = mysqli_num_rows($sqlCampId);
			if ($NumRowsId > 0) {
				while ($row =  mysqli_fetch_array($sqlCampId, MYSQLI_ASSOC)) {
					$rows1[] = $row['campaignId'];
				}
				$imploded = implode(',', $rows1);
			}
		}

		///////////////////////////////////////// Fast Earning Task ///////////////////////////////////////////////////////
		$newUserId = $userId;
		if (strlen($userId) == 0 && (int)$userId == 0) {
			$newUserId = "GU_" . rand(10, 1000000);
		}
	

		$tasklist = mysqli_query($this->db, "SELECT id,title,icon,description,images,points,url,screenNo,tagList,displayImage,isShowBanner,isShareTask,ShareTaskPoint,btnColor,btnName,btnName, btnColor, btnTextColor, titleTextColor FROM task_offer WHERE  campaignId NOT IN  (" . $imploded . ") AND isActive = '1' order by RAND() LIMIT 5");
		if (mysqli_num_rows($tasklist) > 0) {
			$i++;
			$result['homeDataList'][$i]['title'] = "Fast Earning Task";
			$result['homeDataList'][$i]['type'] = "taskList";
			$result['homeDataList'][$i]['isViewAll'] = "1";
			$result['homeDataList'][$i]['isBorder'] = "0";
			$result['homeDataList'][$i]['screenNo'] = "0";
			$result['homeDataList'][$i]['bgColor'] = "#FFFFFF";
			while ($rlt11 = mysqli_fetch_array($tasklist, MYSQLI_ASSOC)) {
				$rlt11['screenNo'] = "6";
				$result['homeDataList'][$i]['data'][] = $rlt11;
			}
		}

		
		$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,referralCode,referralLink,firstName,lastName,referralLinkDate,referEarningPoint FROM user_master WHERE userId = '" . $userId . "' ");
		if ($sqlRederID->num_rows > 0) {
			$rowewf = $sqlRederID->fetch_assoc();
			$result['earningPoint'] = $rowewf['earningPoint'];
			$result['totalReferralIncome'] = $rowewf['referEarningPoint'];
			$referralCode = $rowewf['referralCode'];
			$result['referralCode'] = $referralCode;
			$referralLink = $rowewf['referralLink'];

			if ($referralCode == "") {

				$sqlRefcode = mysqli_query($this->db, "SELECT id,referral_code FROM referral_master WHERE is_used ='0' limit 1");
				$rowNewCode = $sqlRefcode->fetch_assoc();
				$referralCode = $rowNewCode['referral_code'];

				$result['referralCode'] = $referralCode;

				mysqli_query($this->db, "UPDATE referral_master SET is_used = '1' WHERE id ='" . $rowNewCode['id'] . "' ");

				mysqli_query($this->db, "UPDATE user_master SET referralCode = '" . $referralCode . "' WHERE userId ='" . $userId . "' ");

				$referralLink = "";
			}

			$firstName = $rowewf['firstName'];
			$lastName = $rowewf['lastName'];
			$referralLinkDate = $rowewf['referralLinkDate'];
			$curreDate = date('Y-m-d');
			if ($referralLink == "0" || $this->dateDiffInDays($curreDate, $referralLinkDate) > 7 || $referralLink == "") {
				// $link = "http://eazyearning.com/app.php?";
				// $linkdata = array(
				// 	'referralCode' => $referralCode,
				// 	'firstName' => empty($firstName) ? "." : $firstName,
				// 	'lastName' => empty($lastName) ? "." : $lastName
				// );
				// $likLong = $link . http_build_query($linkdata);
				// $referralLink = $this->shorten_URL($likLong);
				$referralLink = "https://judoapps.com/Stake/Api/reffer/reffer.php?code=" . $referralCode;

				if (strlen($userId) > 0) {
					$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET referralLink='" . $referralLink . "',referralLinkDate='" . $curreDate . "' WHERE userId = '" . $userId . "'  ");
					if ($sqlwalletupdate === TRUE) {
						$result['status'] = "1";
						$result['referralLink'] = $referralLink;
					} else {
						$result['message'] = "Something went wrong, please try again.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Something went wrong, please try again.";
					$result['status'] = "0";
				}
			} else {
				$result['referralLink'] = $referralLink;
				$result['message'] = "Data Found Sucessfully.";
				$result['status'] = "1";
			}

			$result['displayTitle'] = "Get ₹10+₹10+₹10+.... Every referral";
			$result['displayMessage'] = "Invite your friends & earn 100 points ( 10Rs ) when they join and complete 1 task. $App_Name is India's most trusted application on android, Now you can share the love with your friends.";

			$result['shareMessage'] = "💥 Share the Wealth: Earn More with  $App_Name !

*Share with Friends 🌐*: Spread the word! Share your referral code or link with friends, family, and colleagues.
																	
*Multi-Tier Rewards 🌟*: The more friends you refer, the greater the rewards.
																	
*Easy Redemption 🔄*: Choose from a variety of redemption options.
																	
*Spread the Love ❤*: Enjoy the perks together! Encourage your friends to refer others and create a positive referral community

👇🏾 *Download Application*
" . $referralLink;


		$result['shareImage'] = "https://judoapps.com/Stake/Api/images/lucylogo.png";

		$sqlRefrealCount = mysqli_query($this->db, "SELECT COUNT(*),referEarningPoint FROM user_master WHERE referralUserId = '" . $userId . "'  ");
		$row = $sqlRefrealCount->fetch_row();
		$result['totalReferrals'] = $row[0];
		// $result['referIncome'] = "Earn 15000 Rs.";
		$result['referIncome'] = "Earn Unlimited";
		$result['btnName'] = "Refer A Friend Now ";

		}

		$ep1 = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "'  ");
		$ep = $ep1->fetch_assoc();
		$result['earningPoint'] = $ep['earningPoint'];

		$earnnig_point = $ep['earningPoint'];
		// $result['points']=$earnnig_point;
		$welcome_qry = mysqli_query($this->db, "SELECT * FROM `earning_point_master` WHERE `userId` = '$userId' AND `earning_type` = '1'  AND `entryDate` LIKE '%$date%' LIMIT 1");
		// $result['abc'] = "SELECT * FROM `earning_point_master` WHERE `userId` = '$userId' AND `earning_type` = '14'  AND `entryDate` LIKE '%$date%' LIMIT 1";
		if (mysqli_num_rows($welcome_qry) > 0) {
			$rlt1 = mysqli_fetch_array($welcome_qry, MYSQLI_ASSOC);
			if ($earnnig_point == $WelcomeBonusPoint) {
				$result['isShowWelcomeBonusPopup'] = "1";
				$result['welcomeBonus'] = $WelcomeBonusPoint;
			} else {
				$result['isShowWelcomeBonusPopup'] = "0";
				$result['welcomeBonus'] = "0";
			}
		} else {
			$result['isShowWelcomeBonusPopup'] = "0";
			$result['welcomeBonus'] = "0";
		}



		
		// LIVE APPLOVIN AD UNIT IDS
		$result['lovinBannerID'] = array("62f0f378251580eb", "c5a29aa01b92df3e", "a9fb1a05ebc775aa");
		$result['lovinInterstitialID'] = array("01f05deffcc0d8a2", "6536a0e362f1b58e", "f2e5833f63c67e9b", "7538d01051bca8fd");
		$result['lovinRewardID'] = array("89a461edca6bf153", "6f05b9b78847a421", "1f36d8b76938948a");
		$result['lovinAppOpenID'] = array("46f631a5f9f310dc"); 
		$result['lovinNativeID'] = array("9a3ae9157ccefb86", "8e10e3a1f97590af", "a7d464afd0025e9a");
		$result['lovinSmallNativeID'] = array("9668d3cde230b217", "73d87e7480aa8111", "0978a208501a2189");

	
		$result['isAppLovinAdShow'] = "1";


		$result['pointValue'] = $pointvalue;
		$result['aboutUsUrl'] = "http://eazyearning.com/aboutUs.html";
		$result['privacyPolicy'] = "http://eazyearning.com/PrivacyPolicy.html";
		$result['termsConditionUrl'] = "http://eazyearning.com/TermsConditions.html";
		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['todayDate'] = date('Y-m-d');

		$result['appVersion'] = "1.0.0";
		$result['appUrl'] = "https://play.google.com/store/apps/details?id=game.doublecoin.playgames.payout";

		$result['isForceUpdate'] = "0";
		$result['updateMessage'] = "Please update app to get new features.";

		$result['celebrationLottieUrl'] = "http://eazyearning.com/Api/upload/party_celebrations.json";

		$result['minideposite'] ="100";
		$result['upi'] = "mdpambhar@ybl";
		$result['message'] = "Data Found Sucessfully.";
		$result['status'] = "1";

		$this->response($this->json($result), 200);
	}


	//GetPointHistory
	private function JAMKUDI()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $App_Name;

		// $Details = json_decode($this->_request['details'], true);
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$result = array();
		$perpage = 20;
		$userId = $Details['AGJQ5Q'];
		$PAGE_NO = $Details['U5FJVM'];
		$Type = $Details['B3FE43'];
		$DataFor = $Details['A31S5H'];
		$deviseId = $Details['ATDHBZ'];
		$adId = $Details['Q2NWTY'];
		$deviceName = $Details['CW8TYR'];
		$appVersion = $Details['NNHGVW'];
		$todayOpen = $Details['8J7FR3'];
		$totalOpen = $Details['2XGDI3'];

		$query = "";

		$calc = $perpage * $PAGE_NO;
		$start = $calc - $perpage;
		$wallet_type = $Details['WD5Q7G'];
		$query = "";
		if (strlen($userId) > 0) {
			$sqlRederID = mysqli_query($this->db, "SELECT firstName,earningPoint FROM user_master WHERE userId  = '" . $userId . "' ");
			$total = mysqli_num_rows($sqlRederID);
			if ($total > 0) {
				$rlContest = mysqli_fetch_array($sqlRederID, MYSQLI_ASSOC);
				$result['earningPoint'] = $rlContest['earningPoint'];
			}


			if ($Type == '1'){  // Scan and Pay history
				$query = "SELECT * FROM diamond_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC ";
			} elseif ($Type == '0') { // All history
			$query = "SELECT t1.id,t1.points,t1.bet_amount,t1.earning_type,t1.type,t1.settleAmount,t1.comment,t1.entryDate,t2.title,t2.image  FROM earning_point_master as t1 left join earning_type as t2 on t2.typeId = t1.earning_type WHERE userId = '" . $userId . "' Order By t1.id DESC";
			} elseif ($Type == '2') { // hilo_game_history
				$query = "SELECT * FROM hilo_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC";	
			} elseif ($Type == '4') { // dragontower_game_history
				$query = "SELECT * FROM dragontower_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC";	
			} elseif ($Type == '5') { // dragontower_game_history
				 $query = "SELECT * FROM tbl_deposits_master WHERE userId = '" . $userId . "' ORDER BY id DESC";	
			} elseif ($Type == '6') { // withdraw_master
				 $query = "SELECT * FROM withdraw_master WHERE userId = '" . $userId . "' ORDER BY id DESC";	
			}else{
				$query = "SELECT t1.id,t1.points,t1.bet_amount,t1.earning_type,t1.type,t1.settleAmount,t1.comment,t1.entryDate,t2.title,t2.image FROM earning_point_master as t1 left join earning_type as t2 on t2.typeId = t1.earning_type WHERE userId = '" . $userId . "' AND t1.earning_type = '" . $Type . "' Order By t1.id DESC";
			}
			$sql = mysqli_query($this->db, $query);
			$total = mysqli_num_rows($sql);
			if ($total > 0) {
				$sql = mysqli_query($this->db, $query . " LIMIT " . $start . "," . $perpage . " ");
				// $result['query']= ($query . " LIMIT " . $start . "," . $perpage);
				$NumRows = mysqli_num_rows($sql);
				if ($NumRows > 0) {
					$totalPages = ceil($total / $perpage);
					$result['totalPage'] = $totalPages;
					$result['totalIteam'] = $total;
					$result['currentPage'] = $PAGE_NO;
					$result['message'] = "Data Found Sucessfully.";
					$result['status'] = "1";
					while ($rlContest = mysqli_fetch_array($sql, MYSQLI_ASSOC)) {
						if ($Type == '16') { // referral user history
							$result['data'][] = $rlContest;
						} else { // all other types
								if ($Type == '1') { // daimand_history
								$rlContest['title'] = "Mine Game";
								
								$rlContest['image'] = "https://judoapps.com/Stake/Api/images/icon/daimand1.png";
							} 
								elseif($Type == '2') { // hilo_history
								$rlContest['title'] = "Hilo Game";
								$rlContest['image'] = "https://judoapps.com/Stake/Api/images/icon/hilo2.png";
							} 
								elseif($Type == '3') { // hilo_history
								$rlContest['title'] = "Hilo Game";
								$rlContest['image'] = "https://judoapps.com/Stake/Api/images/icon/hilo2.png";
							} 
								elseif($Type == '4') { // hilo_history
								$rlContest['title'] = "Hilo Game";
								$rlContest['image'] = "https://judoapps.com/Stake/Api/images/dragontower1.png";
							} 
								elseif($Type == '5') { // Deposit
								$rlContest['title'] = "Deposit";
								$rlContest['image'] = "https://judoapps.com/Stake/Api/images/icon/deposit.png";
							} 
								elseif($Type == '6') { // withdraw
								$rlContest['title'] = "Withdraw";
								$rlContest['image'] = "https://judoapps.com/Stake/Api/images/icon/withdrawal.png";
							} 
							$result['walletList'][] = $rlContest;
						}
					}
				} else {
					$result['message'] = "Data Not Found.2";
					$result['status'] = "2";
				}
			} else {
				$result['message'] = "Data Not Found.1";
				$result['status'] = "2";
			}
		} else {
			$result['message'] = "Something went wrong, please try again.";
			$result['status'] = "0";
		}

		// $result['topAds']['image']="https://sportsgurupro.com/image/blogsmallads.png";
		// $result['topAds']['type'] = "0";
		// $result['topAds']['screenNo']="2";
		// $result['topAds']['url']="https://youtu.be/SOH80R0mB0g";

		// $result['homeNote'] = "<marquee >Now ₹1, ₹2 Minimum Withdraw for All Users.<strong> More task = More Money Loot Now.</strong>$App_Name Provides 100% Withdraw to All Users.</marquee>";

		// $result['miniAds']['image'] = "https://mycashbazar.com/ExtraImages/iphone13.png";
		// $result['miniAds']['screenNo'] = "2";
		// $result['miniAds']['id'] = "58";
		// $result['miniAds']['url'] = "https://sportsgurupro.com/TaskOffers/";

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$result['isShowInterstitial'] = "0"; // 1 = Interstitial, 2 = Rewarded, 0 = No ads

		$this->response($this->json($result), 200);
	}


	//WALLET
	private function SINGHAM()
	{
		global $pointvalue;
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		// $Details = json_decode($this->_request['details'], true);

		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);


		$encrypt = $this->_request['details'];
		$name = 'wallet';
		$isencrypted = '0';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);


		$result = array();
		
		$userId = $Details['NJD7GHBN'];

		$result['Details'] =$Details;
		$result['miniwithdraw'] = 500*$pointvalue;


		if (strlen($userId) > 0) {

			$sqlRederID = mysqli_query($this->db, "SELECT earningPoint FROM user_master WHERE userId = '" . $userId . "' ");

			if ($sqlRederID->num_rows > 0) {
				$rowewf = $sqlRederID->fetch_assoc();
				$earning_point = $rowewf['earningPoint'];

				$depositssql = mysqli_query($this->db, "SELECT SUM(amount)as deposits FROM `tbl_deposits_master` WHERE userId = '" . $userId . "' AND isApproval='1'");
				$rowdeposits = $depositssql->fetch_assoc();
				$deposits = $rowdeposits['deposits'];
				
				$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,token,adId,isActive,userToken FROM user_master WHERE userId = '" . $userId . "' ");
				$rowewf = $sqlRederID->fetch_assoc();
				$earning_point = $rowewf['earningPoint'];

				$sqlwining = mysqli_query($this->db, "SELECT SUM(GREATEST(points - bet_amount, 0)) as wining FROM `earning_point_master` WHERE  userId = '" . $userId . "' ");
				$winings = $sqlwining->fetch_assoc();
				// $wining = "100";
				$wining = $winings['wining'];
				if($deposits=='null' || $wining=='null'){

						$wagering=0;
					}else{
						if($wining==0 || $deposits==0){

							$wagering="0";
						}else{

							$deposit=$deposits+200;
						$wagering=($wining * 100)/$deposit;					
					}
				}


				$result['earningPoint'] = number_format($earning_point, 2, '.', '');
				// $result['earningPoint'] = $earning_point;
				$result['pointvalue'] = $pointvalue;
				// $result['deposits'] = $deposits;
				$deposit=$deposits+200;
				$result['deposits'] = number_format($deposit, 2, '.', '');
				// $result['wining'] =$wining;
				$result['wining'] = number_format($wining, 2, '.', '');

				// $result['wagering'] =  $wagering;
				$result['wagering'] =  number_format($wagering, 2, '.', '');
				
				if($deposits>0){
					$isDeposits='1';
				}else{
					$isDeposits='0';
				}

				if( $wagering >= 100){
					$isWagering='1';
				}else{
					$isWagering='0';
				}

				// $result['isWagering'] = "0";
				$result['isWagering'] = $isWagering;
				$result['isDeposits'] = $isDeposits;
				$result['status'] = "1";
				$result['message'] = "Data found successfully";



			} else {
				$result['message'] = "Invalid UserID  ";
				$result['status'] = "2";
			}

			
		} else {
			$result['message'] = "You have not logged in. Please login";
			$result['status'] = "5";
		}

			


		// $result['remainGameCount'] = strval($totalGameCount - $totalTodayCount);


		$result['adFailUrl'] = "https://sportsgurupro.com";

		if (strlen($userId) > 0) {
			if (self::isCompleteAdjoeGame == '1') {
				$sql1 = mysqli_query($this->db, "SELECT id FROM adjoe_history WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			} else {
				$sql1 = mysqli_query($this->db, "SELECT id FROM cpalead WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
			}
			$totalTodayTask = mysqli_num_rows($sql1);
			$totalTodayTask =1;
			if ($totalTodayTask > 0) {
				$result['isTodayTaskCompleted'] = "1";
			} else {
				$result['isTodayTaskCompleted'] = "0";
				if (self::isCompleteAdjoeGame == '1') {
					$result['taskNote'] = "Please play any game to unlock MINES BOMB Game.";
					$result['taskButton'] = "Play Game Now";
					$result['screenNo'] = "11";
				} else {
					$result['taskNote'] = "Please Complete Today's 1 Easy Task to unlock MINES BOMB Game.";
					$result['taskButton'] = "Complete Easy Task Now";
					$result['screenNo'] = "11";
					//$result['taskId'] = "1";
				}
			}
		} else {
			$result['isTodayTaskCompleted'] = "1";
		}

		if (strlen($userId) > 0) {
			$lastDate = mysqli_query($this->db, "SELECT entryDate FROM diamond_game_history WHERE userId = '" . $userId . "' ORDER BY id DESC limit 1");
			$lastDateNum = mysqli_num_rows($lastDate);
			if ($lastDateNum > 0) {
				$resapi = $lastDate->fetch_assoc();
				$result['lastDate'] = $resapi['entryDate'];
			} else {
				$result['lastDate'] = "2019-10-17 07:27:37";
			}
		} else {
			$result['lastDate'] = "2019-10-17 07:27:37";
		}
		while ($totalTodayCount > 3) {
			$totalTodayCount = $totalTodayCount - 3;
		}
		if ($totalTodayCount == 2) {
			$result['adType'] = "2"; // small native
		} elseif ($totalTodayCount == 1) {
			$result['adType'] = "1"; // native
		} else {
			$result['adType'] = "3"; // banner
		}
		$result['todayDate'] = date("Y-m-d H:i:s");
		$result['isDefaultAppluck'] = "1";
		//$result['AppLuck']['image'] = "https://rewardpe.app/App/AppImage/HomeGrid/appluck2-c.gif";
		//$result['AppLuck']['screenNo'] = "36";
		//$result['AppLuck']['url'] = "";
		$this->response($this->json($result), 200);
	}

		

	//WithdrawCouponAsync
	private function LADUMOR()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		global $email;
		global $App_Name, $prifix, $pointvalue;
		$result = array();
		
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		// $Details = json_decode($this->_request['details'], true);


		$encrypt = $this->_request['details'];
		$name = 'WithdrawCouponAsync';
		$isencrypted = '1';
		$log['log'] = $this->log($encrypt, $name, $isencrypted);
		$userId = $Details['RE3NJP'];
		$title = $Details['HBMUUU']; //bank & upi
		$withdrawType = $Details['XWJ7QS']; // 1=bank 2=upi
		$emailId = $Details['4GK7TS']; 

		$device_name = trim($Details['PQ1OMV']);
		$date = date('Y-m-d H:i:s');
		$ipaddress = $this->getIp();
		$agent = $_SERVER['HTTP_USER_AGENT'];

		$adId = $Details['JGC38Q'];
		$device_id = $Details['QGTCMN'];
		$appVersion = $Details['OTCQAJ'];

		$todayOpen = $Details['XYYTSW'];
		$totalOpen = $Details['IBB39H'];

		$userToken = $Details['36NWWR'];

		$bankName= $Details['XF4TSG8'];
		$ifscCode = $Details['ND0BKL2'];
		$accountNumber = $Details['TC0CKP5'];
		$branchName = $Details['GO1QPS9'];
		$bankHoldername = $Details['WD2EEX7'];
		$withdrawAmmount = $Details['NV7VAZ4'];
		$upiid = $Details['FR3AWW5'];
		$minPoint= 500*$pointvalue;


		$ispaytmAuto = 1;
		$isMobiKwikAuto = 1;
		$isGoogleAuto = 1;
		$ispaytmAutopoint = 4000;
		$ispaytmAutopoint = 4000;
		$isGoogleAutopoin = 3500;
		$isMobiKwikAutopoin = 3500;
		$isAmazoneAutopoin = 3500;
		$isUPIpoin = 10000;
		$isPrimeUser = 0;

		// $result['message'] = "Data Found Sucessfully.";

		$agent = $_SERVER['HTTP_USER_AGENT'];
		$agent = "okhttp/5.0.0-alpha.2";
		//$agent == "okhttp/5.0.0-alpha.2" && 


				if (strlen($userId) > 0 && strlen($withdrawType) > 0 && strlen($withdrawType) > 0 && strlen($userToken) > 0) {
				
					if (strlen($userId) > 0 || strlen($emailId) > 0) {
						
						if(strlen($upiid) > 0){
						
							$withdrawCount = mysqli_query($this->db, "SELECT id FROM withdraw_master WHERE upiid = '" . $upiid . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
							$checWithdrawcount = mysqli_num_rows($withdrawCount);
						}elseif(strlen($accountNumber) > 0){
							
							$withdrawCount = mysqli_query($this->db, "SELECT id FROM withdraw_master WHERE accountNumber = '" . $accountNumber . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
							$checWithdrawcount = mysqli_num_rows($withdrawCount);
						}

						if($checWithdrawcount > 1){	
											
							$sqlwalletupdate = mysqli_query($this->db, "UPDATE `user_master` SET `isActive` = '0' WHERE `user_master`.`userId` = '" . $userId . "' ");
							if ($sqlwalletupdate === TRUE) {
								
								$result['message'] = "sorry your account are block plese contact to LuckyBet ";
								$result['status'] = "4";
								
							}else{
								
								$result['message'] = "sorry your account are block plese contact to LuckyBet ";
								$result['status'] = "4";
							}

						}else{
							// echo "8";
							$withdrawCount = mysqli_query($this->db, "SELECT id FROM withdraw_master WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
							$checWithdrawcount = mysqli_num_rows($withdrawCount);

							$withdrawCount2 = mysqli_query($this->db, "SELECT id FROM withdraw_master WHERE upiid = '" . $upiid . "' AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
							$checWithdrawcount2 = mysqli_num_rows($withdrawCount2);

							$withdrawCount4 = mysqli_query($this->db, "SELECT id FROM withdraw_master WHERE accountNumber = '" . $accountNumber . "' AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ");
							$checWithdrawcount4 = mysqli_num_rows($withdrawCount4);

							$withdrawCount3 = mysqli_query($this->db, "SELECT userId FROM user_master WHERE withdrawMobileNo = '" . $upiid . "' AND userId != '" . $userId . "'  ");
							$checWithdrawcount3 = mysqli_num_rows($withdrawCount3);

							if ($checWithdrawcount > 0 || $checWithdrawcount4 > 0 || $checWithdrawcount2 > 0 || $checWithdrawcount3 > 0) {
								if ($checWithdrawcount3 > 0) {
									$result['message'] = "This mobile number is associated with another account. Please use different mobile number.";
									$result['status'] = "4";
									$result['status'] = "SELECT id FROM withdraw_master WHERE userId = '" . $userId . "'  AND entryDate > '" . date("Y-m-d", time()) . ' 00:00:00' . "' ";
								} else {
									$result['message'] = "You have exhausted the limit of 1 withdrawals per day. Now you can withdraw it tomorrow.";
									$result['status'] = "0";
								}
							} else {
								$sqlRederID = mysqli_query($this->db, "SELECT earningPoint,adId,isActive,isPrimeUser,deviceName,isCommissionPass,token,referralUserId,commissionPoint,muteNoti,withdrawMobileNo,userToken FROM user_master WHERE userId = '" . $userId . "' ");
								if ($sqlRederID->num_rows > 0) {
									$rowewf = $sqlRederID->fetch_assoc();
									$earning_point = $rowewf['earningPoint'];
									$isActive = $rowewf['isActive'];
									$referralUserId = $rowewf['referralUserId'];
									$commissionPoint = $rowewf['commissionPoint'];
									$isCommissionPass = $rowewf['isCommissionPass'];
									$deviceName2 = trim($rowewf['deviceName']);
									$adId2 = trim($rowewf['adId']);
									$withdrawMobileNo = trim($rowewf['withdrawMobileNo']);
									$muteNoti = trim($rowewf['muteNoti']);
									$userToken2 = trim($rowewf['userToken']);
									$token2 = trim($rowewf['token']);
									$result['txnStatus'] = "0";

									if (strlen($rowewf['isPrimeUser']) > 0) {
										$isPrimeUser = $rowewf['isPrimeUser'];
									}

									$sameMobileCheck = "1";

									if ($withdrawMobileNo != "0") {
										if ($withdrawMobileNo == $upiid) {
											$sameMobileCheck = "1";
										} else {
											$sameMobileCheck = "0";
										}
									}

								


									if ($sameMobileCheck == "0" || $isActive == '0' || $userToken != $userToken2) {


										if ($userToken != $userToken2 || $deviceName2 != $device_name) {
											$result['status'] = "5";
											$result['message'] = "Somthing wrong please try again.";
										}

										if ($isActive == '0') {

											$result['message'] = "Your account is blocked for some reason. Please contact us on $email email address to get solution.";
											$result['status'] = "5";
										}

										if ($sameMobileCheck == '0') {
											$upi = substr($withdrawMobileNo, 0, 5);
											$result['message'] = "Please Withdraw With Old Upi Id: " . $upi . "XXXXX . (We allow one mobile number with one device).";
											$result['status'] = "0";
										}
									} else {

										$result['earningPoint'] = $earning_point;

										$result['minPoint'] = $minPoint;

										if ((int)$earning_point >= (int)$minPoint ) {

											switch ($withdrawType) {

												case "1":
												

													$query = mysqli_query($this->db, "INSERT INTO `withdraw_master` (`id`, `userId`, `ipAddress`, `title`, `withdraw_type`, `points`, `emailID`, `bankName`, `ifscCode`, `accountNumber`, `branchName`, `bankHoldername`, `withdrawAmmount`, `upiid`, `isDeliverd`, `txnID`, `comment`, `deviceName`, `isActive`, `deliveryDate`, `raisedTicketId`, `entryDate`, `updatedate`) VALUES (NULL,'" . $userId . "','" . $ipaddress . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','" . $emailId . "','" . $bankName . "','" . $ifscCode . "','" . $accountNumber . "','" . $branchName . "','" . $bankHoldername . "','" . $withdrawAmmount . "','" . $upiid . "','2','','','" . $device_name . "','1','Pending','', NOW(), NOW())");
													
													$result['query'] = "INSERT INTO `withdraw_master` (`id`, `userId`, `ipAddress`, `title`, `withdraw_type`, `points`, `emailID`, `bankName`, `ifscCode`, `accountNumber`, `branchName`, `bankHoldername`, `withdrawAmmount`, `upiid`, `isDeliverd`, `txnID`, `comment`, `deviceName`, `isActive`, `deliveryDate`, `raisedTicketId`, `entryDate`, `updatedate`) VALUES (NULL,'" . $userId . "','" . $ipaddress . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','" . $emailId . "','" . $bankName . "','" . $ifscCode . "','" . $accountNumber . "','" . $branchName . "','" . $bankHoldername . "','" . $withdrawAmmount . "','" . $upiid . "','0','','','" . $device_name . "','1','Pending','', NOW(), NOW())";

													if ($query === TRUE) {
														$finalearning_point = $earning_point - (int)$withdrawAmmount;
														
														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "'  WHERE userId = '" . $userId . "' ");

														if ($sqlwalletupdate) {
															$result['earningPoint'] = $finalearning_point;
															$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.....";
															$result['status'] = "1";
															$result['msgFail'] = "Auto Off";
															$result['txnStatus'] = "5";
														}
													}
													break;
												case "2":
													$query = mysqli_query($this->db, "INSERT INTO `withdraw_master` (`id`, `userId`, `ipAddress`, `title`, `withdraw_type`, `points`, `emailID`, `bankName`, `ifscCode`, `accountNumber`, `branchName`, `bankHoldername`, `withdrawAmmount`, `upiid`, `isDeliverd`, `txnID`, `comment`, `deviceName`, `isActive`, `deliveryDate`, `raisedTicketId`, `entryDate`, `updatedate`) VALUES (NULL,'" . $userId . "','" . $ipaddress . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','" . $emailId . "','" . $bankName . "','" . $ifscCode . "','" . $accountNumber . "','" . $branchName . "','" . $bankHoldername . "','" . $withdrawAmmount . "','" . $upiid . "','2','','','" . $device_name . "','1','Pending','', NOW(), NOW())");
													
													$result['query'] = "INSERT INTO `withdraw_master` (`id`, `userId`, `ipAddress`, `title`, `withdraw_type`, `points`, `emailID`, `bankName`, `ifscCode`, `accountNumber`, `branchName`, `bankHoldername`, `withdrawAmmount`, `upiid`, `isDeliverd`, `txnID`, `comment`, `deviceName`, `isActive`, `deliveryDate`, `raisedTicketId`, `entryDate`, `updatedate`) VALUES (NULL,'" . $userId . "','" . $ipaddress . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','" . $emailId . "','" . $bankName . "','" . $ifscCode . "','" . $accountNumber . "','" . $branchName . "','" . $bankHoldername . "','" . $withdrawAmmount . "','" . $upiid . "','0','','','" . $device_name . "','1','Pending','', NOW(), NOW())";

													if ($query === TRUE) {
														$finalearning_point = (int)$earning_point - (int)$withdrawAmmount;
														
														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "'  WHERE userId = '" . $userId . "' ");

														if ($sqlwalletupdate) {
															$result['earningPoint'] = $finalearning_point;
															$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.....";
															$result['status'] = "1";
															$result['msgFail'] = "Auto Off";
															$result['txnStatus'] = "5";
														}
													}
													break;
												case "3":
													//BGMI  Withdraw
													$query = mysqli_query($this->db, "INSERT INTO tbl_withdraw_master (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
													if ($query === TRUE) {
														$finalearning_point = (int)$earning_point - (int)$minPoint;
														mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "', withdrawMobileNo='" . $mobileNumber . "'  WHERE userId = '" . $userId . "' ");
														if ($sqlwalletupdate) {
															$result['earningPoint'] = $finalearning_point;
															$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
															$result['status'] = "1";
															$result['txnStatus'] = "0";
														}
													}
													break;
												case "4":
													//FF Diamond  Withdraw
													$query = mysqli_query($this->db, "INSERT INTO tbl_withdraw_master (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
													if ($query === TRUE) {
														$finalearning_point = (int)$earning_point - (int)$minPoint;
														mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID . "', '2','" . $finalearning_point . "','" . $title . "')");
														$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");
														if ($sqlwalletupdate) {
															$result['earningPoint'] = $finalearning_point;
															$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
															$result['status'] = "1";
															$result['txnStatus'] = "0";
														}
													}
													break;
												case "5":
													//Paytm Withdraw
													if ($minPoint <= $isMobiKwikAutopoin) {

														sleep(rand(3, 15));
														if ($minPoint <= $isUPIpoin) {
															if ((int)$earning_point >= (int)$minPoint) {
																$finalearning_point = (int)$earning_point - (int)$minPoint;
																$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");
																if (mysqli_affected_rows($this->db)) {
																	$amount = number_format($amount, 2);
																	$paytmParams = array();
																	$txnid =  "3XR" . $userId . "MK" . rand(100, 100000);
																	$response = file_get_contents("http://taskpaydeal.com/abc/UPITransfer/Mobiquickwithdarw.php?mobileNo=" . $mobileNumber . "&amount=" . $amount . "&appName=3XReward&userId=" . $userId . "&txnID=" . $txnid . "&ip=" . $ipaddress);
																	$apiresponse = json_decode($response, true);
																	$result['$apiresponse'] = $apiresponse;
																	if ($apiresponse['status_code'] == "200") {
																		$queryAuto = mysqli_query($this->db, "INSERT INTO tbl_withdraw_master (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','100','" . $emailId . "','" . $mobileNumber . "','1' ,'" . $id . "','" . $ipaddress . "', '' ,'" . $txnid . "','' , '" . $date . "' ,'" . $device_name . "' ) ");
																		if ($queryAuto === true) {
																			mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "', '" . $title . "')");

																			if ($sqlwalletupdate) {
																				$this->senWithdrawNoChanneSucesslNoti($token2, "");
																				$result['earningPoint'] = $finalearning_point;
																				$result['message'] = "We have successfully transferred money to your MobiKwik wallet, please check. Give 5 Star rating & review on playstore.";
																				$result['status'] = "1";
																				$result['txnStatus'] = "5";
																			}
																		}
																	} else {
																		$finalearning_point = (int)$earning_point;
																		$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");
																		$ErrorMessage = $apiresponse['message'];
																		$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
																		$result['status'] = "0";
																	}
																}
															}
														} else {
															//Manual Withdraw 
															$query = mysqli_query($this->db, "INSERT INTO tbl_withdraw_master (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','100','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , 'Penfig' ,'" . $device_name . "' ) ");
															if ($query === TRUE) {
																$finalearning_point = (int)$earning_point - (int)$minPoint;
																mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "','" . $title . "')");

																$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "'  WHERE userId = '" . $userId . "' ");

																if ($sqlwalletupdate) {
																	$result['earningPoint'] = $finalearning_point;
																	$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.....";
																	$result['status'] = "1";
																	$result['msgFail'] = "Auto Off";
																	$result['txnStatus'] = "5";
																}
															}
														}
													} else {
														//Manual Withdraw 
														$query = mysqli_query($this->db, "INSERT INTO tbl_withdraw_master (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , '' ,'" . $device_name . "' ) ");
														if ($query === TRUE) {
															$finalearning_point = (int)$earning_point - (int)$minPoint;
															mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "','" . $title . "')");
															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' , withdrawMobileNo='" . $mobileNumber . "' WHERE userId = '" . $userId . "' ");
															if ($sqlwalletupdate) {
																$result['earningPoint'] = $finalearning_point;
																$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.....";
																$result['status'] = "1";
																$result['msgFail'] = "Auto Off";
																$result['txnStatus'] = "5";
															}
														}
													}
													break;
												case "6":
													//Paytm Withdraw
													sleep(rand(3, 15));
													if ($minPoint <= $isUPIpoin) {
														if ((int)$earning_point >= (int)$minPoint) {
															$finalearning_point = (int)$earning_point - (int)$minPoint;
															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");
															if (mysqli_affected_rows($this->db)) {
																// 		$amount = (int)$payoutPoint / 100;
																$amount = number_format($amount, 2);
																$paytmParams = array();
																$txnid =  "3XR" . $userId . "AM" . rand(100, 100000);
																$response = file_get_contents("http://taskpaydeal.com/abc/UPITransfer/AmazoneWithdarw.php?mobileNo=" . $mobileNumber . "&amount=" . $amount . "&appName=PrizeBox&userId=" . $userId . "&txnID=" . $txnid . "&ip=" . $ipaddress);
																$apiresponse = json_decode($response, true);
																$result['$apiresponse'] = $apiresponse;
																if ($apiresponse['status_code'] == "200") {
																	$queryAuto = mysqli_query($this->db, "INSERT INTO tbl_withdraw_master (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','100','" . $emailId . "','" . $mobileNumber . "','1' ,'" . $id . "','" . $ipaddress . "', '' ,'" . $txnid . "','' , '" . $date . "' ,'" . $device_name . "' ) ");
																	if ($queryAuto === true) {
																		if ($sqlwalletupdate) {
																			$this->senWithdrawNoChanneSucesslNoti($token2, "");
																			$result['earningPoint'] = $finalearning_point;
																			$result['message'] = "We have successfully transferred money to your Amazone wallet, please check. Give 5 Star rating & review on playstore.";
																			$result['status'] = "1";
																			$result['txnStatus'] = "5";
																		}
																	}
																} else {
																	$finalearning_point = (int)$earning_point;
																	$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");
																	$ErrorMessage = $apiresponse['message'];
																	$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.";
																	$result['status'] = "0";
																}
															}
														}
													} else {
														//Manual Withdraw 
														$query = mysqli_query($this->db, "INSERT INTO tbl_withdraw_master (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','100','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , 'Penfig' ,'" . $device_name . "' ) ");
														if ($query === TRUE) {
															$finalearning_point = (int)$earning_point - (int)$minPoint;
															mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "','" . $title . "')");

															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "'  WHERE userId = '" . $userId . "' ");

															if ($sqlwalletupdate) {
																$result['earningPoint'] = $finalearning_point;
																$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.....";
																$result['status'] = "1";
																$result['msgFail'] = "Auto Off";
																$result['txnStatus'] = "5";
															}
														}
													}
													break;
												case "8":
													sleep(rand(2, 8));
													//Paytm Withdraw
													if ($minPoint <= $isUPIpoin) {
														if ((int)$earning_point >= (int)$minPoint) {

															$finalearning_point = (int)$earning_point - (int)$minPoint;
															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");

															if (mysqli_affected_rows($this->db)) {
																$amount = (int)$payoutPoint / 100;
																$txnid =  "$prifix" . $userId . "ID" . rand(100, 1000000);
																$response = file_get_contents("http://taskpaydeal.com/abc/UPITransfer/CBZ-reacharge3.php?UPIID=" . $mobileNumber . "&amount=" . $amount . "&appName=3xrewardApp&userId=" . $userId . "&txnID=" . $txnid . "&ip=" . $ipaddress);
																$apiresponse = json_decode($response, true);
																if ($apiresponse['status_code'] == "200") {
																	$queryAuto = mysqli_query($this->db, "INSERT INTO tbl_withdraw_master (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','100','" . $emailId . "','" . $mobileNumber . "','1' ,'" . $id . "','" . $ipaddress . "', '' ,'" . $txnid . "','' , '" . $date . "' ,'" . $device_name . "' ) ");

																	if ($queryAuto === true) {

																		// $finalearning_point = (int)$earning_point - (int)$minPoint;
																		mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "', '" . $title . "')");

																		// $sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE userId = '" . $userId . "' ");
																		if ($sqlwalletupdate) {

																			$this->senWithdrawNoChanneSucesslNotiUPI($token2, "");
																			$result['earningPoint'] = $finalearning_point;
																			$result['message'] = "We have successfully transferred money to your UPI Bank account.\n \nCredit Amount in 5-10 Minites.\n";
																			$result['status'] = "1";
																			$result['txnStatus'] = "5";
																		}
																	}
																} else {
																	$finalearning_point = (int)$earning_point;
																	$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE  userId = '" . $userId . "' ");

																	$ErrorMessage = $apiresponse['message'];
																	$result['message'] = "There is a technical issue at your bank please try after some time.\nOr\nEnter Valid Bank UPI ID.\n";
																	$result['status'] = "0";
																}
															}
														}
													} else {
														if ($query === TRUE) {
															//Manual Withdraw 
															$query = mysqli_query($this->db, "INSERT INTO tbl_withdraw_master (userId,title,withdraw_type,points,pointValue,emailID,mobileNo,isDeliverd,withdrawId,ipAddress,couponeCode,txnID,comment,deliveryDate,deviceName) VALUES ('" . $userId . "','" . $title . "','" . $withdrawType . "','" . $minPoint . "','10','" . $emailId . "','" . $mobileNumber . "','0' ,'" . $id . "','" . $ipaddress . "', '' ,'','' , 'Penfig' ,'" . $device_name . "' ) ");
															$finalearning_point = (int)$earning_point - (int)$minPoint;
															mysqli_query($this->db, "INSERT INTO earning_point_master(userId, points,earning_type,type,settleAmount,comment) VALUES ('" . $userId . "', '" . $minPoint . "','" . $txtTypeID2 . "', '2','" . $finalearning_point . "','" . $title . "')");

															$sqlwalletupdate = mysqli_query($this->db, "UPDATE user_master SET earningPoint='" . $finalearning_point . "' WHERE userId = '" . $userId . "' ");

															if ($sqlwalletupdate) {
																$result['earningPoint'] = $finalearning_point;
																$result['message'] = "Your withdrawal request has been placed successfully. It will be processed within 48 hours.....";
																$result['status'] = "1";
																$result['msgFail'] = "Auto Off";
																$result['txnStatus'] = "5";
															}
														}
													}
													break;
												default:
													$result['message'] = "Something wrong please try again.";
													$result['status'] = "0";
											}
										} else {
											$result['message'] = "You do not have enough points to withdraw. Earn more points and try again.";
											$result['status'] = "0";
										}
									}
								}
							}
						}	
					} else {
						$result['message'] = "Please Enter Valid Data";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Please Login Again.";
					$result['status'] = "5";
				}
			


		$result['adFailUrl'] = "https://sportsgurupro.com";
		$result['nextWithdrawAmount'] = "5";
		
		// 		$result['txnStatus'] = "5";
		$this->response($this->json($result), 200);
	}
	
	// deposite
	private function JAMSAHEB()
	{	
		global  $pointvalue;
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}

		// $Details = json_decode($this->_request['details'], true);
		
		$decrypted = MCrypt::decrypt($this->_request['details']);
		$Details = json_decode($decrypted, true);

		$result = array();

		$userId = $Details['AGJQ5Q'];
		$deviseId = $Details['ATDHBZ'];
		$adId = $Details['Q2NWTY'];
		$deviceName = $Details['CW8TYR'];
		$email = $Details['NNHGVW'];

		$amounts = $Details['UVEIUTGOUX'];
		$tnxId = $Details['DS9UTFSDIO'];

		$amount=$amounts * $pointvalue;


		$fileName1  =  $_FILES['image']['name'];
		$tempPath1  =  $_FILES['image']['tmp_name'];
		$fileSize1  =  $_FILES['image']['size'];
		
		$valid_extensions = array('jpg', 'png');
		$upload_path = '../deposit/';
		
		$result['Details'] = $Details;


		if (strlen($userId) > 0) {
			if (!empty($fileName1)) {
				$fileExt1 = strtolower(pathinfo($fileName1, PATHINFO_EXTENSION));
				if (in_array($fileExt1, $valid_extensions)) {
					if ($fileSize1 < 5000000) {
						$customFileName = "U{$userId}_A_{$amount}_T_{$tnxId}.{$fileExt1}";
						if (move_uploaded_file($tempPath1, $upload_path . $customFileName)) {
							$imageUrl = "https://judoapps.com/Stake/Api/deposit/" . $customFileName;
								$sql = mysqli_query($this->db, "INSERT INTO tbl_deposits_master (userId,email_ID, amount, tnx_id, image_url, device_id, ad_id, device_name) VALUES ('".$userId."','".$email."','". $amount ."','". $tnxId ."','". $imageUrl ."','". $deviseId ."','". $adId ."','". $deviceName ."')");				
								if ($sql === TRUE) {

								$result['message'] = "Deposit request submitted successfully.";
								$result['status'] = "1";
								$result['depositId'] = mysqli_insert_id($this->db);
							} else {
								$result['message'] = "";
								$result['status'] = "0";
							}
						} else {
							$result['message'] = "Error uploading file.";
							$result['status'] = "0";
						}
					} else {
						$result['message'] = "Sorry, your file is too large, it should be < 5 MB.";
						$result['status'] = "0";
					}
				} else {
					$result['message'] = "Sorry, only JPG and PNG files are allowed.";
					$result['status'] = "0";
				}
			} else {
				$result['message'] = "Please select an image file.";
				$result['status'] = "0";
			}
		} else {
			$result['message'] = "Please login again";
			$result['status'] = "5";
		}

		$result['adFailUrl'] = "https://sportsgurupro.com";

		$this->response($this->json($result), 200);
	}
	private function CheckMobileNo()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$Details = json_decode($this->_request['details'], true);
		$DeviceId = $Details['device_id'];
		$mobileNumber = $Details['mobileNumber'];
		$result = array();

		$setting = mysqli_query($this->db, "SELECT userId FROM user_master WHERE  mobileNumber = '" . $mobileNumber . "' ");
		if ($setting->num_rows > 0) {
			$result['message'] = "Data Found Sucessfully.";
			$result['status'] = "1";
		} else {
			$result['message'] = "Please Login/Signup With emailId.";
			$result['status'] = "0";
		}
		$this->response($this->json($result), 200);
	}
	function iptocountry($ip)

	{

		$numbers = preg_split("/\./", $ip);
		include("../ip_files/" . $numbers[0] . ".php");
		$code = ($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
		foreach ($ranges as $key => $value) {
			if ($key <= $code) {
				if ($ranges[$key][0] >= $code) {
					$two_letter_country_code = $ranges[$key][1];
					break;
				}
			}
		}
		if ($two_letter_country_code == "") {
			$two_letter_country_code = "unkown";
		}
		return $two_letter_country_code;
		// return "USA";
	}
	private function shorten_URL($longUrl)
	{
		global $App_Name, $app_logo;
		$key = 'AIzaSyD_QK-ka7sWe2cc48Us8aTKXsc44CmHjyE';
		$url = 'https://firebasedynamiclinks.googleapis.com/v1/shortLinks?key=' . $key;
		$data = array(
			"dynamicLinkInfo" => array(
				"dynamicLinkDomain" => "Stake.page.link",
				"link" => $longUrl,
				"androidInfo" =>  array("androidPackageName" => $PackageName),
				"socialMetaTagInfo" => array(
					"socialTitle" => "$App_Name : Your Earning Partner",
					"socialDescription" => "$App_Name is one of the BEST money earning and most trusted App in India.",
					"socialImageLink" => $app_logo
				)
			),
			"suffix" => array(
				"option" => "UNGUESSABLE"
			)
		);

		$headers = array('Content-Type: application/json');

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

		$data = curl_exec($ch);
		curl_close($ch);

		$short_url = json_decode($data);
		if (isset($short_url->error)) {
			return "";
		} else {
			return $short_url->shortLink;
		}
	}


	function dateDiffInDays($date1, $date2)
	{

		$diff = strtotime($date2) - strtotime($date1);
		return abs(round($diff / 86400));
	}

	function gen_uuid()
	{
		return sprintf(
			'%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			// 32 bits for "time_low"
			mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),

			// 16 bits for "time_mid"
			mt_rand(0, 0xffff),

			// 16 bits for "time_hi_and_version",
			// four most significant bits holds version number 4
			mt_rand(0, 0x0fff) | 0x4000,

			// 16 bits, 8 bits for "clk_seq_hi_res",
			// 8 bits for "clk_seq_low",
			// two most significant bits holds zero and one for variant DCE1.1
			mt_rand(0, 0x3fff) | 0x8000,

			// 48 bits for "node"
			mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0xffff)
		);
	}
	function getLocationInfoByIp()
	{
		$client  = @$_SERVER['HTTP_CLIENT_IP'];
		$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote  = @$_SERVER['REMOTE_ADDR'];
		$result  = array('country' => '', 'city' => '');
		if (filter_var($client, FILTER_VALIDATE_IP)) {
			$ip = $client;
		} elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
			$ip = $forward;
		} else {
			$ip = $remote;
		}

		$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
		//$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=138.197.222.35"));    
		if ($ip_data && $ip_data->geoplugin_countryName != null) {
			$result['country'] = $ip_data->geoplugin_countryCode;
			$result['city'] = $ip_data->geoplugin_city;
		}

		return $result;
	}


	private function senWithdrawNoChanneSucesslNotiCoupone($token, $point)
	{

		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array("title" => "Your Withdraw Request Sucessfully Credit in your redeem history.", 'body' => "Please Check your redeem history for redeem coupon code."),
			'android' => array('notification' => array("title" => "Your Withdraw Request Sucessfully Credit in your redeem history.", 'body' => "Please Check your redeem history for redeem coupon code.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "Your Withdraw Request Sucessfully Credit in your redeem history.",
				"description" => "Please Check your redeem history for redeem coupon code.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "success",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}


	function log($Details, $name, $isencrypted)
	{
		$on = '1';
		if ($on == '1') {

			if ($isencrypted == '1') {
				$decrypted = MCrypt::decrypt($Details);
				$encrypted = json_decode($decrypted, true);
				$var =  json_encode($encrypted, JSON_PRETTY_PRINT);
				$querry2 = mysqli_query($this->db, "INSERT INTO `log_master` ( `apiName`, `details`,`decrypted`, `appName`) VALUES ('" . $name . "', '" . $Details . "','" . $var . "', 'Stake')");
			} else {

				$var =  json_encode($Details, JSON_PRETTY_PRINT);
				$querry2 = mysqli_query($this->db, "INSERT INTO `log_master` ( `apiName`, `decrypted`, `appName`) VALUES ('" . $name . "', '" . $var . "', 'Stake')");
			}
		}
	}
	private function senWithdrawNoChanneSucesslNoti($token, $point)
	{


		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array("title" => "We have transferred money to your UPI wallet successfully.", 'body' => "Please check your UPI wallet. Give 5 Star tatings & review on playstore."),
			'android' => array('notification' => array("title" => "We have transferred money to your UPI wallet successfully.", 'body' => "Please check your UPI wallet. Give 5 Star tatings & review on playstore.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "We have transferred money to your UPI wallet successfully.",
				"description" => "Please check your UPI wallet. Give 5 Star tatings & review on playstore.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "success",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}

	private function senWithdrawNoChanneSucesslNotiUPI($token, $point)
	{

		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array('title' => "We have transferred money to your UPI bank account successfully.", 'body' => "Please check your UPI wallet. Give 5 Star tatings & review on playstore."),
			'android' => array('notification' => array('title' => "We have transferred money to your UPI bank account successfully.", 'body' => "Please check your UPI wallet. Give 5 Star tatings & review on playstore.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "We have transferred money to your UPI bank account successfully.",
				"description" => "Please check your UPI wallet. Give 5 Star tatings & review on playstore.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "success",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}

	function exists_url($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		// don't download content
		curl_setopt($ch, CURLOPT_NOBODY, 1);
		curl_setopt($ch, CURLOPT_FAILONERROR, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$result = curl_exec($ch);
		curl_close($ch);
		if ($result !== FALSE) {
			return true;
		} else {
			return false;
		}
	}
	private function senWithdrawNoChanneSucesslNotiQR($token, $point)
	{
		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array('title' => "We have transferred money to your merchant bank successfully.", 'body' => ""),
			'android' => array('notification' => array('title' => "We have transferred money to your merchant bank successfully.", 'body' => "")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "We have transferred money to your merchant bank successfully.",
				"description" => "",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "success",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}


	private function refreFrendNoti($token, $point)
	{
		global $Server_key, $serverToken, $projectId;
		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array('title' => $point . " Free Points received!", 'body' => "Your friend has signed up with your referral code."),
			'android' => array('notification' => array('title' => $point . " Free Points received!", 'body' => "Your friend has signed up with your referral code.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => $point . " Free Points received!",
				"description" => "Your friend has signed up with your referral code.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "coin",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		curl_close($curl);
	}



	private function sendDailyLoginNoti($token, $point)
	{
		global $Server_key, $serverToken, $projectId;

		$image = "";

		$flip1 = rand(0, 10);

		if ($flip1 == '1') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/259_newvideo.jpg";
		} else if ($flip1 == '2') {
			$image = "https://mycashbazar.com/admin/images/homeslider/85_taskkarorearnkaro.png";
		} else if ($flip1 == '3') {
			$image = "https://mycashbazar.com/admin/images/homeslider/20_smallads.png";
		} else if ($flip1 == '4') {
			$image = "https://mycashbazar.com/admin/images/homeslider/81_2INR.png";
		} else if ($flip1 == '5') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/728_refervideo.png";
		} else if ($flip1 == '6') {
			$image = "https://mycashbazar.com/admin/images/homeslider/81_2INR.png";
		} else if ($flip1 == '7') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/476_Minmimamwithdrawnew.jpg";
		} else if ($flip1 == '8') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/427_sdsdsd.png";
		} else if ($flip1 == '9') {
			$image = "https://sportsgurupro.com/admin/images/homeslider/672_ewwewewe.jpg";
		}


		$url = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
		$data = array('message' => array(
			'token' => $token,
			'notification' => array('title' => "Congratulations!", 'body' => $point . " Points has been credited in your wallet."),
			'android' => array('notification' => array('title' => "Congratulations!", 'body' => $point . " Points has been credited in your wallet.")),
			'data' => array(
				"Notification_Id" => strval(rand(10, 100)),
				"title" => "Congratulations!",
				"description" => $point . " Points has been credited in your wallet.",
				"notificationDate" => date('Y-m-d'),
				"image" => "",
				"screenNo" => "0",
				"icon" => "coin",
				"matchId" => "",
				"offerId" => "",
				"url" => "",
				"badge" => '1',
				"sound" => 'default'
			)
		));
		$content = json_encode($data);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt(
			$curl,
			CURLOPT_HTTPHEADER,
			array(
				"Content-Type: application/json; charset=utf-8",
				"Authorization: Bearer " . $serverToken
			)
		);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$json_response = curl_exec($curl);
		$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		curl_close($curl);
	}

	private function Hello()
	{
		if ($this->get_request_method() != "GET") {
			$this->response('', 406);
		}
		$result[] = array('Hello' => "Milan Pambhar");
		$this->response($this->json($result), 200);
	}

	private function json($data)
	{
		// $encrypt = MCrypt::encrypt(json_encode($data));
		$mcrypt = new MCrypt();
		$encrypted = $mcrypt->encrypt(json_encode($data));
		// $data= array();
		$data['encrypt'] = $encrypted;
		if (is_array($data)) {
			return json_encode($data);
		}
	}



	function getIp()
	{
		$ip = $_SERVER['REMOTE_ADDR'];
		if ($ip) {
			if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
				$ip = $_SERVER['HTTP_CLIENT_IP'];
			} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
				$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
			}
			return $ip;
		}
		return false;
	}


	function startsWith($haystack, $needle)
	{
		$length = strlen($needle);
		return (substr($haystack, 0, $length) === $needle);
	}
}
$api = new API;
$api->processApi();


class MCrypt
{


	public $iv = 'maj9ki765g7hjm8j'; #Same as in JAVA
	public $key = 'okm8uhbvgy789ijn'; #Same as in JAVA
	function __construct()
	{
	}



	function encrypt($str)
	{

		global $encryptionMethod, $secretHash, $iv;

		$td = mcrypt_module_open($encryptionMethod, '', 'cbc', $iv);

		mcrypt_generic_init($td, $secretHash, $iv);
		$encrypted = mcrypt_generic($td, $str);

		mcrypt_generic_deinit($td);
		mcrypt_module_close($td);

		return bin2hex($encrypted);
	}

	static function decrypt($code)
	{
		global $encryptionMethod, $secretHash, $iv;

		$code = hex2bin($code);

		$td = mcrypt_module_open($encryptionMethod, '', 'cbc', $iv);

		mcrypt_generic_init($td, $secretHash, $iv);
		$decrypted = mdecrypt_generic($td, $code);

		mcrypt_generic_deinit($td);
		mcrypt_module_close($td);

		return utf8_encode(trim($decrypted));
	}


	function hex2bin($hexdata)
	{
		$bindata = '';
		for ($i = 0; $i < strlen($hexdata); $i += 2) {
			$bindata .= chr(hexdec(substr($hexdata, $i, 2)));
		}
		return $bindata;
	}
}