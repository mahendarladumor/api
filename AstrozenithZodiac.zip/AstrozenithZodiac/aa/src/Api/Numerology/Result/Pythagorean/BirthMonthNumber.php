<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class BirthMonthNumber extends Number
{
}
