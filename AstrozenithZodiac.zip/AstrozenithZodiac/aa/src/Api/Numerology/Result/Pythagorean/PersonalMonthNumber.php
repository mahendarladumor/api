<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class PersonalMonthNumber extends Number
{
}
