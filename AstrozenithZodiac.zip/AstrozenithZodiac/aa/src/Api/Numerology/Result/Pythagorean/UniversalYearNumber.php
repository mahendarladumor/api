<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class UniversalYearNumber extends Number
{
}
