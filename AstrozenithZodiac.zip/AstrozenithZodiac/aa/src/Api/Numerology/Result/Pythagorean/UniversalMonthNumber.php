<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class UniversalMonthNumber extends Number
{
}
