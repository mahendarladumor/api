<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class InnerDreamNumber extends Number
{
}
