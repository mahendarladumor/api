<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class BalanceNumber extends Number
{
}
