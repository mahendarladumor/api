<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class UniversalDayNumber extends Number
{
}
