<?php



namespace Prokerala\Api\Numerology\Result\Pythagorean;

class BirthdayNumber extends Number
{
}
