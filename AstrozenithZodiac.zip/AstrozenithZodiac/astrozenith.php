<?php
date_default_timezone_set('Asia/Kolkata');
include 'include/connection.php';

if (!$mysqli) {
    die("Connection failed: " . mysqli_connect_error());
}

$horoscopes = array(
    'aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo',
    'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces'
);

$start = date('Y-m-d');

// Check if data has already been inserted today
$checkSql = "SELECT COUNT(*) as count FROM astrozenithzodiac WHERE entryDate = '$start'";
$checkResult = mysqli_query($mysqli, $checkSql);
$row = mysqli_fetch_assoc($checkResult);

if ($row['count'] == count($horoscopes)) {
    echo "Daily entries for all horoscopes already exist. Exiting.\n";
    exit;
}

// Reset monthly_count for keys that haven't been used in a month
$resetSql = "UPDATE api_list SET monthly_count = 0 WHERE monthly_count = 18 AND entryDate < DATE_SUB(CURDATE(), INTERVAL 1 MONTH)";
mysqli_query($mysqli, $resetSql);

function getNextApiKey($mysqli) {
    $apiSql = "SELECT * FROM api_list WHERE monthly_count < 18 ORDER BY monthly_count ASC, entryDate ASC LIMIT 1";
    $apiResult = mysqli_query($mysqli, $apiSql);
    return mysqli_fetch_assoc($apiResult);
}

$apiRow = getNextApiKey($mysqli);

if (!$apiRow) {
    echo "No available API keys found. All keys have been used this month.\n";
    exit;
}

$orderid = $apiRow['orderid'];
$key = $apiRow['key'];

foreach ($horoscopes as $horoscope) {
    echo "Processing horoscope: $horoscope\n";
    
    $retry = true;
    while ($retry) {
        echo "Using API key: $key\n";

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://best-daily-astrology-and-horoscope-api.p.rapidapi.com/api/Detailed-Horoscope/?zodiacSign=$horoscope",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => [
                "x-rapidapi-host: best-daily-astrology-and-horoscope-api.p.rapidapi.com",
                "x-rapidapi-key: $key"
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        curl_close($curl);

        if ($err) {
            echo "cURL Error for $horoscope: " . $err . "\n";
            $retry = false;
            continue;
        }

        $responseData = json_decode($response, true);

        if ($httpCode == 429 && isset($responseData['message']) && strpos($responseData['message'], "You have exceeded the MONTHLY quota") !== false) {
            echo "Monthly quota exceeded for this key. Moving to next key.\n";
            mysqli_query($mysqli, "UPDATE api_list SET monthly_count = 18, entryDate = '$start' WHERE orderid = $orderid");
            
            $apiRow = getNextApiKey($mysqli);
            if (!$apiRow) {
                echo "No more available API keys. Exiting.\n";
                exit;
            }
            $orderid = $apiRow['orderid'];
            $key = $apiRow['key'];
        } else {
            $retry = false;
        }
    }

    if (isset($responseData['status']) && $responseData['status'] === true) {
        $prediction = $responseData['prediction'] ?? '';
        $number = $responseData['number'] ?? '';
        $color = $responseData['color'] ?? '';
        $mantra = $responseData['mantra'] ?? '';
        $remedy = $responseData['remedy'] ?? '';
        $start = date("Y-m-d h:i:s");
        $sql = "INSERT INTO astrozenithzodiac (horoscope, prediction, number, color, mantra, remedy, entryDate) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                prediction = VALUES(prediction),
                number = VALUES(number),
                color = VALUES(color),
                mantra = VALUES(mantra),
                remedy = VALUES(remedy),
                entryDate = VALUES(entryDate)";

        $stmt = $mysqli->prepare($sql);
        if (!$stmt) {
            echo "Error preparing statement for $horoscope: " . $mysqli->error . "\n";
        } else {
            $stmt->bind_param("sssssss", $horoscope, $prediction, $number, $color, $mantra, $remedy, $start);

            if ($stmt->execute()) {
                echo "Data inserted/updated successfully for $horoscope!\n";
            } else {
                echo "Error inserting/updating data for $horoscope: " . $stmt->error . "\n";
            }

            $stmt->close();
        }

        // Update API usage count
        mysqli_query($mysqli, "UPDATE api_list SET monthly_count = monthly_count + 1, entryDate = '$start' WHERE orderid = $orderid");
        echo "API usage updated for $horoscope. $start\n";
    } else {
        echo "Invalid response from API for $horoscope.\n";
    }

    echo "\n";
    sleep(1);
}

mysqli_close($mysqli);
?>