<?php

require_once("Rest.inc.php");


header("Access-Control-Allow-Methods: POST");
header("Acess-Control-Allow-Origin: *");
error_reporting(E_ERROR | E_PARSE);


date_default_timezone_set("Asia/Calcutta");



global $encryptionMethod, $iv, $secretHash, $WelcomeBonusPoint, $charges, $minAmontCharger;
$encryptionMethod = "rijndael-128";
$secretHash = "tegsvek730d6isbl";
$iv = 'vsrejst52h65bebd';
$WelcomeBonusPoint = 200;
$minAmontCharger = 10;
$charges = 120;



// ini_set('display_errors', 1);	
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

class API extends REST
{
	public $data = "";	
	const DB_SERVER = "localhost";
	const DB_USER = "AstrozenithZodiac_DB";
	const DB_PASSWORD = "LLLwESK22Ph8afC5";
	const DB = "astrozenithzodiac_db";
	private $db = NULL;
	
	const Miv =  'vsrejst52h65bebd'; #Same as in JAVA
	const Mkey = 'tegsvek730d6isbl'; #Same as in JAVA
	const isCompleteAdjoeGame = '0'; // This will check adjoe first then will check for task completion

	public function __construct()
	{
		parent::__construct();
		$this->dbConnect();
	}

	private function dbConnect()
	{
		$this->db = mysqli_connect(self::DB_SERVER, self::DB_USER, self::DB_PASSWORD, self::DB);
		$this->db->set_charset('utf8mb4');
	}

	public function processApi()
	{
		if (isset($_REQUEST['rquest']) && $_REQUEST['rquest'] != null) {
			$func = strtolower(trim(str_replace("/", "", $_REQUEST['rquest'])));

			if ((int) method_exists($this, $func) > 0)
				$this->$func();
			else
				$result = array(
					'status' => "0",
					'message' => "Something Wrong2"
				);
			$this->response($this->json($result), 404);
		} else {
			$result = array(
				'status' => "0",
				'message' => "Something Wrong1"
			);
			$this->response($this->json($result), 404);
		}
	}
	private function astrozenithzodiac()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();
		$Details = json_decode($this->_request['details'], true);

		$horoscope = $Details['horoscope'];		
				
				$resSlider = mysqli_query($this->db, "SELECT * FROM `astrozenithzodiac` WHERE horoscope = '" . $horoscope . "'  ");
				if (mysqli_num_rows($resSlider) > 0) {
					while ($rlContest = mysqli_fetch_array($resSlider, MYSQLI_ASSOC)) {
						$result['astrozenithzodiac'][] = $rlContest;
					}
					$result['message'] = "Data Found Sucessfully";
					$result['status'] = "1";
				}		
		$this->response($this->json($result), 200);
	}
	private function BABU()
	{
		if ($this->get_request_method() != "POST") {
			$this->response('', 406);
		}
		$result = array();
		$Details = json_decode($this->_request['details'], true);

		$month = $Details['month'];		
				
				$resSlider = mysqli_query($this->db, "SELECT * FROM `india_fastival` WHERE `Date` LIKE '%$month%'");
				if (mysqli_num_rows($resSlider) > 0) {
					while ($rlContest = mysqli_fetch_array($resSlider, MYSQLI_ASSOC)) {
						$result['india_fastival'][] = $rlContest;
					}
					$result['message'] = "Data Found Sucessfully";
					$result['status'] = "1";
				}		
		$this->response($this->json($result), 200);
	}

	private function json($data)
	{
		// $encrypt = MCrypt::encrypt(json_encode($data));
		$mcrypt = new MCrypt();
		$encrypted = $mcrypt->encrypt(json_encode($data));
		// $data= array();
		$data['encrypt'] = $encrypted;
		if (is_array($data)) {
			return json_encode($data);
		}
	}

}
$api = new API;
$api->processApi();


class MCrypt
{


	public $iv = 'vsrejst52h65bebd'; #Same as in JAVA
	public $key = 'tegsvek730d6isbl'; #Same as in JAVA
	function __construct()
	{
	}



	function encrypt($str)
	{

		global $encryptionMethod, $secretHash, $iv;

		$td = mcrypt_module_open($encryptionMethod, '', 'cbc', $iv);

		mcrypt_generic_init($td, $secretHash, $iv);
		$encrypted = mcrypt_generic($td, $str);

		mcrypt_generic_deinit($td);
		mcrypt_module_close($td);

		return bin2hex($encrypted);
	}

	static function decrypt($code)
	{
		global $encryptionMethod, $secretHash, $iv;

		$code = hex2bin($code);

		$td = mcrypt_module_open($encryptionMethod, '', 'cbc', $iv);

		mcrypt_generic_init($td, $secretHash, $iv);
		$decrypted = mdecrypt_generic($td, $code);

		mcrypt_generic_deinit($td);
		mcrypt_module_close($td);

		return utf8_encode(trim($decrypted));
	}


	function hex2bin($hexdata)
	{
		$bindata = '';
		for ($i = 0; $i < strlen($hexdata); $i += 2) {
			$bindata .= chr(hexdec(substr($hexdata, $i, 2)));
		}
		return $bindata;
	}
}
