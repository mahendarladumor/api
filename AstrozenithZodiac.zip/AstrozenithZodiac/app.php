<?php

$curl = curl_init();

curl_setopt_array($curl, [
	CURLOPT_URL => "https://rto-vehicle-information-verification-india.p.rapidapi.com/api/v1/rc/vehicleinfo",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "POST",
	CURLOPT_POSTFIELDS => json_encode([
		'reg_no' => 'GJ05RX3943',
		'consent' => 'Y',
		'consent_text' => 'I hear by declare my consent agreement for fetching my information via AITAN Labs API'
	]),
	CURLOPT_HTTPHEADER => [
		"Content-Type: application/json",
		"x-rapidapi-host: rto-vehicle-information-verification-india.p.rapidapi.com",
		"x-rapidapi-key: 99b1ca17a6msh45c684d3387c90ap1a27e5jsn1b5157e986bf"
	],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
	echo "cURL Error #:" . $err;
} else {
	echo $response;
}